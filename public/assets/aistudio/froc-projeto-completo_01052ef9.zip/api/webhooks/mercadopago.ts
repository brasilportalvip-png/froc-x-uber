import { db } from '../_lib/db';
import { verifyMercadoPagoSignature } from '../_lib/security';

interface VercelLikeRequest {
  method?: string;
  headers: Record<string, string | string[] | undefined>;
  body?: unknown;
  query?: Record<string, string | string[] | undefined>;
  url?: string;
}

interface VercelLikeResponse {
  status: (code: number) => VercelLikeResponse;
  json: (data: unknown) => void;
  setHeader: (name: string, value: string) => VercelLikeResponse;
}

export default async function handler(req: VercelLikeRequest, res: VercelLikeResponse) {
  res.setHeader('Content-Type', 'application/json');

  if (req.method !== 'POST') {
    return res.status(405).json({
      success: false,
      error: { code: 'METHOD_NOT_ALLOWED', message: 'Apenas requisições POST são aceitas no endpoint de webhook.' },
    });
  }

  try {
    const xSignature = (req.headers['x-signature'] as string) || '';
    const xRequestId = (req.headers['x-request-id'] as string) || '';
    const queryId = (req.query?.['data.id'] || req.query?.id) as string;

    let payloadBody: Record<string, unknown> = {};
    if (typeof req.body === 'string') {
      try {
        payloadBody = JSON.parse(req.body);
      } catch {
        payloadBody = {};
      }
    } else if (req.body && typeof req.body === 'object') {
      payloadBody = req.body as Record<string, unknown>;
    }

    const eventId = String(payloadBody.id || payloadBody['data.id'] || queryId || xRequestId || Date.now());

    // Deduplicação estrita de eventos (idempotência garantida)
    if (db.processedWebhookEvents.has(eventId)) {
      return res.status(200).json({
        status: 'already_processed',
        eventId,
        message: 'Evento duplicado já processado com idempotência.',
      });
    }

    // Validação criptográfica de autenticidade HMAC SHA-256 se o segredo estiver configurado
    const webhookSecret = process.env.MERCADO_PAGO_WEBHOOK_SECRET;
    if (webhookSecret && xSignature) {
      const isValid = verifyMercadoPagoSignature(xSignature, queryId || eventId, webhookSecret);
      if (!isValid) {
        return res.status(401).json({
          success: false,
          error: { code: 'INVALID_SIGNATURE', message: 'Assinatura HMAC x-signature inválida do provedor Mercado Pago.' },
        });
      }
    }

    const action = String(payloadBody.action || payloadBody.type || 'payment.updated');
    const externalReference = String(payloadBody.external_reference || '');

    // Localização da ordem em custódia correspondente
    let targetEscrow = externalReference ? db.escrowOrders.get(externalReference) : undefined;
    if (!targetEscrow) {
      for (const order of db.escrowOrders.values()) {
        if (order.mercadoPagoPaymentId === eventId || order.preferenceId === eventId) {
          targetEscrow = order;
          break;
        }
      }
    }

    if (targetEscrow) {
      if (action.includes('payment') || action.includes('order')) {
        targetEscrow.status = 'held_escrow';
        targetEscrow.mercadoPagoPaymentId = eventId;
        db.escrowOrders.set(targetEscrow.id, targetEscrow);

        const associatedTrip = db.trips.get(targetEscrow.tripId);
        if (associatedTrip) {
          associatedTrip.paymentStatus = 'held_escrow';
          associatedTrip.status = 'accepted';
          associatedTrip.updatedAt = new Date().toISOString();
          db.trips.set(associatedTrip.id, associatedTrip);
        }
      }
    }

    // Marca o evento como processado de forma durável
    db.processedWebhookEvents.add(eventId);

    return res.status(200).json({
      status: 'received',
      eventId,
      processedAt: new Date().toISOString(),
      verified: !!webhookSecret,
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Falha no processador de webhooks.';
    return res.status(500).json({
      success: false,
      error: { code: 'WEBHOOK_INTERNAL_ERROR', message },
    });
  }
}

import type { IncomingMessage, ServerResponse } from 'http';
import {
  calculateDirectFare,
  calculateNegotiatedFloor,
  validateNegotiatedOffer,
  calculateCarpoolFare,
  VehicleCategory,
} from './_lib/pricing';
import { getStore, TripRecord } from './_lib/db';
import { sanitizeString } from './_lib/security';

interface VercelRequest extends IncomingMessage {
  query: Record<string, string | string[]>;
  cookies?: Record<string, string>;
  body?: unknown;
  headers: Record<string, string | string[] | undefined>;
  method?: string;
}

interface VercelResponse extends ServerResponse {
  status: (code: number) => VercelResponse;
  json: (body: unknown) => void;
}

const seenIdempotencyKeys = new Map<string, { timestamp: number; response: unknown }>();

function readJsonBody(req: VercelRequest): Promise<Record<string, unknown>> {
  return new Promise((resolve, reject) => {
    if (req.body && typeof req.body === 'object') {
      resolve(req.body as Record<string, unknown>);
      return;
    }
    let data = '';
    req.on('data', (chunk) => {
      data += chunk;
    });
    req.on('end', () => {
      try {
        resolve(data ? JSON.parse(data) : {});
      } catch (err) {
        reject(err);
      }
    });
    req.on('error', (err) => reject(err));
  });
}

export default async function handler(req: VercelRequest, res: VercelResponse): Promise<void> {
  res.setHeader('Content-Type', 'application/json');
  const method = req.method || 'GET';
  const store = getStore();

  if (method === 'GET') {
    const url = new URL(req.url || '/', 'http://localhost');
    const id = url.searchParams.get('id');
    const mode = url.searchParams.get('mode');

    if (id) {
      const trip = store.trips.get(id);
      if (!trip) {
        res.status(404).json({ error: 'Viagem ou frete não encontrado.' });
        return;
      }
      res.status(200).json({ success: true, trip, id: trip.id, ...trip });
      return;
    }

    const allTrips = Array.from(store.trips.values());
    const filtered = mode ? allTrips.filter((t) => t.mode === mode) : allTrips;
    res.status(200).json({ success: true, trips: filtered, total: filtered.length });
    return;
  }

  if (method === 'POST') {
    const rawKey = req.headers['idempotency-key'];
    const idempotencyKey = typeof rawKey === 'string' ? rawKey : undefined;

    if (idempotencyKey && seenIdempotencyKeys.has(idempotencyKey)) {
      const cached = seenIdempotencyKeys.get(idempotencyKey)!;
      res.status(200).json(cached.response);
      return;
    }

    try {
      const body = await readJsonBody(req);
      const mode = (body.mode as string) || 'direct';
      const origin = sanitizeString(String(body.origin || body.originAddress || ''));
      const destination = sanitizeString(String(body.destination || body.destinationAddress || ''));
      const distanceKm = Math.max(1, Number(body.estimatedKm || body.distanceKm || 10));
      const durationMins = Math.max(2, Number(body.estimatedMinutes || body.durationMinutes || 20));
      const vehicleCategory = (body.vehicleCategory as VehicleCategory) || 'popular';

      if (!origin || !destination) {
        res.status(400).json({ error: 'Endereço de partida e destino são obrigatórios.' });
        return;
      }

      let finalPrice = 0;
      let platformFee = 0;
      let driverPayout = 0;
      let status: TripRecord['status'] = 'searching';

      if (mode === 'direct') {
        const fare = calculateDirectFare(distanceKm, durationMins, vehicleCategory);
        finalPrice = fare.finalFare;
        platformFee = fare.platformFee;
        driverPayout = fare.driverPayout;
        status = 'searching';
      } else if (mode === 'negotiated') {
        const floorCalc = calculateNegotiatedFloor(distanceKm, durationMins);
        const offered = Number(body.suggestedPrice || body.price || body.offeredPrice || floorCalc.minimumFloor);
        const validation = validateNegotiatedOffer(distanceKm, offered, durationMins);
        if (!validation.isValid) {
          res.status(400).json({
            error: validation.reason || validation.message || `Oferta abaixo do piso regulatório de R$ ${floorCalc.minimumFloor.toFixed(2).replace('.', ',')}.`,
          });
          return;
        }
        finalPrice = offered;
        platformFee = parseFloat((offered * 0.12).toFixed(2));
        driverPayout = parseFloat((offered - platformFee).toFixed(2));
        status = 'bidding';
      } else if (mode === 'carpool') {
        const seats = Math.max(1, Number(body.seats || body.seatsAvailable || 1));
        const carpoolCalc = calculateCarpoolFare(distanceKm, seats);
        finalPrice = carpoolCalc.finalFare;
        platformFee = carpoolCalc.platformFee;
        driverPayout = carpoolCalc.driverPayout;
        status = 'searching';
      } else {
        res.status(400).json({ error: 'Modalidade inválida. Utilize direct, negotiated, carpool ou utilize /api/freights para fretes.' });
        return;
      }

      const newTrip: TripRecord = {
        id: `trip_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        mode: mode as TripRecord['mode'],
        status,
        customerId: 'usr_guest',
        customerName: 'Passageiro Froc',
        origin,
        destination,
        distanceKm,
        durationMinutes: durationMins,
        price: finalPrice,
        platformFee,
        driverPayout,
        pinCode: String(Math.floor(1000 + Math.random() * 9000)),
        paymentStatus: 'pending',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      store.trips.set(newTrip.id, newTrip);

      const responsePayload = {
        success: true,
        trip: newTrip,
        id: newTrip.id,
        ...newTrip,
      };

      if (idempotencyKey) {
        seenIdempotencyKeys.set(idempotencyKey, {
          timestamp: Date.now(),
          response: responsePayload,
        });
      }

      res.status(201).json(responsePayload);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Erro interno ao processar criação de corrida.';
      res.status(500).json({ error: msg });
    }
    return;
  }

  if (method === 'PATCH' || method === 'DELETE') {
    try {
      const body = await readJsonBody(req);
      const url = new URL(req.url || '/', 'http://localhost');
      const tripId = String(body.tripId || body.id || url.searchParams.get('id') || '');
      const action = String(body.action || url.searchParams.get('action') || '');

      const trip = store.trips.get(tripId);
      if (!trip) {
        res.status(404).json({ error: 'Viagem não encontrada.' });
        return;
      }

      if (action === 'accept') {
        trip.status = 'accepted';
        trip.driverId = String(body.driverId || 'drv_test_01');
        trip.driverName = String(body.driverName || 'Carlos Motorista');
        trip.updatedAt = new Date().toISOString();
        store.trips.set(tripId, trip);
        res.status(200).json({ success: true, message: 'Viagem aceita pelo motorista.', trip, id: trip.id, ...trip });
        return;
      }

      if (action === 'start_trip') {
        trip.status = 'in_transit';
        trip.updatedAt = new Date().toISOString();
        store.trips.set(tripId, trip);
        res.status(200).json({ success: true, message: 'Viagem iniciada.', trip, id: trip.id, ...trip });
        return;
      }

      if (action === 'complete') {
        trip.status = 'delivered';
        trip.paymentStatus = 'released';
        trip.updatedAt = new Date().toISOString();
        store.trips.set(tripId, trip);
        res.status(200).json({ success: true, message: 'Viagem concluída e custódia liberada.', trip, id: trip.id, ...trip });
        return;
      }

      if (action === 'cancel' || method === 'DELETE') {
        trip.status = 'cancelled';
        trip.updatedAt = new Date().toISOString();
        store.trips.set(tripId, trip);
        res.status(200).json({ success: true, message: 'Viagem cancelada com sucesso.', trip, id: trip.id, ...trip });
        return;
      }

      if (action === 'verify_pin') {
        const inputPin = String(body.pin || '').trim();
        if (trip.pinCode !== inputPin) {
          // Requisito e teste esperam código HTTP 400 para PIN inválido
          res.status(400).json({ error: 'PIN de segurança inválido.' });
          return;
        }
        trip.status = 'delivered';
        trip.paymentStatus = 'released';
        trip.updatedAt = new Date().toISOString();
        store.trips.set(tripId, trip);
        res.status(200).json({ success: true, message: 'PIN autenticado. Custódia liberada ao motorista.', trip, id: trip.id, ...trip });
        return;
      }

      res.status(400).json({ error: `Ação '${action}' não suportada.` });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Erro ao atualizar viagem.';
      res.status(500).json({ error: msg });
    }
    return;
  }

  res.status(405).json({ error: `Método ${method} não suportado.` });
}

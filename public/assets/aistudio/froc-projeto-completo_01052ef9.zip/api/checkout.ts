import { db } from './_lib/db';
import { sanitizeString, validateSafeNumber } from './_lib/security';

interface VercelLikeRequest {
  method?: string;
  headers: Record<string, string | string[] | undefined>;
  body?: unknown;
  query?: Record<string, string | string[] | undefined>;
}

interface VercelLikeResponse {
  status: (code: number) => VercelLikeResponse;
  json: (data: unknown) => void;
  setHeader: (name: string, value: string) => VercelLikeResponse;
}

export default async function handler(req: VercelLikeRequest, res: VercelLikeResponse) {
  res.setHeader('Content-Type', 'application/json');

  if (req.method !== 'POST') {
    return res.status(405).json({
      success: false,
      error: { code: 'METHOD_NOT_ALLOWED', message: 'Método não permitido. Utilize POST.' },
    });
  }

  try {
    let parsedBody: Record<string, unknown> = {};
    if (typeof req.body === 'string') {
      parsedBody = JSON.parse(req.body);
    } else if (req.body && typeof req.body === 'object') {
      parsedBody = req.body as Record<string, unknown>;
    }

    const tripId = sanitizeString(String(parsedBody.tripId || ''));
    const rawAmount = Number(parsedBody.amount);
    const payerEmail = sanitizeString(String(parsedBody.payerEmail || 'passageiro@froc.app'));
    const payerName = sanitizeString(String(parsedBody.payerName || 'Passageiro Froc X Uber'));

    if (!tripId) {
      return res.status(400).json({
        success: false,
        error: { code: 'INVALID_TRIP_ID', message: 'O identificador da viagem (tripId) é obrigatório.' },
      });
    }

    const trip = db.trips.get(tripId);
    if (!trip) {
      return res.status(404).json({
        success: false,
        error: { code: 'TRIP_NOT_FOUND', message: 'Viagem ou frete não encontrado na base de dados.' },
      });
    }

    const finalAmount = validateSafeNumber(rawAmount > 0 ? rawAmount : trip.finalAgreedPrice, 5.0, 50000.0);
    
    // Cálculo da comissão regulatória Froc X Uber
    const feePercent = trip.mode === 'direct' ? 0.12 : trip.mode === 'carpool' ? 0.10 : 0.08;
    const platformFee = Math.round(finalAmount * feePercent * 100) / 100;
    const driverPayout = Math.round((finalAmount - platformFee) * 100) / 100;

    const escrowOrderId = `escrow_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
    const mpAccessToken = process.env.MERCADO_PAGO_ACCESS_TOKEN;
    const deploymentEnv = process.env.FROC_DEPLOYMENT_ENVIRONMENT || 'production';
    const isSandbox = deploymentEnv !== 'production' || !mpAccessToken;

    let preferenceId = `pref_sandbox_${Date.now()}`;
    let checkoutUrl = `https://sandbox.mercadopago.com.br/checkout/v1/redirect?pref_id=${preferenceId}`;

    // Integração real com API Mercado Pago Checkout Preferences quando token presente
    if (mpAccessToken) {
      try {
        const mpResponse = await fetch('https://api.mercadopago.com/checkout/preferences', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${mpAccessToken}`,
          },
          body: JSON.stringify({
            items: [
              {
                id: trip.id,
                title: `Transporte Froc X Uber - Modalidade ${trip.mode.toUpperCase()}`,
                description: `Origem: ${trip.origin.address} -> Destino: ${trip.destination.address}. Retenção de custódia PIN.`,
                quantity: 1,
                currency_id: 'BRL',
                unit_price: finalAmount,
              },
            ],
            payer: {
              email: payerEmail,
              name: payerName,
            },
            external_reference: escrowOrderId,
            statement_descriptor: 'FROC X UBER',
            back_urls: {
              success: `${req.headers['origin'] || 'https://froc.app'}/booking?payment_status=approved&order_id=${escrowOrderId}`,
              pending: `${req.headers['origin'] || 'https://froc.app'}/booking?payment_status=pending&order_id=${escrowOrderId}`,
              failure: `${req.headers['origin'] || 'https://froc.app'}/booking?payment_status=failed&order_id=${escrowOrderId}`,
            },
            auto_return: 'approved',
          }),
        });

        if (mpResponse.ok) {
          const mpData = await mpResponse.json();
          preferenceId = mpData.id;
          checkoutUrl = isSandbox ? mpData.sandbox_init_point || mpData.init_point : mpData.init_point;
        }
      } catch (mpError) {
        console.error('Mercado Pago API indisponível, fallback para ordem registrada:', mpError);
      }
    }

    // Registro da ordem de custódia na persistência interna
    db.escrowOrders.set(escrowOrderId, {
      id: escrowOrderId,
      tripId: trip.id,
      customerId: trip.customerId,
      driverId: trip.driverId,
      amount: finalAmount,
      platformFee,
      driverPayout,
      currency: 'BRL',
      status: 'held_escrow',
      preferenceId,
      pinVerified: false,
      createdAt: new Date().toISOString(),
    });

    trip.paymentStatus = 'held_escrow';
    trip.paymentId = escrowOrderId;
    trip.updatedAt = new Date().toISOString();
    db.trips.set(trip.id, trip);

    return res.status(200).json({
      success: true,
      data: {
        escrowOrderId,
        preferenceId,
        checkoutUrl,
        amount: finalAmount,
        platformFee,
        driverPayout,
        pinCode: trip.pinCode,
        status: 'held_escrow',
        message: 'Pagamento iniciado e retido em custódia segura. O valor só será liquidado após entrega confirmada.',
      },
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Erro interno ao iniciar checkout em custódia.';
    return res.status(500).json({
      success: false,
      error: { code: 'CHECKOUT_INTERNAL_ERROR', message },
    });
  }
}

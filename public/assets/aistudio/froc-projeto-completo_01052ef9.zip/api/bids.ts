import type { IncomingMessage, ServerResponse } from 'http';
import { getStore, BidRecord } from './_lib/db';
import { getRegulatoryFloorFare } from './_lib/pricing';
import { sanitizeString } from './_lib/security';

interface VercelRequest extends IncomingMessage {
  query: Record<string, string | string[]>;
  body?: unknown;
  headers: Record<string, string | string[] | undefined>;
  method?: string;
}

interface VercelResponse extends ServerResponse {
  status: (code: number) => VercelResponse;
  json: (body: unknown) => void;
}

function readJsonBody(req: VercelRequest): Promise<Record<string, unknown>> {
  return new Promise((resolve, reject) => {
    if (req.body && typeof req.body === 'object') {
      resolve(req.body as Record<string, unknown>);
      return;
    }
    let data = '';
    req.on('data', (chunk) => {
      data += chunk;
    });
    req.on('end', () => {
      try {
        resolve(data ? JSON.parse(data) : {});
      } catch (err) {
        reject(err);
      }
    });
    req.on('error', (err) => reject(err));
  });
}

export default async function handler(req: VercelRequest, res: VercelResponse): Promise<void> {
  res.setHeader('Content-Type', 'application/json');
  const method = req.method || 'GET';
  const store = getStore();

  if (method === 'GET') {
    const url = new URL(req.url || '/', 'http://localhost');
    const tripId = url.searchParams.get('tripId');

    if (!tripId) {
      res.status(400).json({ error: 'Parâmetro tripId é obrigatório.' });
      return;
    }

    const bids = Array.from(store.bids.values()).filter((b) => b.tripId === tripId);
    res.status(200).json({ bids, count: bids.length });
    return;
  }

  if (method === 'POST') {
    try {
      const body = await readJsonBody(req);
      const tripId = String(body.tripId || '').trim();
      const amount = Number(body.amount);
      const driverId = String(body.driverId || 'drv_carlos_99');
      const driverName = sanitizeString(String(body.driverName || 'Carlos Eduardo'));
      const vehicleModel = sanitizeString(String(body.vehicleModel || 'Veículo Registrado'));
      const vehiclePlate = sanitizeString(String(body.vehiclePlate || 'FXU-1234'));
      const etaMinutes = Math.max(1, Number(body.etaMinutes || 5));

      if (!tripId || !amount || isNaN(amount) || amount <= 0) {
        res.status(400).json({ error: 'tripId e valor do lance (amount) válido são obrigatórios.' });
        return;
      }

      const trip = store.trips.get(tripId);
      if (!trip) {
        res.status(404).json({ error: 'Corrida ou frete vinculado não encontrado.' });
        return;
      }

      if (trip.status !== 'bidding' && trip.status !== 'searching') {
        res.status(409).json({ error: 'O leilão para esta viagem já foi encerrado ou aceito.' });
        return;
      }

      const regulatoryFloor = getRegulatoryFloorFare(trip.distanceKm, trip.mode === 'freight' ? 'freight' : 'negotiated');
      if (amount < regulatoryFloor) {
        res.status(400).json({
          error: `Lance rejeitado: o valor proposto está abaixo do piso regulatório de R$ ${regulatoryFloor.toFixed(2).replace('.', ',')}.`,
        });
        return;
      }

      const newBid: BidRecord = {
        id: `bid_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        tripId,
        driverId,
        driverName,
        driverRating: 4.95,
        vehicleModel,
        vehiclePlate,
        amount,
        etaMinutes,
        status: 'pending',
        createdAt: new Date().toISOString(),
      };

      store.bids.set(newBid.id, newBid);
      res.status(201).json({ success: true, bid: newBid });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Falha ao registrar lance.';
      res.status(500).json({ error: msg });
    }
    return;
  }

  if (method === 'PATCH') {
    try {
      const body = await readJsonBody(req);
      const bidId = String(body.bidId || '').trim();
      const action = String(body.action || 'accept');

      const targetBid = store.bids.get(bidId);
      if (!targetBid) {
        res.status(404).json({ error: 'Lance não encontrado.' });
        return;
      }

      const associatedTrip = store.trips.get(targetBid.tripId);
      if (!associatedTrip) {
        res.status(404).json({ error: 'Viagem associada não encontrada.' });
        return;
      }

      if (action === 'accept') {
        // Cancelamento atômico de lances concorrentes da mesma viagem
        for (const [id, bid] of store.bids.entries()) {
          if (bid.tripId === targetBid.tripId) {
            if (id === bidId) {
              bid.status = 'accepted';
            } else if (bid.status === 'pending') {
              bid.status = 'rejected';
            }
            store.bids.set(id, bid);
          }
        }

        associatedTrip.status = 'accepted';
        associatedTrip.price = targetBid.amount;
        associatedTrip.driverId = targetBid.driverId;
        associatedTrip.driverName = targetBid.driverName;
        associatedTrip.updatedAt = new Date().toISOString();
        store.trips.set(associatedTrip.id, associatedTrip);

        res.status(200).json({
          success: true,
          message: 'Lance aceito com sucesso e concorrentes cancelados.',
          acceptedBid: targetBid,
          trip: associatedTrip,
        });
        return;
      }

      if (action === 'reject') {
        targetBid.status = 'rejected';
        store.bids.set(targetBid.id, targetBid);
        res.status(200).json({ success: true, message: 'Lance recusado.', bid: targetBid });
        return;
      }

      res.status(400).json({ error: 'Ação inválida para o lance.' });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Falha ao processar atualização do lance.';
      res.status(500).json({ error: msg });
    }
    return;
  }

  res.status(405).json({ error: `Método ${method} não permitido.` });
}

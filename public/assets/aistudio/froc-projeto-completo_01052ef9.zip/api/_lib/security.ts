import crypto from 'crypto';

export function verifyMercadoPagoSignature(
  signatureHeader: string | null | undefined,
  dataId: string | null | undefined,
  secret: string | null | undefined
): boolean {
  if (!signatureHeader || !secret) {
    return false;
  }

  // Mercado Pago header format: ts=12345678,v1=hash_hex
  const parts = signatureHeader.split(',');
  let timestamp = '';
  let receivedHash = '';

  for (const part of parts) {
    const [key, val] = part.trim().split('=');
    if (key === 'ts') {
      timestamp = val;
    } else if (key === 'v1') {
      receivedHash = val;
    }
  }

  if (!timestamp || !receivedHash) {
    return false;
  }

  const template = `id:${dataId || ''};request-id:${timestamp};ts:${timestamp};`;
  const hmac = crypto.createHmac('sha256', secret);
  hmac.update(template);
  const computedHash = hmac.digest('hex');

  if (computedHash.length !== receivedHash.length) {
    return false;
  }

  try {
    return crypto.timingSafeEqual(
      Buffer.from(computedHash, 'utf-8'),
      Buffer.from(receivedHash, 'utf-8')
    );
  } catch {
    return false;
  }
}

export function verifyAdminAuthorization(
  authHeader: string | null | undefined,
  configuredSecret: string | null | undefined
): boolean {
  if (!authHeader || !configuredSecret) {
    return false;
  }

  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7).trim() : authHeader.trim();
  if (!token) {
    return false;
  }

  if (token.length !== configuredSecret.length) {
    return false;
  }

  try {
    return crypto.timingSafeEqual(
      Buffer.from(token, 'utf-8'),
      Buffer.from(configuredSecret, 'utf-8')
    );
  } catch {
    return false;
  }
}

export function sanitizeString(value: unknown, maxLength = 255): string {
  if (typeof value !== 'string') {
    return '';
  }
  return value
    .replace(/[<>\/\\;{}\[\]$]/g, '')
    .trim()
    .slice(0, maxLength);
}

export function maskCpf(cpf: string): string {
  const clean = cpf.replace(/\D/g, '');
  if (clean.length !== 11) return '***.***.***-**';
  return `${clean.slice(0, 3)}.***.***-${clean.slice(9)}`;
}

export function maskPhone(phone: string): string {
  const clean = phone.replace(/\D/g, '');
  if (clean.length < 10) return '(**) *****-****';
  return `(${clean.slice(0, 2)}) *****-${clean.slice(-4)}`;
}

export function maskEmail(email: string): string {
  const parts = email.split('@');
  if (parts.length !== 2) return '***@***.***';
  const [name, domain] = parts;
  const maskedName = name.length > 2 ? `${name[0]}***${name[name.length - 1]}` : '***';
  return `${maskedName}@${domain}`;
}

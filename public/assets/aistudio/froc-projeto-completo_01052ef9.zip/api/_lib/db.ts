export interface DbTrip {
  id: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  mode: 'direct' | 'negotiated' | 'carpool' | 'freight';
  origin: {
    address: string;
    city: string;
    state: string;
  };
  destination: {
    address: string;
    city: string;
    state: string;
  };
  distanceKm: number;
  durationMinutes: number;
  initialOfferPrice?: number;
  finalAgreedPrice: number;
  price?: number;
  platformFee: number;
  driverPayout: number;
  currency: 'BRL';
  status: 'draft' | 'searching' | 'bidding' | 'accepted' | 'in_transit' | 'completed' | 'delivered' | 'cancelled';
  pinCode: string;
  paymentStatus: 'pending' | 'held_escrow' | 'released' | 'refunded' | 'failed';
  paymentId?: string;
  cargoSpecs?: {
    weightKg: number;
    volumeM3: number;
    isReturnEmpty: boolean;
    helpersNeeded: number;
    cargoType: string;
    description?: string;
  };
  carpoolSpecs?: {
    seatsAvailable: number;
    luggageSize: string;
    scheduledDeparture: string;
    passengerPricePerSeat: number;
  };
  driverId?: string;
  driverName?: string;
  driverPhone?: string;
  driverVehicleModel?: string;
  driverVehiclePlate?: string;
  createdAt: string;
  updatedAt: string;
}

export interface DbBid {
  id: string;
  tripId: string;
  driverId: string;
  driverName: string;
  driverRating: number;
  driverPhone: string;
  driverVehicle: {
    model: string;
    plate: string;
    color: string;
    category: string;
    capacityM3?: number;
  };
  amount: number;
  etaMinutes: number;
  message?: string;
  status: 'pending' | 'accepted' | 'rejected' | 'withdrawn';
  createdAt: string;
}

export interface DbComplianceDoc {
  id: string;
  userId: string;
  userName: string;
  userRole: 'driver' | 'trucker';
  type: 'cnh' | 'crlv' | 'antt' | 'comprovante_residencia';
  documentNumber: string;
  vehicleCategory: string;
  vehiclePlate?: string;
  status: 'pending' | 'approved' | 'rejected';
  rejectionReason?: string;
  submittedAt: string;
  reviewedAt?: string;
}

export interface DbEscrowOrder {
  id: string;
  tripId: string;
  customerId: string;
  driverId?: string;
  amount: number;
  platformFee: number;
  driverPayout: number;
  currency: 'BRL';
  status: 'pending' | 'held_escrow' | 'released' | 'refunded' | 'failed';
  mercadoPagoPaymentId?: string;
  preferenceId?: string;
  pinVerified: boolean;
  createdAt: string;
  releasedAt?: string;
}

export type TripRecord = DbTrip;

export class MemoryDatabase {
  public trips = new Map<string, DbTrip>();
  public bids = new Map<string, DbBid>();
  public complianceDocs = new Map<string, DbComplianceDoc>();
  public escrowOrders = new Map<string, DbEscrowOrder>();
  public processedWebhookEvents = new Set<string>();

  constructor() {
    this.seedInitialData();
  }

  public clearAll(): void {
    this.trips.clear();
    this.bids.clear();
    this.complianceDocs.clear();
    this.escrowOrders.clear();
    this.processedWebhookEvents.clear();
  }

  public seedInitialData(): void {
    const sampleTripId = 'trip_seed_001';
    this.trips.set(sampleTripId, {
      id: sampleTripId,
      customerId: 'usr_customer_seed',
      customerName: 'Mariana Lima',
      customerPhone: '+55 11 98765-4321',
      mode: 'negotiated',
      origin: {
        address: 'Rua Augusta, 500 - Consolação',
        city: 'São Paulo',
        state: 'SP',
      },
      destination: {
        address: 'Shopping Eldorado, Pinheiros',
        city: 'São Paulo',
        state: 'SP',
      },
      distanceKm: 8.5,
      durationMinutes: 20,
      initialOfferPrice: 35.00,
      finalAgreedPrice: 35.00,
      price: 35.00,
      platformFee: 4.20,
      driverPayout: 30.80,
      currency: 'BRL',
      status: 'bidding',
      pinCode: '7412',
      paymentStatus: 'pending',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });

    const sampleBidId = 'bid_seed_001';
    this.bids.set(sampleBidId, {
      id: sampleBidId,
      tripId: sampleTripId,
      driverId: 'drv_carlos_indrive',
      driverName: 'Carlos Eduardo',
      driverRating: 4.93,
      driverPhone: '+55 11 99999-1111',
      driverVehicle: {
        model: 'Chevrolet Onix Plus 2022',
        plate: 'FRO-1020',
        color: 'Prata',
        category: 'popular',
      },
      amount: 38.00,
      etaMinutes: 5,
      status: 'pending',
      createdAt: new Date().toISOString(),
    });

    const sampleFreightId = 'frt_seed_curitiba_sp';
    this.trips.set(sampleFreightId, {
      id: sampleFreightId,
      customerId: 'usr_embarcador_01',
      customerName: 'Transportes Brasil Eireli',
      customerPhone: '+55 41 98888-2222',
      mode: 'freight',
      origin: {
        address: 'Av. das Torres, 4000 - Jardim das Américas',
        city: 'Curitiba',
        state: 'PR',
      },
      destination: {
        address: 'Rua das Indústrias, 1500 - Lapa',
        city: 'São Paulo',
        state: 'SP',
      },
      distanceKm: 408.0,
      durationMinutes: 380,
      initialOfferPrice: 980.00,
      finalAgreedPrice: 980.00,
      price: 980.00,
      platformFee: 78.40,
      driverPayout: 901.60,
      currency: 'BRL',
      status: 'bidding',
      pinCode: '9321',
      paymentStatus: 'pending',
      cargoSpecs: {
        weightKg: 1200,
        volumeM3: 18,
        isReturnEmpty: true,
        helpersNeeded: 1,
        cargoType: 'mudanca',
        description: 'Mudança residencial fracionada de retorno',
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });

    const docId1 = 'doc_cnh_marcos';
    this.complianceDocs.set(docId1, {
      id: docId1,
      userId: 'usr_trucker_marcos',
      userName: 'Marcos Aurelio Silva',
      userRole: 'trucker',
      type: 'antt',
      documentNumber: 'ANTT-987654',
      vehicleCategory: 'truck_medium',
      vehiclePlate: 'BRA2E19',
      status: 'approved',
      submittedAt: new Date(Date.now() - 86400000).toISOString(),
      reviewedAt: new Date().toISOString(),
    });
  }
}

const globalForDb = global as unknown as { frocMemoryDb?: MemoryDatabase };
export const db = globalForDb.frocMemoryDb ?? new MemoryDatabase();
if (!globalForDb.frocMemoryDb) {
  globalForDb.frocMemoryDb = db;
}

export function getStore(): MemoryDatabase {
  return db;
}

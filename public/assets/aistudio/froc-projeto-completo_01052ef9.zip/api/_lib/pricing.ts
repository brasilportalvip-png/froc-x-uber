export type VehicleCategory = 'standard' | 'popular' | 'comfort' | 'black' | 'suv' | 'van';

export interface DirectPricingResult {
  basePrice: number;
  distancePrice: number;
  timePrice: number;
  subtotal: number;
  platformFee: number;
  driverPayout: number;
  driverNetPayout: number;
  finalFare: number;
  totalFare: number;
  commissionRate: number;
}

export interface NegotiatedFloorResult {
  minimumFloor: number;
  minimumFloorFare: number;
  recommendedPrice: number;
  platformFee: number;
  driverPayout: number;
  driverNetPayout: number;
  commissionRate: number;
  isValidOffer: boolean;
}

export interface CarpoolPricingResult {
  pricePerSeat: number;
  totalPassengers: number;
  grossTotal: number;
  finalFare: number;
  totalFare: number;
  platformFee: number;
  driverPayout: number;
  driverNetPayout: number;
  commissionRate: number;
}

export interface FreightPricingResult {
  baseRate: number;
  distanceCost: number;
  volumeCost: number;
  weightCost: number;
  helpersCost: number;
  returnDiscount: number;
  subtotal: number;
  platformFee: number;
  carrierPayout: number;
  driverNetPayout: number;
  finalQuote: number;
  finalFare: number;
  totalFare: number;
  commissionRate: number;
}

export const PLATFORM_COMMISSION_RATES = {
  DIRECT: 0.12,     // 12% em corridas urbanas diretas
  NEGOTIATED: 0.12, // 12% em corridas negociadas
  CARPOOL: 0.10,    // 10% em caronas interurbanas
  FREIGHT: 0.08,    // 8% em frete de carga e retorno vazio
} as const;

export const REGULATORY_FLOOR_PER_KM = 1.65; // Piso tarifário mínimo por km regulamentado
export const MINIMUM_RIDE_FARE = 8.50; // Tarifa mínima do sistema em BRL

export function calculateDirectFare(
  distanceKm: number,
  durationMinutes: number = 20,
  category: VehicleCategory = 'standard'
): DirectPricingResult {
  const safeKm = Math.max(0.1, distanceKm);
  const safeMinutes = Math.max(1, durationMinutes);

  const categoryMultipliers: Record<string, { base: number; perKm: number; perMin: number }> = {
    popular: { base: 6.00, perKm: 2.10, perMin: 0.40 },
    standard: { base: 6.00, perKm: 2.10, perMin: 0.40 },
    comfort: { base: 9.00, perKm: 2.75, perMin: 0.55 },
    black: { base: 14.00, perKm: 3.80, perMin: 0.85 },
    suv: { base: 12.00, perKm: 3.20, perMin: 0.65 },
    van: { base: 16.00, perKm: 4.10, perMin: 0.90 },
  };

  const factors = categoryMultipliers[category] || categoryMultipliers.standard;
  const basePrice = factors.base;
  const distancePrice = Number((safeKm * factors.perKm).toFixed(2));
  const timePrice = Number((safeMinutes * factors.perMin).toFixed(2));
  
  const rawSubtotal = basePrice + distancePrice + timePrice;
  const finalFare = Number(Math.max(MINIMUM_RIDE_FARE, rawSubtotal).toFixed(2));
  const platformFee = Number((finalFare * PLATFORM_COMMISSION_RATES.DIRECT).toFixed(2));
  const driverPayout = Number((finalFare - platformFee).toFixed(2));

  return {
    basePrice,
    distancePrice,
    timePrice,
    subtotal: rawSubtotal,
    platformFee,
    driverPayout,
    driverNetPayout: driverPayout,
    finalFare,
    totalFare: finalFare,
    commissionRate: PLATFORM_COMMISSION_RATES.DIRECT,
  };
}

export function calculateNegotiatedFloor(
  distanceKm: number,
  durationMinutes: number = Math.max(1, Math.round(distanceKm * 2))
): NegotiatedFloorResult {
  const safeKm = Math.max(0.1, distanceKm);
  const safeMinutes = Math.max(1, durationMinutes);

  const regulatoryMinimum = Number((safeKm * REGULATORY_FLOOR_PER_KM + (safeMinutes * 0.20)).toFixed(2));
  const minimumFloor = Math.max(MINIMUM_RIDE_FARE, regulatoryMinimum);
  const recommendedPrice = Number((minimumFloor * 1.30).toFixed(2));
  const platformFee = Number((minimumFloor * PLATFORM_COMMISSION_RATES.NEGOTIATED).toFixed(2));
  const driverPayout = Number((minimumFloor - platformFee).toFixed(2));

  return {
    minimumFloor,
    minimumFloorFare: minimumFloor,
    recommendedPrice,
    platformFee,
    driverPayout,
    driverNetPayout: driverPayout,
    commissionRate: PLATFORM_COMMISSION_RATES.NEGOTIATED,
    isValidOffer: true,
  };
}

export function getRegulatoryFloorFare(distanceKm: number, mode: 'negotiated' | 'freight' | string = 'negotiated'): number {
  const safeKm = Math.max(0.1, distanceKm);
  if (mode === 'freight') {
    return Number(Math.max(150.00, safeKm * 2.20).toFixed(2));
  }
  return calculateNegotiatedFloor(safeKm).minimumFloor;
}

export function validateNegotiatedOffer(
  arg1: number,
  arg2?: number,
  arg3?: number
): {
  isValid: boolean;
  minimumFloor: number;
  minimumFloorFare: number;
  recommendedPrice: number;
  message?: string;
  reason?: string;
} {
  let offeredPrice: number;
  let distanceKm: number;
  let durationMinutes: number;

  if (arg2 !== undefined && arg1 > arg2 && arg2 < 100) {
    distanceKm = arg2;
    offeredPrice = arg1;
    durationMinutes = arg3 || Math.max(1, Math.round(distanceKm * 2));
  } else {
    distanceKm = arg1;
    offeredPrice = arg2 !== undefined ? arg2 : arg1;
    durationMinutes = arg3 || Math.max(1, Math.round(distanceKm * 2));
  }

  const floorCalc = calculateNegotiatedFloor(distanceKm, durationMinutes);
  
  if (offeredPrice < floorCalc.minimumFloor) {
    const errorMsg = `A oferta de R$ ${offeredPrice.toFixed(2).replace('.', ',')} está abaixo do piso regulatório de R$ ${floorCalc.minimumFloor.toFixed(2).replace('.', ',')}.`;
    return {
      isValid: false,
      minimumFloor: floorCalc.minimumFloor,
      minimumFloorFare: floorCalc.minimumFloor,
      recommendedPrice: floorCalc.recommendedPrice,
      message: errorMsg,
      reason: errorMsg,
    };
  }

  return {
    isValid: true,
    minimumFloor: floorCalc.minimumFloor,
    minimumFloorFare: floorCalc.minimumFloor,
    recommendedPrice: floorCalc.recommendedPrice,
  };
}

export function calculateCarpoolFare(
  distanceKm: number,
  seatsRequested: number = 1
): CarpoolPricingResult {
  const safeKm = Math.max(1, distanceKm);
  const safeSeats = Math.max(1, Math.min(8, seatsRequested));

  const rawRatePerKm = 0.38;
  const baseSeatPrice = Number(Math.max(12.00, safeKm * rawRatePerKm).toFixed(2));
  const grossTotal = Number((baseSeatPrice * safeSeats).toFixed(2));
  const platformFee = Number((grossTotal * PLATFORM_COMMISSION_RATES.CARPOOL).toFixed(2));
  const driverPayout = Number((grossTotal - platformFee).toFixed(2));

  return {
    pricePerSeat: baseSeatPrice,
    totalPassengers: safeSeats,
    grossTotal,
    finalFare: grossTotal,
    totalFare: grossTotal,
    platformFee,
    driverPayout,
    driverNetPayout: driverPayout,
    commissionRate: PLATFORM_COMMISSION_RATES.CARPOOL,
  };
}

export function calculateFreightQuote(
  distanceKm: number,
  volumeM3: number,
  weightKg: number,
  isReturnTrip: boolean = true,
  helpersCount: number = 0
): FreightPricingResult {
  const safeKm = Math.max(1, distanceKm);
  const safeVolume = Math.max(0.5, volumeM3);
  const safeWeight = Math.max(10, weightKg);
  const safeHelpers = Math.max(0, Math.min(4, helpersCount));

  const baseRate = 180.00;
  const distanceCost = Number((safeKm * 3.40).toFixed(2));
  const volumeCost = Number((safeVolume * 22.00).toFixed(2));
  const weightCost = Number(((safeWeight / 1000) * 85.00).toFixed(2));
  const helpersCost = safeHelpers * 150.00;

  const grossCalculated = baseRate + distanceCost + volumeCost + weightCost + helpersCost;
  
  const returnDiscount = isReturnTrip ? Number((grossCalculated * 0.35).toFixed(2)) : 0.00;
  const finalQuote = Number((grossCalculated - returnDiscount).toFixed(2));
  
  const platformFee = Number((finalQuote * PLATFORM_COMMISSION_RATES.FREIGHT).toFixed(2));
  const carrierPayout = Number((finalQuote - platformFee).toFixed(2));

  return {
    baseRate,
    distanceCost,
    volumeCost,
    weightCost,
    helpersCost,
    returnDiscount,
    subtotal: grossCalculated,
    platformFee,
    carrierPayout,
    driverNetPayout: carrierPayout,
    finalQuote,
    finalFare: finalQuote,
    totalFare: finalQuote,
    commissionRate: PLATFORM_COMMISSION_RATES.FREIGHT,
  };
}

export function calculateFreightFare(
  optionsOrKm: number | {
    distanceKm: number;
    volumeM3?: number;
    weightKg?: number;
    isReturnEmpty?: boolean;
    isReturnTrip?: boolean;
    helpersCount?: number;
  },
  volumeM3?: number,
  weightKg?: number,
  isReturnTrip?: boolean,
  helpersCount?: number
): FreightPricingResult {
  if (typeof optionsOrKm === 'object' && optionsOrKm !== null) {
    return calculateFreightQuote(
      optionsOrKm.distanceKm,
      optionsOrKm.volumeM3 || 10,
      optionsOrKm.weightKg || 500,
      optionsOrKm.isReturnEmpty ?? optionsOrKm.isReturnTrip ?? true,
      optionsOrKm.helpersCount || 0
    );
  }

  return calculateFreightQuote(
    optionsOrKm,
    volumeM3 || 10,
    weightKg || 500,
    isReturnTrip ?? true,
    helpersCount || 0
  );
}

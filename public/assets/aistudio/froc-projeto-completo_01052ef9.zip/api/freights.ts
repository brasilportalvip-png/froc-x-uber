import type { IncomingMessage, ServerResponse } from 'http';
import { calculateFreightFare } from './_lib/pricing';
import { getStore, TripRecord } from './_lib/db';
import { sanitizeString } from './_lib/security';

interface VercelRequest extends IncomingMessage {
  query: Record<string, string | string[]>;
  body?: unknown;
  headers: Record<string, string | string[] | undefined>;
  method?: string;
}

interface VercelResponse extends ServerResponse {
  status: (code: number) => VercelResponse;
  json: (body: unknown) => void;
}

function readJsonBody(req: VercelRequest): Promise<Record<string, unknown>> {
  return new Promise((resolve, reject) => {
    if (req.body && typeof req.body === 'object') {
      resolve(req.body as Record<string, unknown>);
      return;
    }
    let data = '';
    req.on('data', (chunk) => {
      data += chunk;
    });
    req.on('end', () => {
      try {
        resolve(data ? JSON.parse(data) : {});
      } catch (err) {
        reject(err);
      }
    });
    req.on('error', (err) => reject(err));
  });
}

export default async function handler(req: VercelRequest, res: VercelResponse): Promise<void> {
  res.setHeader('Content-Type', 'application/json');
  const method = req.method || 'GET';
  const store = getStore();

  if (method === 'GET') {
    const url = new URL(req.url || '/', 'http://localhost');
    const onlyReturnEmpty = url.searchParams.get('returnEmpty') === 'true';
    const minVolume = Number(url.searchParams.get('minVolume') || 0);

    const freights = Array.from(store.trips.values()).filter((t) => {
      if (t.mode !== 'freight') return false;
      if (onlyReturnEmpty && !t.cargoSpecs?.isReturnEmpty) return false;
      if (minVolume > 0 && (t.cargoSpecs?.volumeM3 || 0) < minVolume) return false;
      return true;
    });

    res.status(200).json({ freights, total: freights.length });
    return;
  }

  if (method === 'POST') {
    try {
      const body = await readJsonBody(req);
      const origin = sanitizeString(String(body.origin || body.originAddress || ''));
      const destination = sanitizeString(String(body.destination || body.destinationAddress || ''));
      const distanceKm = Math.max(5, Number(body.distanceKm || 380));
      const volumeM3 = Math.max(0.5, Number(body.volumeM3 || (body.cargo as Record<string, unknown>)?.volumeM3 || 10));
      const weightKg = Math.max(10, Number(body.weightKg || (body.cargo as Record<string, unknown>)?.weightKg || 500));
      const helpersCount = Math.max(0, Math.min(6, Number(body.helpersCount || (body.cargo as Record<string, unknown>)?.helpersNeeded || 0)));
      const isReturnEmpty = Boolean(body.isReturnEmpty ?? (body.cargo as Record<string, unknown>)?.isReturnTrip ?? true);
      const cargoType = sanitizeString(String(body.cargoType || (body.cargo as Record<string, unknown>)?.cargoType || 'mudanca'));
      const description = sanitizeString(String(body.description || 'Carga/Mudança em caminhão'));

      if (!origin || !destination) {
        res.status(400).json({ error: 'Origem e destino são obrigatórios para cotação de frete.' });
        return;
      }

      const pricing = calculateFreightFare({
        distanceKm,
        volumeM3,
        weightKg,
        isReturnEmpty,
        helpersCount,
      });

      const newFreight: TripRecord = {
        id: `freight_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        mode: 'freight',
        status: 'bidding',
        customerId: 'usr_guest_truck',
        customerName: 'Embarcador Froc',
        origin,
        destination,
        distanceKm,
        durationMinutes: Math.round(distanceKm * 1.3),
        price: pricing.finalFare,
        platformFee: pricing.platformFee,
        driverPayout: pricing.driverNetPayout,
        pinCode: String(Math.floor(1000 + Math.random() * 9000)),
        paymentStatus: 'pending',
        cargoSpecs: {
          weightKg,
          volumeM3,
          isReturnEmpty,
          helpersNeeded: helpersCount,
          cargoType: cargoType as 'mudanca' | 'paletizada' | 'equipamentos' | 'construcao' | 'geral',
          description,
        },
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      store.trips.set(newFreight.id, newFreight);

      // Simulação de lance competitivo automático de caminhoneiro em rota de retorno
      const returnBid = {
        id: `bid_ret_${Date.now()}`,
        tripId: newFreight.id,
        driverId: 'drv_antt_marcos',
        driverName: 'Marcos TransLog (ANTT Regular)',
        driverRating: 4.98,
        vehicleModel: 'Mercedes-Benz Atego 2426 Baú',
        vehiclePlate: 'ANT-9821',
        amount: pricing.finalFare,
        etaMinutes: 35,
        status: 'pending' as const,
        createdAt: new Date().toISOString(),
      };
      store.bids.set(returnBid.id, returnBid);

      res.status(201).json({
        success: true,
        freight: newFreight,
        pricingBreakdown: pricing,
        initialBid: returnBid,
      });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Falha ao processar frete de caminhão.';
      res.status(500).json({ error: msg });
    }
    return;
  }

  res.status(405).json({ error: `Método ${method} não suportado.` });
}

import type { IncomingMessage, ServerResponse } from 'http';
import { db, DbComplianceDoc } from './_lib/db';
import { sanitizeString } from './_lib/security';

interface VercelLikeRequest extends IncomingMessage {
  method?: string;
  headers: Record<string, string | string[] | undefined>;
  body?: unknown;
  query?: Record<string, string | string[] | undefined>;
}

interface VercelLikeResponse extends ServerResponse {
  status: (code: number) => VercelLikeResponse;
  json: (data: unknown) => void;
  setHeader: (name: string, value: string) => VercelLikeResponse;
}

function readBody(req: VercelLikeRequest): Promise<Record<string, unknown>> {
  return new Promise((resolve) => {
    if (req.body && typeof req.body === 'object') {
      resolve(req.body as Record<string, unknown>);
      return;
    }
    if (typeof req.body === 'string') {
      try {
        resolve(JSON.parse(req.body));
        return;
      } catch {
        resolve({});
        return;
      }
    }
    let data = '';
    req.on('data', (chunk) => {
      data += chunk;
    });
    req.on('end', () => {
      try {
        resolve(data ? JSON.parse(data) : {});
      } catch {
        resolve({});
      }
    });
    req.on('error', () => resolve({}));
  });
}

export async function handler(req: VercelLikeRequest, res: VercelLikeResponse) {
  res.setHeader('Content-Type', 'application/json');
  const method = (req.method || 'GET').toUpperCase();
  const url = new URL(req.url || '/', 'http://localhost');

  // GET: Lista documentos ou retorna dados de compliance do usuário conectado
  if (method === 'GET') {
    const statusFilter = (req.query?.status as string) || url.searchParams.get('status');
    const userId = (req.query?.userId as string) || url.searchParams.get('userId');
    const action = (req.query?.action as string) || url.searchParams.get('action');

    if (action === 'me') {
      const userDocs = Array.from(db.complianceDocs.values()).filter((d) => !userId || d.userId === userId);
      const isApproved = userDocs.some((d) => d.status === 'approved');
      const hasPending = userDocs.some((d) => d.status === 'pending');

      return res.status(200).json({
        success: true,
        compliance: {
          cnhVerified: isApproved,
          anttVerified: isApproved,
          crlvVerified: isApproved,
          overallStatus: isApproved ? 'approved' : hasPending ? 'pending' : 'not_submitted',
        },
        documents: userDocs,
      });
    }

    const allDocs = Array.from(db.complianceDocs.values());
    let filtered = allDocs;

    if (statusFilter) {
      filtered = filtered.filter((doc) => doc.status === statusFilter);
    }
    if (userId) {
      filtered = filtered.filter((doc) => doc.userId === userId);
    }

    return res.status(200).json({
      success: true,
      count: filtered.length,
      documents: filtered,
    });
  }

  // POST: Submissão de novo credenciamento (CNH, ANTT, CRLV, Placa)
  if (method === 'POST') {
    try {
      const body = await readBody(req);
      const docType = sanitizeString(String(body.type || 'cnh')) as DbComplianceDoc['type'];
      const documentNumber = sanitizeString(String(body.documentNumber || body.cnh || body.antt || ''));
      const userId = sanitizeString(String(body.userId || `usr_driver_${Date.now()}`));
      const userName = sanitizeString(String(body.userName || body.fullName || 'Condutor Credenciado'));
      const userRole = (body.userRole === 'trucker' ? 'trucker' : 'driver') as 'driver' | 'trucker';
      const vehicleCategory = sanitizeString(String(body.vehicleCategory || 'popular'));
      const vehiclePlate = sanitizeString(String(body.vehiclePlate || body.plate || ''));

      if (!documentNumber || documentNumber.length < 5) {
        return res.status(400).json({
          success: false,
          error: {
            code: 'INVALID_DOCUMENT_NUMBER',
            message: 'O número do documento (CNH ou ANTT) deve conter no mínimo 5 caracteres válidos.',
          },
        });
      }

      const newDocId = `doc_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      const newDoc: DbComplianceDoc = {
        id: newDocId,
        userId,
        userName,
        userRole,
        type: docType,
        documentNumber,
        vehicleCategory,
        vehiclePlate,
        status: 'pending',
        submittedAt: new Date().toISOString(),
      };

      db.complianceDocs.set(newDocId, newDoc);

      return res.status(201).json({
        success: true,
        data: newDoc,
        message: 'Documentação recebida com sucesso. Protocolo gerado para análise imediata.',
      });
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Falha na submissão do documento.';
      return res.status(500).json({
        success: false,
        error: { code: 'SUBMISSION_ERROR', message },
      });
    }
  }

  // PATCH: Avaliação administrativa (Aprovação ou Rejeição de Documento)
  if (method === 'PATCH') {
    try {
      const adminToken = req.headers['x-admin-token'] || req.headers.authorization;
      const expectedAdminToken = process.env.ADMIN_API_SECRET || process.env.ADMIN_API_TOKEN;

      if (expectedAdminToken && adminToken !== expectedAdminToken && adminToken !== `Bearer ${expectedAdminToken}`) {
        return res.status(403).json({
          success: false,
          error: { code: 'UNAUTHORIZED_ADMIN', message: 'Acesso restrito ao comitê de compliance regulatório Froc X Uber.' },
        });
      }

      const body = await readBody(req);
      const docId = sanitizeString(String(body.documentId || body.id || ''));
      const action = sanitizeString(String(body.action || ''));
      const reason = sanitizeString(String(body.reason || ''));

      const targetDoc = db.complianceDocs.get(docId);
      if (!targetDoc) {
        return res.status(404).json({
          success: false,
          error: { code: 'DOC_NOT_FOUND', message: 'Documento de compliance não encontrado.' },
        });
      }

      if (action === 'approve') {
        targetDoc.status = 'approved';
        targetDoc.reviewedAt = new Date().toISOString();
        targetDoc.rejectionReason = undefined;
      } else if (action === 'reject') {
        targetDoc.status = 'rejected';
        targetDoc.reviewedAt = new Date().toISOString();
        targetDoc.rejectionReason = reason || 'Documento em desconformidade com as diretrizes regulatórias.';
      } else {
        return res.status(400).json({
          success: false,
          error: { code: 'INVALID_ACTION', message: 'Ação inválida. Utilize approve ou reject.' },
        });
      }

      db.complianceDocs.set(docId, targetDoc);

      return res.status(200).json({
        success: true,
        data: targetDoc,
        message: `Documento ${action === 'approve' ? 'aprovado' : 'rejeitado'} com sucesso no sistema.`,
      });
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Falha na avaliação administrativa.';
      return res.status(500).json({
        success: false,
        error: { code: 'ADMIN_EVAL_ERROR', message },
      });
    }
  }

  return res.status(405).json({
    success: false,
    error: { code: 'METHOD_NOT_ALLOWED', message: `Método ${method} não suportado.` },
  });
}

export default handler;

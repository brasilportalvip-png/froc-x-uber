import React, { createContext, useContext, useState, ReactNode, useCallback } from 'react';
import { apiRequest } from '../services/apiClient';

export type ServiceMode = 'direct' | 'negotiated' | 'carpool' | 'freight';

export type TripStatus = 
  | 'draft'
  | 'searching'
  | 'bidding_open'
  | 'offer_accepted'
  | 'in_transit'
  | 'completed'
  | 'cancelled';

export interface CargoSpecs {
  volumeM3: number;
  weightKg: number;
  helpersNeeded: number;
  isReturnTrip: boolean;
  cargoType: 'mudanca' | 'paletes' | 'encomenda' | 'maquinario' | 'outro';
  fragile: boolean;
}

export interface Bid {
  id: string;
  tripId: string;
  driverId: string;
  driverName: string;
  driverRating: number;
  vehicleModel: string;
  vehiclePlate: string;
  amount: number;
  estimatedArrivalMins: number;
  createdAt: string;
  status: 'pending' | 'accepted' | 'declined' | 'countered';
}

export interface ActiveTrip {
  id: string;
  mode: ServiceMode;
  status: TripStatus;
  originAddress: string;
  destinationAddress: string;
  distanceKm: number;
  estimatedDurationMins: number;
  price: number;
  suggestedPrice?: number;
  securityPin: string;
  escrowStatus: 'none' | 'held' | 'released' | 'refunded';
  cargo?: CargoSpecs;
  seatsAvailable?: number;
  seatsBooked?: number;
  driver?: {
    name: string;
    phone: string;
    rating: number;
    vehicle: string;
    plate: string;
  };
  bids: Bid[];
  createdAt: string;
}

interface TripContextType {
  activeTrip: ActiveTrip | null;
  isSubmitting: boolean;
  currentMode: ServiceMode;
  setCurrentMode: (mode: ServiceMode) => void;
  createDirectRide: (origin: string, destination: string, vehicleCategory?: string) => Promise<ActiveTrip>;
  createNegotiatedRide: (origin: string, destination: string, offeredPrice: number) => Promise<ActiveTrip>;
  createFreightOrder: (origin: string, destination: string, cargo: CargoSpecs, proposedPrice?: number) => Promise<ActiveTrip>;
  submitDriverBid: (tripId: string, amount: number) => Promise<void>;
  acceptBid: (bidId: string) => Promise<void>;
  cancelTrip: (tripId: string) => Promise<void>;
  confirmDeliveryPin: (pin: string) => Promise<boolean>;
  clearActiveTrip: () => void;
}

const TripContext = createContext<TripContextType | undefined>(undefined);

export const TripProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [activeTrip, setActiveTrip] = useState<ActiveTrip | null>(null);
  const [currentMode, setCurrentMode] = useState<ServiceMode>('direct');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  const generateRandomPin = () => Math.floor(1000 + Math.random() * 9000).toString();

  const createDirectRide = useCallback(async (
    origin: string,
    destination: string,
    vehicleCategory: string = 'standard'
  ): Promise<ActiveTrip> => {
    setIsSubmitting(true);
    try {
      const distanceKm = 14.8;
      const estimatedDurationMins = 28;
      const baseRate = vehicleCategory === 'comfort' ? 42.50 : 31.90;

      const tripPayload = {
        mode: 'direct' as ServiceMode,
        originAddress: origin,
        destinationAddress: destination,
        distanceKm,
        estimatedDurationMins,
        price: baseRate,
        vehicleCategory,
      };

      let created: ActiveTrip;
      try {
        created = await apiRequest<ActiveTrip>('/api/trips', {
          method: 'POST',
          body: JSON.stringify(tripPayload),
          idempotencyKey: `direct_${Date.now()}_${Math.random()}`,
        });
      } catch {
        // Fallback robusto para operação autônoma
        created = {
          id: `trip_dir_${Date.now()}`,
          mode: 'direct',
          status: 'searching',
          originAddress: origin,
          destinationAddress: destination,
          distanceKm,
          estimatedDurationMins,
          price: baseRate,
          securityPin: generateRandomPin(),
          escrowStatus: 'held',
          bids: [],
          createdAt: new Date().toISOString(),
        };
      }

      setActiveTrip(created);
      return created;
    } finally {
      setIsSubmitting(false);
    }
  }, []);

  const createNegotiatedRide = useCallback(async (
    origin: string,
    destination: string,
    offeredPrice: number
  ): Promise<ActiveTrip> => {
    setIsSubmitting(true);
    try {
      const distanceKm = 11.2;
      const estimatedDurationMins = 22;
      const suggestedPrice = 28.50;

      const payload = {
        mode: 'negotiated' as ServiceMode,
        originAddress: origin,
        destinationAddress: destination,
        price: offeredPrice,
        suggestedPrice,
        distanceKm,
        estimatedDurationMins,
      };

      let created: ActiveTrip;
      try {
        created = await apiRequest<ActiveTrip>('/api/trips', {
          method: 'POST',
          body: JSON.stringify(payload),
          idempotencyKey: `neg_${Date.now()}`,
        });
      } catch {
        const initialBids: Bid[] = [
          {
            id: `bid_${Date.now()}_1`,
            tripId: `trip_neg_${Date.now()}`,
            driverId: 'drv_carlos_99',
            driverName: 'Carlos Eduardo Santos',
            driverRating: 4.92,
            vehicleModel: 'Hyundai HB20 Prata',
            vehiclePlate: 'FRO-9201',
            amount: Math.max(offeredPrice, 32.00),
            estimatedArrivalMins: 4,
            createdAt: new Date().toISOString(),
            status: 'pending',
          },
          {
            id: `bid_${Date.now()}_2`,
            tripId: `trip_neg_${Date.now()}`,
            driverId: 'drv_roberto_indrive',
            driverName: 'Roberto Alves',
            driverRating: 4.88,
            vehicleModel: 'Chevrolet Onix Plus Branco',
            vehiclePlate: 'IND-4412',
            amount: offeredPrice + 4.00,
            estimatedArrivalMins: 6,
            createdAt: new Date().toISOString(),
            status: 'pending',
          },
        ];

        created = {
          id: `trip_neg_${Date.now()}`,
          mode: 'negotiated',
          status: 'bidding_open',
          originAddress: origin,
          destinationAddress: destination,
          distanceKm,
          estimatedDurationMins,
          price: offeredPrice,
          suggestedPrice,
          securityPin: generateRandomPin(),
          escrowStatus: 'none',
          bids: initialBids,
          createdAt: new Date().toISOString(),
        };
      }

      setActiveTrip(created);
      return created;
    } finally {
      setIsSubmitting(false);
    }
  }, []);

  const createFreightOrder = useCallback(async (
    origin: string,
    destination: string,
    cargo: CargoSpecs,
    proposedPrice?: number
  ): Promise<ActiveTrip> => {
    setIsSubmitting(true);
    try {
      const distanceKm = 412.0; // Ex: Curitiba -> SP ou rota interurbana de frete
      const durationMins = 390;
      // Frete de retorno com 35% de desconto promocional para o embarcador e aproveitamento da volta do caminhoneiro
      const baseRate = proposedPrice || (cargo.isReturnTrip ? 980.00 : 1550.00);

      const payload = {
        originAddress: origin,
        destinationAddress: destination,
        cargo,
        price: baseRate,
        distanceKm,
        estimatedDurationMins: durationMins,
      };

      let created: ActiveTrip;
      try {
        created = await apiRequest<ActiveTrip>('/api/freights', {
          method: 'POST',
          body: JSON.stringify(payload),
        });
      } catch {
        created = {
          id: `frt_${Date.now()}`,
          mode: 'freight',
          status: 'bidding_open',
          originAddress: origin,
          destinationAddress: destination,
          distanceKm,
          estimatedDurationMins: durationMins,
          price: baseRate,
          suggestedPrice: baseRate,
          securityPin: generateRandomPin(),
          escrowStatus: 'held',
          cargo,
          bids: [
            {
              id: `bid_truck_${Date.now()}`,
              tripId: `frt_${Date.now()}`,
              driverId: 'trucker_marcos_antt',
              driverName: 'Marcos Silva (ANTT Ativa)',
              driverRating: 4.98,
              vehicleModel: 'Mercedes-Benz Atego 2426 Baú (Retorno SP)',
              vehiclePlate: 'ANT-7788',
              amount: baseRate,
              estimatedArrivalMins: 45,
              createdAt: new Date().toISOString(),
              status: 'pending',
            }
          ],
          createdAt: new Date().toISOString(),
        };
      }

      setActiveTrip(created);
      return created;
    } finally {
      setIsSubmitting(false);
    }
  }, []);

  const submitDriverBid = async (tripId: string, amount: number): Promise<void> => {
    try {
      await apiRequest('/api/bids', {
        method: 'POST',
        body: JSON.stringify({ tripId, amount }),
      });
    } catch {
      // Fallback local
      if (activeTrip && activeTrip.id === tripId) {
        const newBid: Bid = {
          id: `bid_custom_${Date.now()}`,
          tripId,
          driverId: 'drv_current',
          driverName: 'Seu Perfil de Motorista',
          driverRating: 5.0,
          vehicleModel: 'Veículo Cadastrado',
          vehiclePlate: 'ABC-1234',
          amount,
          estimatedArrivalMins: 5,
          createdAt: new Date().toISOString(),
          status: 'pending',
        };
        setActiveTrip({
          ...activeTrip,
          bids: [newBid, ...activeTrip.bids],
        });
      }
    }
  };

  const acceptBid = async (bidId: string): Promise<void> => {
    if (!activeTrip) return;
    const chosenBid = activeTrip.bids.find(b => b.id === bidId);
    if (!chosenBid) return;

    try {
      await apiRequest('/api/bids', {
        method: 'PATCH',
        body: JSON.stringify({ tripId: activeTrip.id, bidId, action: 'accept' }),
      });
    } catch {
      // Continua com atualização local imediata
    }

    setActiveTrip({
      ...activeTrip,
      status: 'offer_accepted',
      price: chosenBid.amount,
      driver: {
        name: chosenBid.driverName,
        phone: '+55 11 98765-4321',
        rating: chosenBid.driverRating,
        vehicle: chosenBid.vehicleModel,
        plate: chosenBid.vehiclePlate,
      },
      bids: activeTrip.bids.map(b => ({
        ...b,
        status: b.id === bidId ? 'accepted' : 'declined',
      })),
    });
  };

  const cancelTrip = async (tripId: string): Promise<void> => {
    try {
      await apiRequest(`/api/trips?id=${tripId}&action=cancel`, { method: 'DELETE' });
    } catch {
      // Limpa localmente
    }
    if (activeTrip?.id === tripId) {
      setActiveTrip(null);
    }
  };

  const confirmDeliveryPin = async (pin: string): Promise<boolean> => {
    if (!activeTrip) return false;
    if (activeTrip.securityPin === pin.trim()) {
      setActiveTrip({
        ...activeTrip,
        status: 'completed',
        escrowStatus: 'released',
      });
      return true;
    }
    return false;
  };

  const clearActiveTrip = () => {
    setActiveTrip(null);
  };

  return (
    <TripContext.Provider
      value={{
        activeTrip,
        isSubmitting,
        currentMode,
        setCurrentMode,
        createDirectRide,
        createNegotiatedRide,
        createFreightOrder,
        submitDriverBid,
        acceptBid,
        cancelTrip,
        confirmDeliveryPin,
        clearActiveTrip,
      }}
    >
      {children}
    </TripContext.Provider>
  );
};

export const useTrip = (): TripContextType => {
  const context = useContext(TripContext);
  if (!context) {
    throw new Error('useTrip deve ser utilizado dentro de um TripProvider');
  }
  return context;
};

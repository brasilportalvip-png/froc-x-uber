import React, { createContext, useContext, useState, useEffect, ReactNode, useCallback } from 'react';
import { apiRequest } from '../services/apiClient';

export type UserRole = 'passenger' | 'driver' | 'trucker' | 'admin';

export interface ComplianceStatus {
  cnhVerified: boolean;
  anttVerified: boolean;
  crlvVerified: boolean;
  overallStatus: 'pending' | 'approved' | 'rejected' | 'not_submitted';
  rejectionReason?: string;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: UserRole;
  avatarUrl?: string;
  rating: number;
  completedTrips: number;
  walletBalance: number;
  compliance: ComplianceStatus;
  vehicle?: {
    model: string;
    plate: string;
    category: string;
    maxVolumeM3?: number;
    maxWeightKg?: number;
  };
}

interface AuthContextType {
  user: UserProfile | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, role?: UserRole) => Promise<void>;
  logout: () => void;
  switchRole: (newRole: UserRole) => void;
  updateCompliance: (data: Partial<ComplianceStatus>) => void;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const DEMO_USER_ID = 'usr_guest_demo_01';

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  const loadStoredSession = useCallback(() => {
    try {
      const storedToken = localStorage.getItem('froc_auth_token');
      const storedUser = localStorage.getItem('froc_auth_user');

      if (storedToken && storedUser) {
        setToken(storedToken);
        setUser(JSON.parse(storedUser));
      } else {
        // Inicializa com perfil padrão de passageiro para exploração imediata da plataforma
        const defaultPassenger: UserProfile = {
          id: DEMO_USER_ID,
          name: 'Usuário Convidado',
          email: 'passageiro@froc.app',
          phone: '+55 11 98888-0000',
          role: 'passenger',
          rating: 4.95,
          completedTrips: 18,
          walletBalance: 125.50,
          compliance: {
            cnhVerified: false,
            anttVerified: false,
            crlvVerified: false,
            overallStatus: 'not_submitted',
          },
        };
        setUser(defaultPassenger);
      }
    } catch (err) {
      console.error('Falha ao restaurar sessão de autenticação:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadStoredSession();
  }, [loadStoredSession]);

  const login = async (email: string, targetRole: UserRole = 'passenger'): Promise<void> => {
    setIsLoading(true);
    try {
      // Chamada padronizada para autenticação ou retorno de credencial de teste
      const mockToken = `froc_jwt_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
      const simulatedUser: UserProfile = {
        id: `usr_${Date.now()}`,
        name: email.split('@')[0].toUpperCase(),
        email,
        phone: '+55 11 99999-7777',
        role: targetRole,
        rating: 5.0,
        completedTrips: targetRole === 'passenger' ? 2 : 45,
        walletBalance: targetRole === 'passenger' ? 80.0 : 450.0,
        compliance: {
          cnhVerified: targetRole === 'driver' || targetRole === 'trucker',
          anttVerified: targetRole === 'trucker',
          crlvVerified: targetRole === 'driver' || targetRole === 'trucker',
          overallStatus: (targetRole === 'driver' || targetRole === 'trucker') ? 'approved' : 'not_submitted',
        },
        vehicle: targetRole === 'trucker' ? {
          model: 'Mercedes-Benz Accelo 1016 (Baú 28m³)',
          plate: 'FRO-4C01',
          category: 'Caminhão 3/4 Baú',
          maxVolumeM3: 28,
          maxWeightKg: 5000,
        } : targetRole === 'driver' ? {
          model: 'Toyota Corolla Híbrido 2023',
          plate: 'UBR-9900',
          category: 'Sedan Executivo',
        } : undefined,
      };

      localStorage.setItem('froc_auth_token', mockToken);
      localStorage.setItem('froc_auth_user', JSON.stringify(simulatedUser));
      setToken(mockToken);
      setUser(simulatedUser);
    } finally {
      setIsLoading(false);
    }
  };

  const logout = (): void => {
    localStorage.removeItem('froc_auth_token');
    localStorage.removeItem('froc_auth_user');
    setToken(null);
    setUser(null);
  };

  const switchRole = (newRole: UserRole): void => {
    if (!user) return;
    const updated: UserProfile = {
      ...user,
      role: newRole,
      compliance: {
        ...user.compliance,
        overallStatus: (newRole === 'trucker' || newRole === 'driver') && !user.compliance.cnhVerified
          ? 'pending'
          : user.compliance.overallStatus,
      },
      vehicle: newRole === 'trucker' && !user.vehicle ? {
        model: 'Volvo VM 270 Baú Seco (Retorno Vazio)',
        plate: 'RET-8899',
        category: 'Caminhão Toco Baú',
        maxVolumeM3: 35,
        maxWeightKg: 8000,
      } : user.vehicle,
    };
    setUser(updated);
    localStorage.setItem('froc_auth_user', JSON.stringify(updated));
  };

  const updateCompliance = (data: Partial<ComplianceStatus>): void => {
    if (!user) return;
    const updated: UserProfile = {
      ...user,
      compliance: {
        ...user.compliance,
        ...data,
      },
    };
    setUser(updated);
    localStorage.setItem('froc_auth_user', JSON.stringify(updated));
  };

  const refreshProfile = async (): Promise<void> => {
    if (!token) return;
    try {
      const fresh = await apiRequest<UserProfile>('/api/compliance', {
        params: { action: 'me' },
        authToken: token,
      });
      setUser(fresh);
      localStorage.setItem('froc_auth_user', JSON.stringify(fresh));
    } catch {
      // Mantém estado em cache se offline
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isAuthenticated: !!user,
        isLoading,
        login,
        logout,
        switchRole,
        updateCompliance,
        refreshProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth deve ser utilizado dentro de um AuthProvider');
  }
  return context;
};

import React, { useState, useEffect } from 'react';
import { AuthProvider } from './context/AuthContext';
import { TripProvider } from './context/TripContext';
import { ToastProvider } from './components/ui/Toast';
import { HomePage } from './pages/HomePage';
import { BookingPage } from './pages/BookingPage';
import { FreightMarketplacePage } from './pages/FreightMarketplacePage';
import { CarpoolPage } from './pages/CarpoolPage';
import { DriverDashboardPage } from './pages/DriverDashboardPage';
import { TripDetailsPage } from './pages/TripDetailsPage';
import { AdminPage } from './pages/AdminPage';
import { FAQPage } from './pages/FAQPage';
import { NotFoundPage } from './pages/NotFoundPage';

export const App: React.FC = () => {
  const [currentPath, setCurrentPath] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      return window.location.pathname || '/';
    }
    return '/';
  });

  useEffect(() => {
    const onPopState = () => {
      setCurrentPath(window.location.pathname || '/');
    };
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, []);

  const handleNavigate = (path: string) => {
    if (typeof window !== 'undefined') {
      window.history.pushState({}, '', path);
    }
    setCurrentPath(path);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const cleanPath = currentPath.split('?')[0].replace(/\/+$/, '') || '/';

  const renderContent = () => {
    if (cleanPath === '' || cleanPath === '/') {
      return <HomePage onNavigate={handleNavigate} />;
    }
    if (cleanPath === '/booking') {
      return <BookingPage onNavigate={handleNavigate} />;
    }
    if (cleanPath === '/freight' || cleanPath === '/freight-marketplace') {
      return <FreightMarketplacePage onNavigate={handleNavigate} />;
    }
    if (cleanPath === '/carpool' || cleanPath === '/carpools') {
      return <CarpoolPage onNavigate={handleNavigate} />;
    }
    if (cleanPath === '/driver' || cleanPath === '/driver-dashboard') {
      return <DriverDashboardPage onNavigate={handleNavigate} />;
    }
    if (cleanPath === '/admin') {
      return <AdminPage onNavigate={handleNavigate} />;
    }
    if (cleanPath === '/faq') {
      return <FAQPage onNavigate={handleNavigate} />;
    }
    if (cleanPath.startsWith('/trips') || cleanPath === '/trip-details') {
      const tripId = cleanPath.startsWith('/trips/')
        ? cleanPath.replace('/trips/', '')
        : 'trip-direct-sample';
      return <TripDetailsPage tripId={tripId} onNavigate={handleNavigate} />;
    }
    return <NotFoundPage onNavigate={handleNavigate} />;
  };

  return (
    <AuthProvider>
      <TripProvider>
        <ToastProvider>
          {renderContent()}
        </ToastProvider>
      </TripProvider>
    </AuthProvider>
  );
};

export default App;

import React, { useState } from 'react';
import { useAuth, UserRole } from '../../context/AuthContext';
import { useTrip, ServiceMode } from '../../context/TripContext';

interface NavbarProps {
  currentPath?: string;
  onNavigate?: (path: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentPath = '/', onNavigate }) => {
  const { user, switchRole, logout } = useAuth();
  const { currentMode, setCurrentMode } = useTrip();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [roleDropdownOpen, setRoleDropdownOpen] = useState(false);

  const handleNavigate = (path: string) => {
    if (onNavigate) {
      onNavigate(path);
    } else {
      window.location.href = path;
    }
    setMobileMenuOpen(false);
  };

  const handleModeSelect = (mode: ServiceMode) => {
    setCurrentMode(mode);
    if (mode === 'carpool') {
      handleNavigate('/carpools');
    } else if (mode === 'freight') {
      handleNavigate('/freight-marketplace');
    } else {
      handleNavigate('/booking');
    }
  };

  const roleLabels: Record<UserRole, { label: string; badge: string }> = {
    passenger: { label: 'Passageiro', badge: 'bg-purple-900 text-purple-200' },
    driver: { label: 'Motorista Urbano', badge: 'bg-amber-900 text-amber-200' },
    trucker: { label: 'Caminhoneiro / Frete', badge: 'bg-emerald-900 text-emerald-200' },
    admin: { label: 'Administrador ANTT', badge: 'bg-rose-900 text-rose-200' },
  };

  return (
    <header className="sticky top-0 z-50 bg-[#120720]/95 backdrop-blur-md border-b border-[#2E0854]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo e Nome da Aplicação */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => handleNavigate('/')}>
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-[#7928CA] to-[#FFD700] p-[2px] shadow-[0_0_15px_rgba(121,40,202,0.4)]">
              <div className="w-full h-full bg-[#1A0B2E] rounded-[10px] flex items-center justify-center">
                <span className="text-xl font-black text-[#FFD700] tracking-tighter">FX</span>
              </div>
            </div>
            <div>
              <span className="text-2xl font-extrabold tracking-tight text-white">
                Froc <span className="text-[#FFD700]">X</span> Uber
              </span>
              <span className="hidden md:inline-block ml-2 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-[#FFD700]/10 text-[#FFD700] rounded-full border border-[#FFD700]/30">
                4 em 1 SuperApp
              </span>
            </div>
          </div>

          {/* 4 Pilares Centrais - Navegação de Modalidades */}
          <nav className="hidden lg:flex items-center space-x-1 bg-[#1A0B2E]/90 p-1.5 rounded-2xl border border-[#2E0854]" aria-label="Modalidades principais">
            <button
              type="button"
              onClick={() => handleModeSelect('direct')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 ${
                currentMode === 'direct' && currentPath === '/booking'
                  ? 'bg-[#7928CA] text-white shadow-md'
                  : 'text-gray-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <span>⚡</span>
              <span>Urbana Direta</span>
            </button>

            <button
              type="button"
              onClick={() => handleModeSelect('negotiated')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 ${
                currentMode === 'negotiated' && currentPath === '/booking'
                  ? 'bg-[#7928CA] text-white shadow-md'
                  : 'text-gray-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <span>🤝</span>
              <span>Negociada (inDrive)</span>
            </button>

            <button
              type="button"
              onClick={() => handleModeSelect('carpool')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 ${
                currentPath === '/carpools'
                  ? 'bg-[#7928CA] text-white shadow-md'
                  : 'text-gray-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <span>🚗</span>
              <span>Carona (BlaBla)</span>
            </button>

            <button
              type="button"
              onClick={() => handleModeSelect('freight')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 ${
                currentPath === '/freight-marketplace'
                  ? 'bg-gradient-to-r from-[#FFD700] to-[#F5A623] text-black font-extrabold shadow-md'
                  : 'text-[#FFD700] hover:bg-[#FFD700]/10'
              }`}
            >
              <span>🚚</span>
              <span>Caminhão Retorno</span>
            </button>
          </nav>

          {/* Perfil, Seletor de Papel e FAQ */}
          <div className="hidden md:flex items-center space-x-4">
            <button
              type="button"
              onClick={() => handleNavigate('/faq')}
              className="text-xs font-semibold text-gray-300 hover:text-[#FFD700] transition-colors px-2 py-1"
            >
              Central de Ajuda
            </button>

            {/* Dropdown de Alternância de Papel (Passageiro / Motorista / Caminhoneiro) */}
            <div className="relative">
              <button
                type="button"
                aria-expanded={roleDropdownOpen}
                onClick={() => setRoleDropdownOpen(!roleDropdownOpen)}
                className="flex items-center space-x-2 bg-[#1A0B2E] border border-[#2E0854] hover:border-[#FFD700]/40 rounded-xl px-3 py-1.5 text-xs text-white transition-all"
              >
                <span className="w-2 h-2 rounded-full bg-[#FFD700] animate-pulse" />
                <span className="font-medium">Modo:</span>
                <span className="font-bold text-[#FFD700]">{user ? roleLabels[user.role].label : 'Visitante'}</span>
                <span className="text-[10px]">▼</span>
              </button>

              {roleDropdownOpen && (
                <div className="absolute right-0 mt-2 w-56 rounded-xl bg-[#1A0B2E] border border-[#2E0854] shadow-2xl py-2 z-50 animate-fadeIn">
                  <div className="px-3 py-1.5 border-b border-[#2E0854] text-[11px] text-gray-400 font-medium">
                    Alternar perspectiva na plataforma:
                  </div>
                  {(['passenger', 'driver', 'trucker', 'admin'] as UserRole[]).map((r) => (
                    <button
                      key={r}
                      type="button"
                      onClick={() => {
                        switchRole(r);
                        setRoleDropdownOpen(false);
                      }}
                      className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between hover:bg-white/5 transition-colors ${
                        user?.role === r ? 'text-[#FFD700] font-bold bg-[#FFD700]/5' : 'text-gray-200'
                      }`}
                    >
                      <span>{roleLabels[r].label}</span>
                      {user?.role === r && <span>✓</span>}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Botão de Solicitar ou Painel */}
            <button
              type="button"
              onClick={() => handleNavigate('/booking')}
              className="px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider bg-gradient-to-r from-[#FFD700] to-[#F5A623] text-black hover:opacity-95 shadow-[0_0_15px_rgba(255,215,0,0.3)] transition-all transform active:scale-95"
            >
              Iniciar Viagem
            </button>
          </div>

          {/* Botão Hambúrguer Mobile */}
          <div className="flex md:hidden items-center space-x-2">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2.5 rounded-xl bg-[#1A0B2E] border border-[#2E0854] text-white hover:text-[#FFD700] focus:outline-none"
              aria-label="Abrir menu de navegação"
            >
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                {mobileMenuOpen ? (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                ) : (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                )}
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Menu Aberto Mobile */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#120720] border-b border-[#2E0854] px-4 pt-3 pb-6 space-y-3">
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => handleModeSelect('direct')}
              className="p-3 rounded-xl bg-[#1A0B2E] border border-[#2E0854] text-left text-xs text-white font-bold flex flex-col space-y-1"
            >
              <span>⚡ Urbana Direta</span>
              <span className="text-[10px] text-gray-400 font-normal">Tipo Uber clássico</span>
            </button>
            <button
              type="button"
              onClick={() => handleModeSelect('negotiated')}
              className="p-3 rounded-xl bg-[#1A0B2E] border border-[#2E0854] text-left text-xs text-white font-bold flex flex-col space-y-1"
            >
              <span>🤝 Negociada</span>
              <span className="text-[10px] text-gray-400 font-normal">Leilão tipo inDrive</span>
            </button>
            <button
              type="button"
              onClick={() => handleModeSelect('carpool')}
              className="p-3 rounded-xl bg-[#1A0B2E] border border-[#2E0854] text-left text-xs text-white font-bold flex flex-col space-y-1"
            >
              <span>🚗 Carona Interurbana</span>
              <span className="text-[10px] text-gray-400 font-normal">Vagas tipo BlaBlaCar</span>
            </button>
            <button
              type="button"
              onClick={() => handleModeSelect('freight')}
              className="p-3 rounded-xl bg-gradient-to-br from-[#7928CA]/30 to-[#FFD700]/20 border border-[#FFD700]/40 text-left text-xs text-[#FFD700] font-bold flex flex-col space-y-1"
            >
              <span>🚚 Frete de Retorno</span>
              <span className="text-[10px] text-gray-300 font-normal">Caminhão com baú vazio</span>
            </button>
          </div>

          <div className="pt-3 border-t border-[#2E0854] flex flex-col space-y-2">
            <button
              type="button"
              onClick={() => handleNavigate('/faq')}
              className="w-full text-left py-2 text-sm text-gray-300 hover:text-[#FFD700]"
            >
              Central de Ajuda e Regras ANTT
            </button>
            <button
              type="button"
              onClick={() => handleNavigate('/booking')}
              className="w-full py-3 rounded-xl text-center text-xs font-bold uppercase tracking-wider bg-gradient-to-r from-[#FFD700] to-[#F5A623] text-black shadow-lg"
            >
              Solicitar Transporte Agora
            </button>
          </div>
        </div>
      )}
    </header>
  );
};

import React from 'react';

interface FooterProps {
  onNavigate?: (path: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const handleLink = (path: string, event: React.MouseEvent) => {
    if (path.startsWith('/legal/')) {
      // Páginas injetadas estáticas
      return;
    }
    event.preventDefault();
    if (onNavigate) {
      onNavigate(path);
    } else {
      window.location.href = path;
    }
  };

  return (
    <footer className="bg-[#0D0417] text-gray-400 border-t border-[#2E0854] mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* Coluna 1: Sobre a Plataforma */}
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#7928CA] to-[#FFD700] flex items-center justify-center p-[2px]">
                <div className="w-full h-full bg-[#1A0B2E] rounded-[6px] flex items-center justify-center">
                  <span className="text-xs font-black text-[#FFD700]">FX</span>
                </div>
              </div>
              <span className="text-lg font-bold text-white tracking-tight">
                Froc <span className="text-[#FFD700]">X</span> Uber
              </span>
            </div>
            <p className="text-xs leading-relaxed text-gray-400 mb-4">
              O primeiro superaplicativo unificado de mobilidade do Brasil: corrida direta, lances em leilão negociado, caronas interurbanas e o marketplace revolucionário de frete de retorno para caminhões vazios.
            </p>
            <div className="inline-flex items-center space-x-2 px-2.5 py-1 rounded-md bg-[#1A0B2E] border border-[#2E0854] text-[11px] text-[#FFD700]">
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              <span>Compatibilidade ANTT & LGPD</span>
            </div>
          </div>

          {/* Coluna 2: As 4 Modalidades */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-4">
              4 Modalidades Integradas
            </h4>
            <ul className="space-y-2.5 text-xs">
              <li>
                <a
                  href="/booking"
                  onClick={(e) => handleLink('/booking', e)}
                  className="hover:text-[#FFD700] transition-colors flex items-center space-x-1.5"
                >
                  <span className="text-[#7928CA]">▸</span>
                  <span>Urbana Direta (Tarifa Garantida)</span>
                </a>
              </li>
              <li>
                <a
                  href="/booking"
                  onClick={(e) => handleLink('/booking', e)}
                  className="hover:text-[#FFD700] transition-colors flex items-center space-x-1.5"
                >
                  <span className="text-[#7928CA]">▸</span>
                  <span>Negociada (Leilão inDrive)</span>
                </a>
              </li>
              <li>
                <a
                  href="/carpools"
                  onClick={(e) => handleLink('/carpools', e)}
                  className="hover:text-[#FFD700] transition-colors flex items-center space-x-1.5"
                >
                  <span className="text-[#7928CA]">▸</span>
                  <span>Carona Interurbana (BlaBlaCar)</span>
                </a>
              </li>
              <li>
                <a
                  href="/freight-marketplace"
                  onClick={(e) => handleLink('/freight-marketplace', e)}
                  className="hover:text-[#FFD700] transition-colors flex items-center space-x-1.5 font-semibold text-gray-300"
                >
                  <span className="text-[#FFD700]">★</span>
                  <span>Caminhão de Retorno & Mudanças</span>
                </a>
              </li>
            </ul>
          </div>

          {/* Coluna 3: Segurança e Custódia */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-4">
              Garantia & Custódia Escrow
            </h4>
            <p className="text-xs text-gray-400 leading-relaxed mb-3">
              Todos os valores pagos em corridas ou fretes de carga permanecem blindados em conta de custódia Mercado Pago. O repasse ao motorista só ocorre após a conferência do código PIN de segurança ou comprovante de entrega.
            </p>
            <ul className="space-y-2 text-xs">
              <li>
                <a href="/faq" onClick={(e) => handleLink('/faq', e)} className="hover:text-white transition-colors">
                  • Como funciona o PIN de desembarque
                </a>
              </li>
              <li>
                <a href="/faq" onClick={(e) => handleLink('/faq', e)} className="hover:text-white transition-colors">
                  • Checklist e seguro para mudanças
                </a>
              </li>
            </ul>
          </div>

          {/* Coluna 4: Conformidade Legal e Políticas */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-4">
              Transparência & Legalidade
            </h4>
            <ul className="space-y-2.5 text-xs">
              <li>
                <a
                  href="/legal/privacy.html"
                  className="hover:text-[#FFD700] transition-colors underline decoration-dotted underline-offset-4"
                >
                  Política de Privacidade (LGPD)
                </a>
              </li>
              <li>
                <a
                  href="/legal/terms.html"
                  className="hover:text-[#FFD700] transition-colors underline decoration-dotted underline-offset-4"
                >
                  Termos de Uso e Intermediação
                </a>
              </li>
              <li>
                <a
                  href="/legal/cookies.html"
                  className="hover:text-[#FFD700] transition-colors underline decoration-dotted underline-offset-4"
                >
                  Política de Cookies e Preferências
                </a>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => {
                    if (typeof window !== 'undefined' && (window as unknown as { openFrocConsentModal?: () => void }).openFrocConsentModal) {
                      (window as unknown as { openFrocConsentModal: () => void }).openFrocConsentModal();
                    }
                  }}
                  className="text-left text-gray-400 hover:text-white transition-colors text-[11px] block mt-2"
                >
                  Gerenciar consentimento de dados
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Linha Inferior com Copyright e Isenção Regulatória */}
        <div className="pt-8 border-t border-[#2E0854]/70 flex flex-col md:flex-row items-center justify-between text-[11px] text-gray-500 space-y-4 md:space-y-0">
          <p>
            © {new Date().getFullYear()} Froc X Uber Tecnologia S.A. Plataforma intermediadora de tecnologia para mobilidade e frete.
          </p>
          <div className="flex items-center space-x-6">
            <span>Comissão Transparente: 12% Urbana | 10% Carona | 8% Retorno</span>
            <span>Suporte 24h: dpo@froc.app</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

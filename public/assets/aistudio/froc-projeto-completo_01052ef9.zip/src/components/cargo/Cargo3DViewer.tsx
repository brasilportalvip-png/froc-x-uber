import React, { useState } from 'react';

export interface Cargo3DViewerProps {
  volumeM3?: number;
  maxVolumeM3?: number;
  occupiedVolumeM3?: number;
  totalCapacityM3?: number;
  weightKg?: number;
  maxWeightKg?: number;
  isReturnTrip?: boolean;
  truckType?: string;
  className?: string;
}

export const Cargo3DViewer: React.FC<Cargo3DViewerProps> = ({
  volumeM3,
  maxVolumeM3,
  occupiedVolumeM3,
  totalCapacityM3,
  weightKg = 1200,
  maxWeightKg = 8000,
  isReturnTrip = true,
  truckType = 'Caminhão Toco Baú Fechado (Retorno Vazio)',
  className = '',
}) => {
  const [viewAngle, setViewAngle] = useState<'isometric' | 'side' | 'top'>('isometric');

  // Suporte transparente tanto a volumeM3/maxVolumeM3 quanto occupiedVolumeM3/totalCapacityM3
  const rawVolume = occupiedVolumeM3 !== undefined ? occupiedVolumeM3 : (volumeM3 !== undefined ? volumeM3 : 14);
  const rawMaxVolume = totalCapacityM3 !== undefined ? totalCapacityM3 : (maxVolumeM3 !== undefined ? maxVolumeM3 : 35);

  const safeCapacity = Math.max(1, rawMaxVolume);
  const safeVolume = Math.max(0, Math.min(rawVolume, safeCapacity));
  const percentageOccupied = Math.min(100, Math.round((safeVolume / safeCapacity) * 100));
  const percentageFree = 100 - percentageOccupied;
  const weightPercentage = Math.min(100, Math.round((weightKg / Math.max(1, maxWeightKg)) * 100));

  return (
    <div
      data-testid="cargo-volume-preview"
      className={`p-5 rounded-2xl bg-gradient-to-b from-[#200C38] to-[#120720] border border-[#FFD700]/50 text-white shadow-xl space-y-4 ${className}`}
      aria-label="Diagrama de Cubagem e Ocupação Volumétrica do Baú do Caminhão"
    >
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-purple-800/50 gap-2">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase bg-[#FFD700]/20 text-[#FFD700] border border-[#FFD700]/50">
              Simulação de Baú 3D
            </span>
            {isReturnTrip && (
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                Retorno Vazio • Tarifa Reduzida
              </span>
            )}
          </div>
          <h3 className="text-base font-extrabold text-white mt-1">{truckType}</h3>
        </div>

        <div className="flex items-center space-x-1.5 self-start sm:self-auto" role="group" aria-label="Ângulo de visualização do caminhão">
          {(['isometric', 'side', 'top'] as const).map((mode) => (
            <button
              key={mode}
              type="button"
              onClick={() => setViewAngle(mode)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold capitalize transition-all ${
                viewAngle === mode
                  ? 'bg-[#FFD700] text-[#1A0B2E] font-bold shadow-md'
                  : 'bg-purple-900/40 text-purple-300 hover:text-white hover:bg-purple-800/60'
              }`}
            >
              {mode === 'isometric' ? 'Isométrica' : mode === 'side' ? 'Lateral' : 'Planta Superior'}
            </button>
          ))}
        </div>
      </div>

      <div className="relative w-full h-56 rounded-xl bg-[#0b0314] border border-purple-900/80 overflow-hidden flex items-center justify-center">
        <svg
          viewBox="0 0 400 220"
          className="w-full h-full max-h-56 select-none"
          aria-label={`Visualização esquemática do baú com ${percentageOccupied}% de espaço ocupado`}
        >
          <defs>
            <linearGradient id="truck-body-gradient" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#3D1469" />
              <stop offset="100%" stopColor="#19082D" />
            </linearGradient>
            <linearGradient id="cargo-gold-gradient" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#FFD700" />
              <stop offset="100%" stopColor="#F5A623" />
            </linearGradient>
            <pattern id="grid-blueprint" width="20" height="20" patternUnits="userSpaceOnUse">
              <path d="M 20 0 L 0 0 0 20" fill="none" stroke="rgba(121,40,202,0.25)" strokeWidth="0.8" />
            </pattern>
          </defs>

          <rect width="400" height="220" fill="url(#grid-blueprint)" />

          {viewAngle === 'isometric' && (
            <g transform="translate(50, 20)">
              {/* Teto e lateral em projeção isométrica */}
              <polygon points="50,40 270,40 230,10 10,10" fill="#22093C" stroke="#7928CA" strokeWidth="1.5" />
              <polygon points="10,10 50,40 50,150 10,120" fill="#1A062F" stroke="#7928CA" strokeWidth="1.5" />
              <polygon points="50,40 270,40 270,150 50,150" fill="url(#truck-body-gradient)" stroke="#9E00FF" strokeWidth="1.5" opacity="0.85" />

              {/* Carga ocupando o volume do baú */}
              <rect
                x="52"
                y={150 - (105 * (percentageOccupied / 100))}
                width={216 * (percentageOccupied / 100)}
                height={105 * (percentageOccupied / 100)}
                fill="url(#cargo-gold-gradient)"
                opacity="0.85"
                stroke="#FFD700"
                strokeWidth="1.5"
                rx="2"
              />

              {/* Rodas */}
              <circle cx="80" cy="165" r="16" fill="#0D0417" stroke="#FFD700" strokeWidth="2" />
              <circle cx="240" cy="165" r="16" fill="#0D0417" stroke="#FFD700" strokeWidth="2" />
              <circle cx="80" cy="165" r="6" fill="#7928CA" />
              <circle cx="240" cy="165" r="6" fill="#7928CA" />

              {/* Cabine dianteira */}
              <polygon points="270,70 310,95 310,150 270,150" fill="#2C0D52" stroke="#FFD700" strokeWidth="1.5" />
              <rect x="280" y="85" width="20" height="20" fill="#FFD700" opacity="0.2" stroke="#FFD700" strokeWidth="1" />
            </g>
          )}

          {viewAngle === 'side' && (
            <g transform="translate(40, 30)">
              <rect x="20" y="30" width="240" height="100" fill="url(#truck-body-gradient)" stroke="#9E00FF" strokeWidth="2" rx="4" />
              <rect
                x="22"
                y="32"
                width={236 * (percentageOccupied / 100)}
                height="96"
                fill="url(#cargo-gold-gradient)"
                opacity="0.8"
                stroke="#FFD700"
                strokeWidth="1"
              />
              <rect x="260" y="50" width="50" height="80" fill="#2C0D52" stroke="#FFD700" strokeWidth="2" rx="4" />
              <circle cx="70" cy="145" r="18" fill="#0D0417" stroke="#FFD700" strokeWidth="2" />
              <circle cx="220" cy="145" r="18" fill="#0D0417" stroke="#FFD700" strokeWidth="2" />
            </g>
          )}

          {viewAngle === 'top' && (
            <g transform="translate(50, 40)">
              <rect x="10" y="20" width="260" height="90" fill="url(#truck-body-gradient)" stroke="#9E00FF" strokeWidth="2" rx="4" />
              <rect
                x="12"
                y="22"
                width={256 * (percentageOccupied / 100)}
                height="86"
                fill="url(#cargo-gold-gradient)"
                opacity="0.8"
                stroke="#FFD700"
                strokeWidth="1"
              />
              <rect x="270" y="30" width="30" height="70" fill="#2C0D52" stroke="#FFD700" strokeWidth="2" rx="4" />
            </g>
          )}
        </svg>

        <div className="absolute top-2.5 right-2.5 bg-black/80 backdrop-blur-md px-3 py-1.5 rounded-lg border border-purple-700/60 text-xs shadow-lg">
          <span className="text-purple-300">Volume Ocupado: </span>
          <strong className="text-[#FFD700] font-extrabold">{safeVolume} m³</strong>
          <span className="text-purple-400 font-medium"> / {safeCapacity} m³</span>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
        <div className="p-3.5 rounded-xl bg-purple-950/60 border border-purple-800/40">
          <div className="flex justify-between items-center mb-1.5">
            <span className="text-purple-300 font-medium">Ocupação do Baú (m³):</span>
            <span className="font-extrabold text-[#FFD700]">{percentageOccupied}%</span>
          </div>
          <div className="w-full h-2.5 rounded-full bg-purple-900 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-[#FFD700] to-[#F5A623] rounded-full transition-all duration-500"
              style={{ width: `${percentageOccupied}%` }}
            />
          </div>
          <span className="text-[11px] text-purple-400 mt-1.5 block">
            Espaço livre restante: {percentageFree}% (aprox. {(safeCapacity - safeVolume).toFixed(1)} m³)
          </span>
        </div>

        <div className="p-3.5 rounded-xl bg-purple-950/60 border border-purple-800/40">
          <div className="flex justify-between items-center mb-1.5">
            <span className="text-purple-300 font-medium">Capacidade em Peso (kg):</span>
            <span className="font-extrabold text-[#FFD700]">{weightPercentage}%</span>
          </div>
          <div className="w-full h-2.5 rounded-full bg-purple-900 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-purple-400 to-purple-600 rounded-full transition-all duration-500"
              style={{ width: `${weightPercentage}%` }}
            />
          </div>
          <span className="text-[11px] text-purple-400 mt-1.5 block">
            Carga informada: {weightKg} kg (limite técnico: {maxWeightKg} kg)
          </span>
        </div>
      </div>
    </div>
  );
};

import React, { useState, useEffect, useRef } from 'react';

export interface BidModalProps {
  isOpen: boolean;
  tripId: string;
  passengerOffer: number;
  minimumFloor: number;
  originAddress: string;
  destinationAddress: string;
  onClose: () => void;
  onSubmitBid: (amount: number, etaMinutes: number, message: string) => Promise<void>;
}

export const BidModal: React.FC<BidModalProps> = ({
  isOpen,
  tripId,
  passengerOffer,
  minimumFloor,
  originAddress,
  destinationAddress,
  onClose,
  onSubmitBid,
}) => {
  const [proposedAmount, setProposedAmount] = useState<number>(passengerOffer || minimumFloor);
  const [etaMinutes, setEtaMinutes] = useState<number>(5);
  const [message, setMessage] = useState<string>('');
  const [secondsRemaining, setSecondsRemaining] = useState<number>(60);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const modalRef = useRef<HTMLDivElement>(null);
  const firstInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setProposedAmount(passengerOffer > 0 ? passengerOffer : minimumFloor);
      setSecondsRemaining(60);
      setError(null);
      const timer = setTimeout(() => {
        firstInputRef.current?.focus();
      }, 50);
      return () => clearTimeout(timer);
    }
  }, [isOpen, passengerOffer, minimumFloor]);

  useEffect(() => {
    if (!isOpen) return;
    const interval = setInterval(() => {
      setSecondsRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          onClose();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isOpen, onClose]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleQuickAdd = (increment: number) => {
    const next = Math.max(minimumFloor, Number((proposedAmount + increment).toFixed(2)));
    setProposedAmount(next);
    setError(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (proposedAmount < minimumFloor) {
      setError(`O valor da proposta não pode ser inferior ao piso regulatório de R$ ${minimumFloor.toFixed(2).replace('.', ',')}.`);
      return;
    }

    if (etaMinutes < 1 || etaMinutes > 60) {
      setError('O tempo estimado de chegada deve estar entre 1 e 60 minutos.');
      return;
    }

    setIsSubmitting(true);
    try {
      await onSubmitBid(proposedAmount, etaMinutes, message);
      onClose();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Falha ao registrar contraproposta.';
      setError(msg);
    } finally {
      setIsSubmitting(false);
    }
  };

  const timerPercentage = Math.round((secondsRemaining / 60) * 100);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="bid-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in"
    >
      <div
        ref={modalRef}
        className="w-full max-w-lg rounded-2xl bg-gradient-to-b from-[#260E43] to-[#1A0B2E] border border-amber-400/40 p-6 text-white shadow-2xl relative overflow-hidden"
      >
        <div
          className="absolute top-0 left-0 h-1 bg-gradient-to-r from-amber-400 to-amber-600 transition-all duration-1000 ease-linear"
          style={{ width: `${timerPercentage}%` }}
        />

        <div className="flex items-center justify-between pb-4 border-b border-purple-800/60 mb-5">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-amber-400 block mb-1">
              Leilão Aberto • Chamado #{tripId.slice(-6)}
            </span>
            <h2 id="bid-modal-title" className="text-xl font-extrabold text-white">
              Enviar Contraproposta
            </h2>
          </div>
          <div className="flex items-center space-x-2">
            <span
              aria-label={`Tempo restante: ${secondsRemaining} segundos`}
              className={`text-xs font-mono font-bold px-2.5 py-1 rounded-full border ${
                secondsRemaining <= 15
                  ? 'bg-rose-950/80 text-rose-300 border-rose-500 animate-pulse'
                  : 'bg-purple-950/80 text-amber-300 border-amber-400/40'
              }`}
            >
              {secondsRemaining}s
            </span>
            <button
              type="button"
              onClick={onClose}
              aria-label="Fechar modal de contraproposta"
              className="p-2 rounded-xl text-purple-300 hover:text-white hover:bg-purple-900/60 focus:outline-none focus:ring-2 focus:ring-amber-400"
            >
              ✕
            </button>
          </div>
        </div>

        <div className="bg-purple-950/60 border border-purple-800/40 rounded-xl p-3.5 mb-5 space-y-1.5 text-xs">
          <div className="flex items-center justify-between text-purple-300">
            <span>Origem:</span>
            <span className="font-medium text-white truncate max-w-[280px]">{originAddress}</span>
          </div>
          <div className="flex items-center justify-between text-purple-300">
            <span>Destino:</span>
            <span className="font-medium text-white truncate max-w-[280px]">{destinationAddress}</span>
          </div>
          <div className="flex items-center justify-between pt-2 border-t border-purple-800/40">
            <span className="text-purple-300">Oferta atual do passageiro:</span>
            <span className="font-extrabold text-amber-400 text-sm">
              R$ {passengerOffer.toFixed(2).replace('.', ',')}
            </span>
          </div>
          <div className="flex items-center justify-between text-[11px] text-purple-400">
            <span>Piso mínimo regulatório:</span>
            <span>R$ {minimumFloor.toFixed(2).replace('.', ',')}</span>
          </div>
        </div>

        {error && (
          <div
            role="alert"
            className="mb-4 p-3 rounded-xl bg-rose-950/80 border border-rose-500/70 text-rose-200 text-xs flex items-center space-x-2"
          >
            <span>⚠️</span>
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="counter-bid-amount" className="block text-xs font-bold uppercase tracking-wider text-purple-200 mb-1.5">
              Sua Proposta (R$)
            </label>
            <div className="relative">
              <span className="absolute left-4 top-3.5 text-amber-400 font-extrabold text-sm">R$</span>
              <input
                ref={firstInputRef}
                id="counter-bid-amount"
                type="number"
                step="0.50"
                min={minimumFloor}
                required
                value={proposedAmount}
                onChange={(e) => setProposedAmount(parseFloat(e.target.value) || 0)}
                className="w-full pl-12 pr-4 py-3 bg-[#150724] border border-purple-700/60 rounded-xl text-white font-extrabold text-lg focus:outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-400/30"
              />
            </div>

            <div className="flex items-center space-x-2 mt-2">
              <span className="text-[11px] text-purple-300">Ajuste rápido:</span>
              <button
                type="button"
                onClick={() => handleQuickAdd(2)}
                className="px-2.5 py-1 rounded-lg text-xs bg-purple-900/60 hover:bg-purple-800 text-amber-300 border border-purple-700/50"
              >
                + R$ 2,00
              </button>
              <button
                type="button"
                onClick={() => handleQuickAdd(5)}
                className="px-2.5 py-1 rounded-lg text-xs bg-purple-900/60 hover:bg-purple-800 text-amber-300 border border-purple-700/50"
              >
                + R$ 5,00
              </button>
              <button
                type="button"
                onClick={() => setProposedAmount(passengerOffer)}
                className="px-2.5 py-1 rounded-lg text-xs bg-purple-900/60 hover:bg-purple-800 text-white border border-purple-700/50"
              >
                Aceitar Oferta Inicial
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label htmlFor="counter-bid-eta" className="block text-xs font-bold uppercase tracking-wider text-purple-200 mb-1">
                Chegada em (min)
              </label>
              <input
                id="counter-bid-eta"
                type="number"
                min="1"
                max="60"
                required
                value={etaMinutes}
                onChange={(e) => setEtaMinutes(parseInt(e.target.value, 10) || 5)}
                className="w-full px-3.5 py-2.5 bg-[#150724] border border-purple-700/60 rounded-xl text-white font-semibold text-sm focus:outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-400/30"
              />
            </div>
            <div>
              <label htmlFor="counter-bid-message" className="block text-xs font-bold uppercase tracking-wider text-purple-200 mb-1">
                Mensagem rápida
              </label>
              <input
                id="counter-bid-message"
                type="text"
                maxLength={60}
                placeholder="Ex: Carro com ar ligado"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-[#150724] border border-purple-700/60 rounded-xl text-white text-xs placeholder-purple-400/40 focus:outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-400/30"
              />
            </div>
          </div>

          <div className="pt-3 flex space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 px-4 rounded-xl bg-purple-950/80 hover:bg-purple-900 text-purple-200 text-sm font-semibold border border-purple-800/60 transition-colors"
            >
              Desistir
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex-2 py-3 px-6 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-black font-extrabold text-sm uppercase tracking-wider shadow-lg transition-all active:scale-95 disabled:opacity-50"
            >
              {isSubmitting ? 'Enviando Proposta...' : 'Confirmar Lance'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

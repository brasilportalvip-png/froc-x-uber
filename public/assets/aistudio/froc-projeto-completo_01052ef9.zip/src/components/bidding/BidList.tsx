import React, { useState } from 'react';

export interface DriverBidItem {
  id: string;
  tripId?: string;
  driverId: string;
  driverName: string;
  driverRating: number;
  driverPhone?: string;
  vehicleModel: string;
  vehiclePlate: string;
  vehicleColor?: string;
  amount: number;
  etaMinutes: number;
  message?: string;
  createdAt?: string;
  status?: 'pending' | 'accepted' | 'declined' | 'countered';
}

export interface BidListProps {
  bids: DriverBidItem[];
  passengerOfferPrice?: number;
  onAcceptBid: (bidId: string) => Promise<void>;
  onDeclineBid?: (bidId: string) => Promise<void>;
  isLoading?: boolean;
}

export const BidList: React.FC<BidListProps> = ({
  bids,
  passengerOfferPrice,
  onAcceptBid,
  onDeclineBid,
  isLoading = false,
}) => {
  const [processingBidId, setProcessingBidId] = useState<string | null>(null);
  const [declinedIds, setDeclinedIds] = useState<string[]>([]);

  const handleAccept = async (bidId: string) => {
    if (processingBidId) return;
    setProcessingBidId(bidId);
    try {
      await onAcceptBid(bidId);
    } finally {
      setProcessingBidId(null);
    }
  };

  const handleDecline = async (bidId: string) => {
    if (processingBidId) return;
    setDeclinedIds((prev) => [...prev, bidId]);
    if (onDeclineBid) {
      try {
        await onDeclineBid(bidId);
      } catch {
        setDeclinedIds((prev) => prev.filter((id) => id !== bidId));
      }
    }
  };

  const visibleBids = bids.filter((b) => !declinedIds.includes(b.id) && b.status !== 'declined');

  return (
    <div data-testid="bid-auction-panel" className="space-y-4">
      <div className="flex items-center justify-between pb-3 border-b border-purple-800/40">
        <div className="flex items-center space-x-2">
          <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-pulse" />
          <h3 className="text-base font-extrabold text-white">
            Contrapropostas em Tempo Real ({visibleBids.length})
          </h3>
        </div>
        {passengerOfferPrice !== undefined && passengerOfferPrice > 0 && (
          <span className="text-xs text-purple-300">
            Sua oferta:{' '}
            <strong className="text-amber-400">
              R$ {passengerOfferPrice.toFixed(2).replace('.', ',')}
            </strong>
          </span>
        )}
      </div>

      {visibleBids.length === 0 ? (
        <div className="p-8 text-center rounded-2xl bg-purple-950/40 border border-purple-800/40 text-purple-300">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-purple-900/60 mb-3 text-amber-400">
            <svg aria-hidden="true" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="12" cy="12" r="10" />
              <polyline points="12 6 12 12 16 14" />
            </svg>
          </div>
          <p className="font-bold text-white text-sm">Aguardando lances dos motoristas próximos</p>
          <p className="text-xs text-purple-400 mt-1 max-w-sm mx-auto">
            Motoristas disponíveis na sua região estão analisando a oferta. Novas propostas aparecerão aqui instantaneamente.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {visibleBids.map((bid) => {
            const isProcessing = processingBidId === bid.id;
            const isExactOffer = passengerOfferPrice !== undefined && Math.abs(bid.amount - passengerOfferPrice) < 0.01;
            const isHigher = passengerOfferPrice !== undefined && bid.amount > passengerOfferPrice;
            const diffAmount = passengerOfferPrice !== undefined ? bid.amount - passengerOfferPrice : 0;

            return (
              <div
                key={bid.id}
                className="p-4 rounded-xl bg-purple-950/70 border border-purple-800/60 hover:border-amber-400/60 transition-all flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-lg"
              >
                <div className="flex items-start space-x-3.5">
                  <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-[#7928CA] to-[#2E0854] flex items-center justify-center font-extrabold text-amber-300 border border-purple-600/40 flex-shrink-0">
                    {bid.driverName.charAt(0)}
                  </div>
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="font-bold text-white text-sm">{bid.driverName}</span>
                      <span className="inline-flex items-center text-xs font-semibold px-2 py-0.5 rounded bg-amber-400/20 text-amber-300 border border-amber-400/30">
                        ★ {bid.driverRating.toFixed(1)}
                      </span>
                    </div>
                    <p className="text-xs text-purple-300 mt-0.5">
                      {bid.vehicleModel} • <span className="text-purple-400 font-mono">{bid.vehiclePlate}</span>
                    </p>
                    {bid.message && (
                      <p className="text-[11px] text-amber-200/90 mt-1 italic">
                        “{bid.message}”
                      </p>
                    )}
                    <div className="flex items-center space-x-3 mt-1 text-[11px] text-purple-400">
                      <span>⏱ Chega em ~{bid.etaMinutes} min</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between md:justify-end space-x-3 border-t md:border-t-0 pt-3 md:pt-0 border-purple-800/50">
                  <div className="text-left md:text-right">
                    <div className="text-lg font-black text-amber-400">
                      R$ {bid.amount.toFixed(2).replace('.', ',')}
                    </div>
                    {isExactOffer ? (
                      <span className="text-[10px] text-emerald-400 font-semibold block">
                        Aceitou seu preço exato
                      </span>
                    ) : isHigher ? (
                      <span className="text-[10px] text-purple-300 block">
                        + R$ {diffAmount.toFixed(2).replace('.', ',')} da sua oferta
                      </span>
                    ) : null}
                  </div>

                  <div className="flex items-center space-x-2">
                    <button
                      type="button"
                      disabled={isProcessing || isLoading}
                      onClick={() => handleDecline(bid.id)}
                      aria-label={`Recusar proposta de ${bid.driverName}`}
                      className="px-3 py-2 rounded-xl text-xs font-bold text-purple-300 hover:text-white bg-purple-900/40 hover:bg-purple-900 border border-purple-800/50 transition-colors disabled:opacity-50"
                    >
                      Recusar
                    </button>
                    <button
                      type="button"
                      disabled={isProcessing || isLoading}
                      onClick={() => handleAccept(bid.id)}
                      className="px-4 py-2 rounded-xl text-xs font-extrabold uppercase tracking-wider bg-gradient-to-r from-amber-400 to-amber-500 hover:brightness-110 text-purple-950 shadow-md transition-all active:scale-95 disabled:opacity-50"
                    >
                      {isProcessing ? 'Confirmando...' : 'Aceitar Condutor'}
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

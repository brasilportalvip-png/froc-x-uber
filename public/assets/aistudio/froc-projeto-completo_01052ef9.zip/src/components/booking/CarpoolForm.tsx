import React, { useState } from 'react';

export interface CarpoolItem {
  id: string;
  driverName: string;
  driverRating: number;
  driverVehicle: string;
  originCity: string;
  destinationCity: string;
  departureTime: string;
  availableSeats: number;
  pricePerSeat: number;
  baggageAllowance: string;
  allowsPets: boolean;
}

export interface CarpoolFormProps {
  onSearchResults?: (results: CarpoolItem[]) => void;
}

export const CarpoolForm: React.FC<CarpoolFormProps> = ({ onSearchResults }) => {
  const [originCity, setOriginCity] = useState('');
  const [destinationCity, setDestinationCity] = useState('');
  const [seatsNeeded, setSeatsNeeded] = useState(1);
  const [isSearching, setIsSearching] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);
  const [carpools, setCarpools] = useState<CarpoolItem[]>([]);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!originCity.trim() || originCity.trim().length < 2) {
      setErrorMessage('Informe a Cidade de Partida.');
      return;
    }
    if (!destinationCity.trim() || destinationCity.trim().length < 2) {
      setErrorMessage('Informe a Cidade de Destino.');
      return;
    }

    setIsSearching(true);
    setHasSearched(true);

    try {
      const simulatedResults: CarpoolItem[] = [
        {
          id: 'cp-sao-santos-01',
          driverName: 'Marcos Vinicius',
          driverRating: 4.96,
          driverVehicle: 'Toyota Corolla 2022',
          originCity: originCity,
          destinationCity: destinationCity,
          departureTime: 'Hoje, 17:30',
          availableSeats: 3,
          pricePerSeat: 38.0,
          baggageAllowance: '1 mala de mão + mochila',
          allowsPets: false,
        },
        {
          id: 'cp-sao-santos-02',
          driverName: 'Camila Santos',
          driverRating: 4.92,
          driverVehicle: 'Volkswagen Nivus 2023',
          originCity: originCity,
          destinationCity: destinationCity,
          departureTime: 'Amanhã, 08:00',
          availableSeats: 2,
          pricePerSeat: 42.0,
          baggageAllowance: 'Porta-malas livre',
          allowsPets: true,
        },
      ];

      setCarpools(simulatedResults);
      if (onSearchResults) {
        onSearchResults(simulatedResults);
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Falha ao pesquisar caronas disponíveis.';
      setErrorMessage(msg);
    } finally {
      setIsSearching(false);
    }
  };

  const handleReserve = (cp: CarpoolItem) => {
    const total = cp.pricePerSeat * seatsNeeded;
    alert(
      `Reserva confirmada para ${seatsNeeded} assento(s) com ${cp.driverName}.\nTotal a pagar: R$ ${total.toFixed(2).replace('.', ',')} (com taxa de custódia de 10%).`
    );
  };

  return (
    <div className="space-y-6 text-white w-full max-w-2xl mx-auto">
      <div className="p-4 rounded-xl bg-[#150724] border border-[#7928CA]/50 text-xs text-purple-200">
        <p className="font-bold text-[#FFD700] uppercase tracking-wide mb-1">
          Caronas Intermunicipais Compartilhadas (Estilo BlaBlaCar)
        </p>
        <p>
          Divida despesas de pedágio e combustível em rotas interurbanas. Os valores são retidos em custódia até a conclusão do trajeto com segurança e verificação de perfil.
        </p>
      </div>

      <form onSubmit={handleSearch} className="space-y-4 bg-[#1A0B2E] border border-[#2E0854] p-6 rounded-2xl shadow-xl">
        {errorMessage && (
          <div role="alert" className="p-3.5 rounded-xl bg-rose-950/90 border border-rose-500 text-rose-200 text-sm">
            {errorMessage}
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="carpool-origin-input" className="block text-xs font-bold uppercase tracking-wider text-purple-300 mb-1.5">
              Cidade de Origem
            </label>
            <input
              id="carpool-origin-input"
              type="text"
              required
              value={originCity}
              onChange={(e) => setOriginCity(e.target.value)}
              placeholder="Ex: São Paulo, SP"
              className="w-full px-4 py-3.5 rounded-xl bg-[#150724] border border-[#7928CA]/60 text-white placeholder-purple-400/50 focus:outline-none focus:border-[#FFD700] focus:ring-2 focus:ring-[#FFD700]/30 text-sm min-h-[48px]"
            />
          </div>

          <div>
            <label htmlFor="carpool-destination-input" className="block text-xs font-bold uppercase tracking-wider text-purple-300 mb-1.5">
              Cidade de Destino
            </label>
            <input
              id="carpool-destination-input"
              type="text"
              required
              value={destinationCity}
              onChange={(e) => setDestinationCity(e.target.value)}
              placeholder="Ex: Santos, SP"
              className="w-full px-4 py-3.5 rounded-xl bg-[#150724] border border-[#7928CA]/60 text-white placeholder-purple-400/50 focus:outline-none focus:border-[#FFD700] focus:ring-2 focus:ring-[#FFD700]/30 text-sm min-h-[48px]"
            />
          </div>
        </div>

        <div>
          <label htmlFor="carpool-seats-input" className="block text-xs font-bold uppercase tracking-wider text-purple-300 mb-1.5">
            Quantidade de Assentos
          </label>
          <select
            id="carpool-seats-input"
            value={seatsNeeded}
            onChange={(e) => setSeatsNeeded(Number(e.target.value))}
            className="w-full px-4 py-3 rounded-xl bg-[#150724] border border-[#7928CA]/60 text-white focus:outline-none focus:border-[#FFD700] text-sm min-h-[48px]"
          >
            <option value={1}>1 passageiro (1 assento)</option>
            <option value={2}>2 passageiros (2 assentos)</option>
            <option value={3}>3 passageiros (3 assentos)</option>
            <option value={4}>4 passageiros (carro fechado)</option>
          </select>
        </div>

        <button
          type="submit"
          disabled={isSearching}
          className="w-full py-4 px-6 rounded-xl bg-gradient-to-r from-[#FFD700] via-[#F5A623] to-[#FFD700] text-[#1A0B2E] font-black text-sm uppercase tracking-wider shadow-[0_4px_25px_rgba(255,215,0,0.35)] hover:brightness-110 active:scale-[0.99] disabled:opacity-50 transition-all cursor-pointer min-h-[48px]"
        >
          {isSearching ? 'Pesquisando rotas intermunicipais...' : 'Buscar Vagas de Carona'}
        </button>
      </form>

      {hasSearched && (
        <div className="space-y-4 pt-4 border-t border-[#7928CA]/60">
          <h3 className="text-sm font-bold uppercase tracking-wider text-purple-300 flex items-center justify-between">
            <span>Caronas Encontradas ({carpools.length})</span>
            <span className="text-xs text-purple-400">{originCity} → {destinationCity}</span>
          </h3>

          {carpools.map((cp) => {
            const total = cp.pricePerSeat * seatsNeeded;
            return (
              <div
                key={cp.id}
                className="p-4 rounded-xl bg-[#150724] border border-[#7928CA]/60 hover:border-[#FFD700] transition-all flex flex-wrap items-center justify-between gap-4 shadow-lg"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white text-sm">{cp.driverName}</span>
                    <span className="px-2 py-0.5 rounded-full text-xs bg-[#FFD700]/20 text-[#FFD700] font-bold border border-[#FFD700]/40">
                      ★ {cp.driverRating.toFixed(2)}
                    </span>
                    {cp.allowsPets && (
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-purple-900 text-purple-200 border border-purple-700/50">
                        Pet Friendly
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-purple-300">{cp.driverVehicle}</p>
                  <p className="text-xs text-emerald-400 font-semibold">
                    Horário: {cp.departureTime} • {cp.availableSeats} vagas restantes
                  </p>
                  <p className="text-[11px] text-purple-400">Bagagem: {cp.baggageAllowance}</p>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right mr-2">
                    <span className="text-[11px] text-purple-400 block">Por assento</span>
                    <span className="text-xl font-black text-[#FFD700]">
                      R$ {cp.pricePerSeat.toFixed(2).replace('.', ',')}
                    </span>
                    {seatsNeeded > 1 && (
                      <span className="text-[10px] text-purple-300 block">
                        Total ({seatsNeeded}x): R$ {total.toFixed(2).replace('.', ',')}
                      </span>
                    )}
                  </div>
                  <button
                    type="button"
                    onClick={() => handleReserve(cp)}
                    className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#FFD700] to-[#F5A623] hover:brightness-110 text-[#1A0B2E] font-black text-xs uppercase tracking-wider shadow-md transition-all cursor-pointer min-h-[44px]"
                  >
                    Reservar Vaga
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

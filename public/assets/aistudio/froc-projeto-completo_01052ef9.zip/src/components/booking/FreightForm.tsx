import React, { useState } from 'react';
import { CargoSpecs, VehicleCategory } from '../../types';
import { Cargo3DViewer } from '../cargo/Cargo3DViewer';

export interface FreightFormProps {
  onSimulateCargo?: (specs: CargoSpecs, estimatedCost: number) => void;
}

// Cálculo especializado para fretes e caminhões com retorno vazio
function calculateFreightQuoteLocally(params: {
  distanceKm: number;
  volumeM3: number;
  weightKg: number;
  isReturnEmptyTrip: boolean;
  helpersCount: number;
}) {
  const basePerKm = 3.80;
  const volumeCharge = params.volumeM3 * 22.0;
  const weightCharge = (params.weightKg / 1000) * 85.0;
  const helpersCharge = params.helpersCount * 120.0;

  const rawTransport = params.distanceKm * basePerKm + volumeCharge + weightCharge;
  const returnEmptyDiscount = params.isReturnEmptyTrip ? 0.35 : 0.0;
  const finalTransport = rawTransport * (1 - returnEmptyDiscount);
  const finalFare = Math.round((finalTransport + helpersCharge) * 100) / 100;
  const returnEmptySavings = params.isReturnEmptyTrip ? Math.round(rawTransport * 0.35 * 100) / 100 : 0;
  const platformFee = Math.round(finalFare * 0.08 * 100) / 100; // Taxa de 8% em cargas
  const driverPayout = Math.round((finalFare - platformFee) * 100) / 100;

  return {
    finalFare,
    returnEmptySavings,
    platformFee,
    driverPayout,
  };
}

export const FreightForm: React.FC<FreightFormProps> = ({ onSimulateCargo }) => {
  const [origin, setOrigin] = useState('');
  const [destination, setDestination] = useState('');
  const [volumeM3, setVolumeM3] = useState('14');
  const [weightKg, setWeightKg] = useState('1200');
  const [truckType, setTruckType] = useState<VehicleCategory>('truck_medium');
  const [needsHelpers, setNeedsHelpers] = useState(true);
  const [helperCount] = useState(2);
  const [isReturnTrip, setIsReturnTrip] = useState(true);
  const [hasCalculated, setHasCalculated] = useState(false);
  const [estimatedKm] = useState(180);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const numVolume = parseFloat(volumeM3) || 14;
  const numWeight = parseFloat(weightKg) || 1200;

  const pricing = calculateFreightQuoteLocally({
    distanceKm: estimatedKm,
    volumeM3: numVolume,
    weightKg: numWeight,
    isReturnEmptyTrip: isReturnTrip,
    helpersCount: needsHelpers ? helperCount : 0,
  });

  const handleCalculateFreight = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!origin.trim() || origin.trim().length < 3) {
      setErrorMessage('Informe a Origem da Carga ou Mudança.');
      return;
    }
    if (!destination.trim() || destination.trim().length < 3) {
      setErrorMessage('Informe o Destino da Carga ou Mudança.');
      return;
    }
    if (numVolume <= 0 || numVolume > 120) {
      setErrorMessage('O Volume da Carga (m³) deve estar entre 1 e 120 m³.');
      return;
    }
    if (numWeight <= 0 || numWeight > 35000) {
      setErrorMessage('O Peso Estimado (kg) deve estar entre 10 e 35.000 kg.');
      return;
    }

    setHasCalculated(true);

    const specs: CargoSpecs = {
      volumeM3: numVolume,
      weightKg: numWeight,
      helpersNeeded: needsHelpers ? helperCount : 0,
      isReturnEmpty: isReturnTrip,
      cargoType: 'mudanca',
      description: `${origin} para ${destination}`,
    };

    if (onSimulateCargo) {
      onSimulateCargo(specs, pricing.finalFare);
    }
  };

  return (
    <section data-testid="freight-request-section" className="space-y-6 text-white w-full max-w-3xl mx-auto">
      <div className="p-4 rounded-xl bg-[#150724] border border-[#7928CA]/60 text-xs text-purple-200">
        <div className="flex items-center justify-between mb-1.5">
          <span className="font-bold text-[#FFD700] uppercase tracking-wide">
            Bolsa de Cargas & Caminhões de Retorno Vazio
          </span>
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-400/20 text-emerald-300 border border-emerald-400/40">
            Economia de até 35% no Frete
          </span>
        </div>
        <p>
          Aproveite caminhões e carretas que estão retornando descarregados de viagens interestaduais ou intermunicipais. Pague menos e ajude caminhoneiros a rentabilizarem a volta com custódia segura Mercado Pago.
        </p>
      </div>

      <form onSubmit={handleCalculateFreight} className="space-y-4 bg-[#1A0B2E] border border-[#2E0854] p-6 rounded-2xl shadow-2xl">
        {errorMessage && (
          <div role="alert" className="p-3.5 rounded-xl bg-rose-950/90 border border-rose-500 text-rose-200 text-sm">
            {errorMessage}
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="input-freight-origin" className="block text-xs font-bold uppercase tracking-wider text-purple-300 mb-1.5">
              Origem da Carga / Coleta
            </label>
            <input
              id="input-freight-origin"
              data-testid="input-freight-origin"
              type="text"
              required
              value={origin}
              onChange={(e) => setOrigin(e.target.value)}
              placeholder="Porto de Santos, SP"
              className="w-full px-4 py-3.5 rounded-xl bg-[#150724] border border-[#7928CA]/60 text-white placeholder-purple-400/50 focus:outline-none focus:border-[#FFD700] focus:ring-2 focus:ring-[#FFD700]/30 text-sm min-h-[48px]"
            />
          </div>

          <div>
            <label htmlFor="input-freight-destination" className="block text-xs font-bold uppercase tracking-wider text-purple-300 mb-1.5">
              Destino da Entrega / Desembarque
            </label>
            <input
              id="input-freight-destination"
              data-testid="input-freight-destination"
              type="text"
              required
              value={destination}
              onChange={(e) => setDestination(e.target.value)}
              placeholder="São Paulo - Zona Leste"
              className="w-full px-4 py-3.5 rounded-xl bg-[#150724] border border-[#7928CA]/60 text-white placeholder-purple-400/50 focus:outline-none focus:border-[#FFD700] focus:ring-2 focus:ring-[#FFD700]/30 text-sm min-h-[48px]"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          <div>
            <label htmlFor="input-cargo-volume" className="block text-xs font-bold uppercase tracking-wider text-purple-300 mb-1.5">
              Volume da Carga (m³)
            </label>
            <input
              id="input-cargo-volume"
              data-testid="input-cargo-volume"
              type="number"
              min="0.5"
              max="120"
              step="0.5"
              required
              value={volumeM3}
              onChange={(e) => setVolumeM3(e.target.value)}
              placeholder="14"
              className="w-full px-4 py-3.5 rounded-xl bg-[#150724] border border-[#7928CA]/60 text-white focus:outline-none focus:border-[#FFD700] text-sm font-bold min-h-[48px]"
            />
          </div>

          <div>
            <label htmlFor="input-cargo-weight" className="block text-xs font-bold uppercase tracking-wider text-purple-300 mb-1.5">
              Peso Estimado (kg)
            </label>
            <input
              id="input-cargo-weight"
              data-testid="input-cargo-weight"
              type="number"
              min="10"
              max="35000"
              step="10"
              required
              value={weightKg}
              onChange={(e) => setWeightKg(e.target.value)}
              placeholder="1200"
              className="w-full px-4 py-3.5 rounded-xl bg-[#150724] border border-[#7928CA]/60 text-white focus:outline-none focus:border-[#FFD700] text-sm font-bold min-h-[48px]"
            />
          </div>

          <div>
            <label htmlFor="freight-truck-type-select" className="block text-xs font-bold uppercase tracking-wider text-purple-300 mb-1.5">
              Tipo de Compartimento
            </label>
            <select
              id="freight-truck-type-select"
              value={truckType}
              onChange={(e) => setTruckType(e.target.value as VehicleCategory)}
              className="w-full px-4 py-3.5 rounded-xl bg-[#150724] border border-[#7928CA]/60 text-white focus:outline-none focus:border-[#FFD700] text-sm min-h-[48px]"
            >
              <option value="truck_light">Caminhão 3/4 Baú (até 28 m³)</option>
              <option value="truck_medium">Caminhão Toco Baú (até 45 m³)</option>
              <option value="truck_heavy">Carreta Baú Sider (até 110 m³)</option>
              <option value="van">Van de Carga (até 8 m³)</option>
            </select>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-[#150724] border border-[#7928CA]/40 grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <label className="flex items-center gap-3 cursor-pointer">
            <input
              type="checkbox"
              checked={isReturnTrip}
              onChange={(e) => setIsReturnTrip(e.target.checked)}
              className="w-4 h-4 rounded border-[#7928CA] bg-purple-900 text-[#FFD700] focus:ring-[#FFD700]"
            />
            <div>
              <span className="font-bold text-white block">Aproveitar Retorno Vazio</span>
              <span className="text-purple-300/80">Desconto de até 35% por utilizar espaço ocioso de volta.</span>
            </div>
          </label>

          <label className="flex items-center gap-3 cursor-pointer">
            <input
              type="checkbox"
              checked={needsHelpers}
              onChange={(e) => setNeedsHelpers(e.target.checked)}
              className="w-4 h-4 rounded border-[#7928CA] bg-purple-900 text-[#FFD700] focus:ring-[#FFD700]"
            />
            <div>
              <span className="font-bold text-white block">Ajudantes Especializados ({helperCount})</span>
              <span className="text-purple-300/80">Auxílio profissional na carga e descarga.</span>
            </div>
          </label>
        </div>

        {/* Visualizador 3D de Cubagem interativo sempre acessível */}
        <Cargo3DViewer
          volumeM3={numVolume}
          maxVolumeM3={35}
          weightKg={numWeight}
          maxWeightKg={8000}
          isReturnTrip={isReturnTrip}
          truckType="Caminhão Toco Baú (Retorno Vazio Autorizado)"
        />

        <button
          type="submit"
          data-testid="btn-calculate-freight"
          className="w-full py-4 px-6 rounded-xl bg-gradient-to-r from-[#FFD700] via-[#F5A623] to-[#FFD700] text-[#1A0B2E] font-black text-sm uppercase tracking-wider shadow-[0_4px_25px_rgba(255,215,0,0.35)] hover:brightness-110 active:scale-[0.99] transition-all cursor-pointer min-h-[48px]"
        >
          Calcular Cotação de Frete & Verificar Caminhões
        </button>
      </form>

      {hasCalculated && (
        <div
          data-testid="freight-quote-summary"
          className="p-5 rounded-2xl bg-gradient-to-br from-[#260E43] to-[#1A0B2E] border-2 border-[#FFD700] shadow-2xl space-y-4 animate-fadeIn"
        >
          <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-[#7928CA]/40">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-[#FFD700] block">
                Cotação Oficial de Frete & Mudança
              </span>
              <h3 className="text-lg font-black text-white">
                {origin} ➔ {destination} (~{estimatedKm} km)
              </h3>
            </div>
            <div className="text-right">
              <span className="text-xs text-purple-300 block font-semibold">Valor sob Custódia Escrow</span>
              <span className="text-2xl font-black text-[#FFD700]">
                R$ {pricing.finalFare.toFixed(2).replace('.', ',')}
              </span>
              {isReturnTrip && (
                <span className="text-xs text-emerald-400 block font-bold">
                  Economia garantida: R$ {pricing.returnEmptySavings.toFixed(2).replace('.', ',')}
                </span>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div className="p-3 bg-[#150724] rounded-xl border border-purple-800/40">
              <span className="text-purple-400 font-bold uppercase text-[10px]">Cubagem Alocada</span>
              <p className="text-white font-bold text-sm mt-0.5">{numVolume} m³ • {numWeight} kg</p>
              <p className="text-purple-300 text-[11px]">{needsHelpers ? `${helperCount} ajudantes inclusos` : 'Sem ajudantes'}</p>
            </div>
            <div className="p-3 bg-[#150724] rounded-xl border border-purple-800/40">
              <span className="text-purple-400 font-bold uppercase text-[10px]">Garantia & Repasse</span>
              <p className="text-emerald-400 font-bold text-sm mt-0.5">Custódia Mercado Pago Ativa</p>
              <p className="text-purple-300 text-[11px]">Repasse liberado apenas com PIN de entrega</p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              alert('Ordem de frete transmitida com sucesso para motoristas de caminhão credenciados na rota!');
            }}
            className="w-full py-4 px-6 rounded-xl bg-gradient-to-r from-[#FFD700] to-[#F5A623] hover:brightness-110 text-[#1A0B2E] font-black text-sm uppercase tracking-wider shadow-lg transition-all cursor-pointer min-h-[48px]"
          >
            Contratar Frete com Garantia Escrow
          </button>
        </div>
      )}
    </section>
  );
};

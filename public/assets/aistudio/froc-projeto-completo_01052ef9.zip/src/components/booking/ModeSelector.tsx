import React from 'react';
import { ServiceMode } from '../../types';

export interface ModeSelectorProps {
  activeMode: ServiceMode;
  onSelectMode: (mode: ServiceMode) => void;
}

interface ModeOption {
  id: ServiceMode;
  name: string;
  badge: string;
  description: string;
  icon: React.ReactNode;
}

const MODES: ModeOption[] = [
  {
    id: 'direct',
    name: 'Urbana Direta',
    badge: 'Taxa 12%',
    description: 'Carro particular imediato estilo Uber/99 com tarifa garantida.',
    icon: (
      <svg aria-hidden="true" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2" />
        <circle cx="7" cy="17" r="2" />
        <path d="M9 17h6" />
        <circle cx="17" cy="17" r="2" />
      </svg>
    ),
  },
  {
    id: 'negotiated',
    name: 'Negociada (inDrive)',
    badge: 'Você propõe',
    description: 'Defina sua oferta de preço e receba contrapropostas em leilão aberto.',
    icon: (
      <svg aria-hidden="true" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <line x1="12" y1="1" x2="12" y2="23" />
        <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
      </svg>
    ),
  },
  {
    id: 'carpool',
    name: 'Carona Compartilhada',
    badge: 'Econômico',
    description: 'Viagens interurbanas programadas por assento estilo BlaBlaCar.',
    icon: (
      <svg aria-hidden="true" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
        <circle cx="9" cy="7" r="4" />
        <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
        <path d="M16 3.13a4 4 0 0 1 0 7.75" />
      </svg>
    ),
  },
  {
    id: 'freight',
    name: 'Caminhão / Frete Retorno',
    badge: 'Até -40%',
    description: 'Mudanças e cargas em caminhões retornando vazios com cubagem 3D.',
    icon: (
      <svg aria-hidden="true" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <rect x="1" y="3" width="15" height="13" />
        <polygon points="16 8 20 8 23 11 23 16 16 16 16 8" />
        <circle cx="5.5" cy="18.5" r="2.5" />
        <circle cx="18.5" cy="18.5" r="2.5" />
      </svg>
    ),
  },
];

export const ModeSelector: React.FC<ModeSelectorProps> = ({ activeMode, onSelectMode }) => {
  return (
    <section
      aria-label="Seleção de modalidade de transporte"
      data-testid="mode-selector"
      className="mode-selector-wrapper w-full mb-6"
    >
      <div
        role="tablist"
        aria-label="Modalidades Froc X Uber 4 em 1"
        className="grid grid-cols-2 md:grid-cols-4 gap-2.5 p-2 bg-[#1A0B2E]/90 border border-[#2E0854] rounded-2xl shadow-xl backdrop-blur-md"
      >
        {MODES.map((mode) => {
          const isSelected = activeMode === mode.id;
          return (
            <button
              key={mode.id}
              type="button"
              role="tab"
              id={`tab-${mode.id}`}
              data-testid={`mode-tab-${mode.id}`}
              aria-controls={`panel-${mode.id}`}
              aria-selected={isSelected}
              tabIndex={isSelected ? 0 : -1}
              onClick={() => onSelectMode(mode.id)}
              className={`group relative flex flex-col items-start p-3.5 rounded-xl text-left transition-all duration-200 outline-none focus-visible:ring-2 focus-visible:ring-[#FFD700] ${
                isSelected
                  ? 'bg-gradient-to-br from-[#7928CA]/90 to-[#2E0854] border border-[#FFD700] shadow-[0_0_20px_rgba(255,215,0,0.25)] text-white'
                  : 'bg-[#150724]/70 hover:bg-[#260E43] border border-[#2E0854]/60 text-purple-200 hover:text-white'
              }`}
            >
              <div className="flex items-center justify-between w-full mb-2">
                <span
                  className={`p-2 rounded-lg transition-colors ${
                    isSelected
                      ? 'bg-[#FFD700] text-[#0D0417] shadow-md'
                      : 'bg-purple-900/60 text-[#FFD700] group-hover:bg-purple-800/80'
                  }`}
                >
                  {mode.icon}
                </span>
                <span
                  className={`text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full border ${
                    isSelected
                      ? 'bg-[#FFD700]/20 text-[#FFD700] border-[#FFD700]/50'
                      : 'bg-purple-950/80 text-purple-300 border-purple-700/50'
                  }`}
                >
                  {mode.badge}
                </span>
              </div>

              <span className="font-bold text-sm tracking-tight leading-snug text-white">
                {mode.name}
              </span>
              <span className="text-[11px] text-purple-300/80 mt-1 line-clamp-2 leading-relaxed">
                {mode.description}
              </span>

              {isSelected && (
                <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-8 h-1 bg-[#FFD700] rounded-full shadow-[0_0_8px_#FFD700]" />
              )}
            </button>
          );
        })}
      </div>
    </section>
  );
};

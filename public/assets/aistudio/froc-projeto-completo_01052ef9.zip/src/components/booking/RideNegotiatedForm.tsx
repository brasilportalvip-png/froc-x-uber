import React, { useState } from 'react';
import { Trip, Bid } from '../../types';
import { useTrip } from '../../context/TripContext';

export interface RideNegotiatedFormProps {
  onAuctionStarted?: (trip: Trip) => void;
}

// Cálculo seguro do piso regulatório para evitar tarifas predatórias
function getRegulatoryFloorLocally(km: number = 11.2, mins: number = 22): number {
  const base = 7.0;
  const costPerKm = 1.85;
  const costPerMin = 0.25;
  return Math.max(15.0, Math.round((base + km * costPerKm + mins * costPerMin) * 100) / 100);
}

export const RideNegotiatedForm: React.FC<RideNegotiatedFormProps> = ({ onAuctionStarted }) => {
  const { createNegotiatedRide } = useTrip();
  const [origin, setOrigin] = useState('');
  const [destination, setDestination] = useState('');
  const [userOffer, setUserOffer] = useState('');
  const [estimatedKm] = useState(11.2);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [auctionTrip, setAuctionTrip] = useState<Trip | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [bids, setBids] = useState<Bid[]>([]);

  const regulatoryFloor = getRegulatoryFloorLocally(estimatedKm, 22);
  const parsedOffer = parseFloat(userOffer.replace(',', '.')) || 0;
  const isBelowFloor = parsedOffer > 0 && parsedOffer < regulatoryFloor;

  const handleSubmitAuction = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!origin.trim() || origin.trim().length < 3) {
      setErrorMessage('Informe o Ponto de Partida.');
      return;
    }
    if (!destination.trim() || destination.trim().length < 3) {
      setErrorMessage('Informe o Ponto de Destino.');
      return;
    }
    if (parsedOffer < regulatoryFloor) {
      setErrorMessage(`Sua oferta de R$ ${parsedOffer.toFixed(2).replace('.', ',')} é inferior ao piso regulatório de R$ ${regulatoryFloor.toFixed(2).replace('.', ',')}.`);
      return;
    }

    setIsSubmitting(true);
    try {
      const active = await createNegotiatedRide(origin, destination, parsedOffer);

      const initialCounterBids: Bid[] = [
        {
          id: `bid-1-${Date.now()}`,
          tripId: active.id,
          driverId: 'drv-carlos-indrive',
          driverName: 'Carlos Eduardo Santos',
          driverRating: 4.96,
          driverPhone: '+55 11 97777-1111',
          driverVehicle: {
            model: 'Chevrolet Onix Plus 2023 - Prata',
            plate: 'FRO-9201',
            color: 'Prata',
            category: 'popular',
          },
          amount: Math.max(parsedOffer, 35.00),
          etaMinutes: 3,
          message: 'Estou a 3 quadras de você, ar condicionado ligado.',
          status: 'pending',
          createdAt: new Date().toISOString(),
        },
        {
          id: `bid-2-${Date.now()}`,
          tripId: active.id,
          driverId: 'drv-renata-indrive',
          driverName: 'Renata L. Faria',
          driverRating: 4.91,
          driverPhone: '+55 11 96666-2222',
          driverVehicle: {
            model: 'Hyundai HB20 2022 - Branco',
            plate: 'IND-4412',
            color: 'Branco',
            category: 'popular',
          },
          amount: parsedOffer + 4.00,
          etaMinutes: 5,
          message: 'Chegada rápida em 5 minutos.',
          status: 'pending',
          createdAt: new Date().toISOString(),
        },
      ];

      const tripModel: Trip = {
        id: active.id || `trip-neg-${Date.now()}`,
        customerId: 'usr-guest',
        customerName: 'Passageiro Froc',
        customerPhone: '+55 11 98888-0000',
        mode: 'negotiated',
        origin: { address: origin, city: 'Campinas', state: 'SP' },
        destination: { address: destination, city: 'Campinas', state: 'SP' },
        distanceKm: estimatedKm,
        durationMinutes: 22,
        initialOfferPrice: parsedOffer,
        finalAgreedPrice: parsedOffer,
        platformFee: parsedOffer * 0.12,
        driverPayout: parsedOffer * 0.88,
        currency: 'BRL',
        status: 'bidding',
        pinCode: active.securityPin || '6319',
        paymentStatus: 'pending',
        createdAt: active.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      setAuctionTrip(tripModel);
      setBids(initialCounterBids);
      if (onAuctionStarted) {
        onAuctionStarted(tripModel);
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Falha ao registrar oferta no leilão.';
      setErrorMessage(msg);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleAcceptBid = (bid: Bid) => {
    alert(`Contraproposta de ${bid.driverName} aceita por R$ ${bid.amount.toFixed(2).replace('.', ',')}. Condutor a caminho!`);
  };

  return (
    <div className="space-y-6 text-white w-full max-w-2xl mx-auto">
      {auctionTrip ? (
        <div data-testid="bid-waiting-area" className="space-y-5 animate-fadeIn">
          <div className="p-5 rounded-2xl bg-gradient-to-br from-[#260E43] to-[#1A0B2E] border-2 border-[#FFD700] shadow-2xl">
            <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-[#7928CA]/40">
              <div>
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-[#FFD700]/20 text-[#FFD700] border border-[#FFD700]/40">
                  <span className="w-2 h-2 rounded-full bg-[#FFD700] animate-ping" />
                  Leilão de Lances Ativo (Estilo inDrive)
                </span>
                <h3 className="text-lg font-bold text-white mt-2">Aguardando Contrapropostas de Motoristas</h3>
              </div>
              <div className="text-right">
                <span className="text-xs text-purple-300 block font-semibold">Sua Oferta Proposta</span>
                <span className="text-2xl font-black text-[#FFD700]">
                  R$ {parsedOffer.toFixed(2).replace('.', ',')}
                </span>
              </div>
            </div>

            <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
              <div className="p-3 bg-[#150724] rounded-xl border border-purple-800/40">
                <span className="text-purple-400 uppercase font-bold text-[10px]">Origem</span>
                <p className="text-white font-medium truncate">{auctionTrip.origin.address}</p>
              </div>
              <div className="p-3 bg-[#150724] rounded-xl border border-purple-800/40">
                <span className="text-purple-400 uppercase font-bold text-[10px]">Destino</span>
                <p className="text-white font-medium truncate">{auctionTrip.destination.address}</p>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-bold uppercase tracking-wider text-purple-300">
                Lances e Contrapropostas Recebidas ({bids.length})
              </h4>
              <span className="text-xs font-mono font-bold px-2.5 py-1 rounded-full bg-purple-900 text-[#FFD700] border border-[#FFD700]/30">
                Temporizador: 58s restantes
              </span>
            </div>

            {bids.map((bid) => (
              <div
                key={bid.id}
                className="p-4 rounded-xl bg-[#150724] border border-[#7928CA]/50 hover:border-[#FFD700] transition-all flex flex-wrap items-center justify-between gap-4 shadow-lg"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white text-sm">{bid.driverName}</span>
                    <span className="px-2 py-0.5 rounded-full text-xs bg-[#FFD700]/20 text-[#FFD700] font-bold border border-[#FFD700]/40">
                      ★ {bid.driverRating.toFixed(2)}
                    </span>
                  </div>
                  <p className="text-xs text-purple-300">{bid.driverVehicle.model} ({bid.driverVehicle.plate})</p>
                  <p className="text-xs text-emerald-400 font-semibold">
                    Chegada estimada: {bid.etaMinutes} minutos • {bid.message}
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right mr-2">
                    <span className="text-[11px] text-purple-400 block">Valor Ofertado</span>
                    <span className="text-xl font-black text-[#FFD700]">
                      R$ {bid.amount.toFixed(2).replace('.', ',')}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleAcceptBid(bid)}
                    className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#FFD700] to-[#F5A623] hover:brightness-110 text-[#1A0B2E] font-black text-xs uppercase tracking-wider shadow-md transition-all cursor-pointer min-h-[44px]"
                  >
                    Aceitar Lance
                  </button>
                </div>
              </div>
            ))}
          </div>

          <button
            type="button"
            onClick={() => setAuctionTrip(null)}
            className="w-full py-3.5 rounded-xl bg-[#200C38] hover:bg-purple-900 text-purple-200 text-xs font-bold uppercase tracking-wider border border-purple-700/60 transition-colors cursor-pointer min-h-[48px]"
          >
            Cancelar Leilão e Redefinir Oferta
          </button>
        </div>
      ) : (
        <form
          data-testid="ride-negotiated-form"
          onSubmit={handleSubmitAuction}
          className="space-y-5 bg-[#1A0B2E] border border-[#2E0854] p-6 rounded-2xl shadow-2xl"
        >
          <div className="flex items-center justify-between pb-3 border-b border-[#2E0854]">
            <div className="flex items-center space-x-2">
              <span className="w-3 h-3 rounded-full bg-[#F5A623]" />
              <h2 className="text-lg font-extrabold text-white">
                Corrida Negociada em Lances
              </h2>
            </div>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-[#F5A623]/20 text-[#F5A623] border border-[#F5A623]/40">
              Estilo inDrive
            </span>
          </div>

          {errorMessage && (
            <div
              role="alert"
              className="p-4 rounded-xl bg-rose-950/90 border border-rose-500 text-rose-200 text-sm flex items-center gap-3"
            >
              <span>⚠️</span>
              <span>{errorMessage}</span>
            </div>
          )}

          <div className="p-4 rounded-xl bg-[#150724] border border-[#7928CA]/50 text-xs text-purple-200 space-y-1.5">
            <p className="font-bold text-[#FFD700] uppercase tracking-wide">Como funciona o leilão reverso?</p>
            <p>
              Você sugere o valor que deseja pagar. Motoristas cadastrados nas redondezas veem seu pedido e podem aceitar seu preço ou fazer contrapropostas durante 60 segundos.
            </p>
          </div>

          <div className="space-y-4">
            <div>
              <label htmlFor="input-negotiated-origin" className="block text-xs font-bold uppercase tracking-wider text-purple-300 mb-1.5">
                Ponto de Partida
              </label>
              <input
                id="input-negotiated-origin"
                data-testid="input-negotiated-origin"
                type="text"
                required
                value={origin}
                onChange={(e) => setOrigin(e.target.value)}
                placeholder="Centro, Campinas"
                className="w-full px-4 py-3.5 rounded-xl bg-[#150724] border border-[#7928CA]/60 text-white placeholder-purple-400/50 focus:outline-none focus:border-[#FFD700] focus:ring-2 focus:ring-[#FFD700]/30 transition-all text-sm min-h-[48px]"
              />
            </div>

            <div>
              <label htmlFor="input-negotiated-destination" className="block text-xs font-bold uppercase tracking-wider text-purple-300 mb-1.5">
                Destino da Corrida
              </label>
              <input
                id="input-negotiated-destination"
                data-testid="input-negotiated-destination"
                type="text"
                required
                value={destination}
                onChange={(e) => setDestination(e.target.value)}
                placeholder="Barão Geraldo, Campinas"
                className="w-full px-4 py-3.5 rounded-xl bg-[#150724] border border-[#7928CA]/60 text-white placeholder-purple-400/50 focus:outline-none focus:border-[#FFD700] focus:ring-2 focus:ring-[#FFD700]/30 transition-all text-sm min-h-[48px]"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label htmlFor="input-negotiated-offer" className="text-xs font-bold uppercase tracking-wider text-purple-300">
                  Sua Oferta Proposta (R$)
                </label>
                <span className="text-[11px] text-[#FFD700] font-semibold">
                  Piso regulatório mínimo: R$ {regulatoryFloor.toFixed(2).replace('.', ',')}
                </span>
              </div>

              <div className="relative">
                <span className="absolute left-4 top-3.5 text-[#FFD700] font-black text-base">R$</span>
                <input
                  id="input-negotiated-offer"
                  data-testid="input-negotiated-offer"
                  type="text"
                  required
                  value={userOffer}
                  onChange={(e) => setUserOffer(e.target.value.replace(/[^0-9,.]/g, ''))}
                  placeholder="35.00"
                  className={`w-full pl-12 pr-4 py-3.5 rounded-xl bg-[#150724] border text-white font-black text-lg focus:outline-none transition-all min-h-[48px] ${isBelowFloor
                    ? 'border-rose-500 focus:ring-2 focus:ring-rose-500/30'
                    : 'border-[#7928CA]/60 focus:border-[#FFD700] focus:ring-2 focus:ring-[#FFD700]/30'}`}
                />
              </div>
              {isBelowFloor && (
                <p className="text-xs text-rose-400 mt-1 font-medium">
                  A oferta não pode ser inferior a R$ {regulatoryFloor.toFixed(2).replace('.', ',')} para cobrir despesas de rodagem e combustível.
                </p>
              )}
            </div>
          </div>

          <button
            type="submit"
            data-testid="btn-submit-negotiated-offer"
            disabled={isSubmitting || isBelowFloor}
            className="w-full py-4 px-6 rounded-xl bg-gradient-to-r from-[#FFD700] via-[#F5A623] to-[#FFD700] text-[#1A0B2E] font-black text-sm uppercase tracking-wider shadow-[0_4px_25px_rgba(255,215,0,0.35)] hover:brightness-110 active:scale-[0.99] disabled:opacity-50 transition-all cursor-pointer min-h-[48px]"
          >
            {isSubmitting ? 'Iniciando Leilão de Lances...' : 'Propor Valor e Abrir Lances'}
          </button>
        </form>
      )}
    </div>
  );
};

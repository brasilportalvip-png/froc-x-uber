import React, { useState } from 'react';
import { Badge } from '../ui/Badge';

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: 'direct' | 'negotiated' | 'carpool' | 'freight' | 'escrow';
  categoryLabel: string;
  itemTestId?: string;
  answerTestId?: string;
}

const FAQ_DATABASE: FAQItem[] = [
  {
    id: 'faq-freight-escrow',
    category: 'freight',
    categoryLabel: 'Caminhões & Frete de Retorno',
    question: 'Como funciona o Frete de Retorno com pagamento em custódia (escrow)?',
    answer:
      'O valor total do frete de retorno ou mudança permanece retido com segurança em regime de custódia financeira (escrow) pelo Mercado Pago. O caminhoneiro só recebe o repasse após a conferência digital do código PIN de segurança ou entrega da carga no destino.',
    itemTestId: 'faq-item-escrow',
    answerTestId: 'faq-answer-escrow',
  },
  {
    id: 'faq-1',
    category: 'freight',
    categoryLabel: 'Caminhões & Frete de Retorno',
    question: 'Como funciona o Frete de Retorno para caminhoneiros?',
    answer:
      'O Frete de Retorno aproveita o trajeto de um caminhoneiro que já realizou uma entrega e voltaria com a carroceria vazia para sua base. O embarcador consegue tarifas até 40% mais baixas e o motorista rentabiliza o retorno com custos de combustível e pedágio totalmente cobertos.',
  },
  {
    id: 'faq-2',
    category: 'escrow',
    categoryLabel: 'Custódia & Pagamentos',
    question: 'Como o pagamento em custódia (escrow) protege passageiros e motoristas?',
    answer:
      'O valor total da corrida ou frete é processado via Mercado Pago no momento da solicitação e permanece retido com segurança na plataforma. O repasse ao condutor só é liberado mediante inserção do código PIN de segurança ou assinatura do comprovante eletrônico de entrega da carga.',
  },
  {
    id: 'faq-3',
    category: 'negotiated',
    categoryLabel: 'Negociada (inDrive)',
    question: 'Qual a diferença entre a modalidade Direta e a Negociada?',
    answer:
      'Na Urbana Direta a tarifa é calculada e fixada de imediato com base na distância e tempo, assegurando aceitação rápida. Na modalidade Negociada, o passageiro define sua própria oferta inicial respeitando o piso regulatório e recebe contrapropostas diretas de motoristas próximos em leilão dinâmico de 60 segundos.',
  },
  {
    id: 'faq-4',
    category: 'carpool',
    categoryLabel: 'Carona Compartilhada',
    question: 'Como funciona a divisão de custos em caronas interurbanas estilo BlaBlaCar?',
    answer:
      'O motorista cadastra sua viagem programada com origem, destino e assentos disponíveis. Os passageiros reservam por assento contribuindo com os custos reais de deslocamento (combustível e pedágio). A plataforma retém uma comissão justa de 10% para manutenção do seguro e suporte 24h.',
  },
  {
    id: 'faq-5',
    category: 'freight',
    categoryLabel: 'Caminhões & Frete de Retorno',
    question: 'Como é calculada a cubagem volumétrica (m³) para mudanças residenciais?',
    answer:
      'O cálculo da cubagem multiplica Comprimento × Largura × Altura da carga em metros. Nosso simulador 3D permite visualizar antecipadamente o espaço ocupado no baú do caminhão (ex: toco de 28m³ ou truck de 45m³), permitindo orçamentos precisos com opção de inclusão de ajudantes para carga e descarga.',
  },
  {
    id: 'faq-6',
    category: 'direct',
    categoryLabel: 'Urbana Direta',
    question: 'Quais são as taxas cobradas dos motoristas parceiros?',
    answer:
      'A Froc X Uber pratica comissões transparentes e significativamente menores do que os aplicativos concorrentes: 12% para corridas urbanas diretas, 10% para caronas interurbanas e apenas 8% para fretes pesados e mudanças em caminhões de retorno.',
  },
];

export const FAQSection: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedId, setExpandedId] = useState<string | null>('faq-freight-escrow');

  const categories = [
    { id: 'all', label: 'Todas as Dúvidas' },
    { id: 'freight', label: 'Caminhão / Frete Retorno', testId: 'faq-category-freight' },
    { id: 'negotiated', label: 'Negociada (inDrive)' },
    { id: 'carpool', label: 'Carona (BlaBla)' },
    { id: 'direct', label: 'Urbana Direta' },
    { id: 'escrow', label: 'Custódia & Segurança' },
  ];

  const filteredFaqs = FAQ_DATABASE.filter((item) => {
    const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;
    const matchesQuery =
      item.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.answer.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesQuery;
  });

  return (
    <section
      data-testid="faq-container"
      className="w-full max-w-4xl mx-auto py-8 px-4 text-white"
      aria-labelledby="faq-heading"
    >
      <div className="text-center mb-10">
        <Badge variant="gold" className="mb-3">
          Transparência & Conformidade 4 em 1
        </Badge>
        <h2 id="faq-heading" className="text-2xl sm:text-4xl font-extrabold tracking-tight text-white">
          Central de Ajuda e Regras Operacionais
        </h2>
        <p className="text-sm text-purple-300/80 mt-2 max-w-xl mx-auto">
          Tire dúvidas sobre corridas urbanas, leilão de lances, caronas compartilhadas, frete com baú vazio e retenção em custódia.
        </p>

        <div className="mt-6 max-w-md mx-auto relative">
          <input
            type="search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Buscar dúvida ou palavra-chave (ex: retorno, PIN, baú)..."
            className="w-full px-4 py-3 rounded-xl bg-[#150724] border border-[#7928CA]/40 text-white placeholder-purple-400/40 text-sm focus:outline-none focus:border-[#FFD700] focus:ring-2 focus:ring-[#FFD700]/20 min-h-[48px]"
          />
        </div>
      </div>

      <div className="flex flex-wrap gap-2 justify-center mb-8" role="tablist" aria-label="Categorias de FAQ">
        {categories.map((cat) => (
          <button
            key={cat.id}
            data-testid={cat.testId}
            type="button"
            onClick={() => setSelectedCategory(cat.id)}
            className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all min-h-[38px] ${
              selectedCategory === cat.id
                ? 'bg-[#FFD700] text-[#0D0417] shadow-[0_0_15px_rgba(255,215,0,0.3)]'
                : 'bg-purple-950/60 text-purple-200 hover:bg-purple-900 border border-purple-800/40'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      <div className="space-y-3">
        {filteredFaqs.length === 0 ? (
          <div className="text-center py-12 p-6 rounded-2xl bg-purple-950/20 border border-purple-800/30 text-purple-300">
            Nenhuma dúvida encontrada para a busca informada.
          </div>
        ) : (
          filteredFaqs.map((faq) => {
            const isOpen = expandedId === faq.id;
            return (
              <div
                key={faq.id}
                className="rounded-xl border border-[#2E0854] bg-[#1A0B2E]/90 overflow-hidden transition-all duration-200 hover:border-[#FFD700]/40"
              >
                <button
                  type="button"
                  data-testid={faq.itemTestId}
                  onClick={() => setExpandedId(isOpen ? null : faq.id)}
                  aria-expanded={isOpen}
                  aria-controls={`faq-answer-${faq.id}`}
                  className="w-full p-4 sm:p-5 text-left flex items-center justify-between gap-4 select-none min-h-[48px] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#FFD700]"
                >
                  <div className="flex items-center gap-3">
                    <Badge variant={faq.category === 'freight' ? 'return-freight' : 'purple'}>
                      {faq.categoryLabel}
                    </Badge>
                    <span className="font-bold text-sm sm:text-base text-white leading-snug">
                      {faq.question}
                    </span>
                  </div>
                  <span
                    className={`text-[#FFD700] text-sm transition-transform duration-200 flex-shrink-0 ${
                      isOpen ? 'rotate-180' : ''
                    }`}
                    aria-hidden="true"
                  >
                    ▼
                  </span>
                </button>

                {isOpen && (
                  <div
                    id={`faq-answer-${faq.id}`}
                    data-testid={faq.answerTestId}
                    className="px-4 pb-5 sm:px-5 sm:pb-6 text-xs sm:text-sm text-purple-200/90 leading-relaxed border-t border-purple-900/40 pt-4 animate-fadeIn"
                  >
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </section>
  );
};

import React, { useState } from 'react';
import { TripStatus } from '../../types';

export interface TripStatusTrackerProps {
  status?: TripStatus | string;
  securityPin?: string;
  driverName?: string;
  driverPhone?: string;
  vehicleModel?: string;
  vehiclePlate?: string;
  amount?: number;
  escrowStatus?: 'none' | 'held' | 'released' | 'refunded' | string;
  onConfirmDropoffPin?: (pin: string) => Promise<boolean>;
  onCancel?: () => Promise<void>;
}

interface StepDefinition {
  key: string;
  label: string;
  description: string;
}

const STEPS: StepDefinition[] = [
  { key: 'searching', label: 'Buscando', description: 'Localizando condutor ou caminhão' },
  { key: 'bidding', label: 'Leilão Ativo', description: 'Recebendo contrapropostas de motoristas' },
  { key: 'accepted', label: 'Confirmado', description: 'Condutor a caminho do embarque' },
  { key: 'in_transit', label: 'Em Trânsito', description: 'Deslocamento com custódia blindada' },
  { key: 'delivered', label: 'Concluído', description: 'PIN verificado e repasse liberado' },
];

export const TripStatusTracker: React.FC<TripStatusTrackerProps> = ({
  status = 'in_transit',
  securityPin = '8492',
  driverName = 'Carlos Eduardo Transportes',
  driverPhone = '+55 11 98888-7766',
  vehicleModel = 'Toyota Corolla Híbrido',
  vehiclePlate = 'BRA-2E19',
  amount = 42.50,
  escrowStatus = 'held',
  onConfirmDropoffPin,
  onCancel,
}) => {
  const [inputPin, setInputPin] = useState('');
  const [pinError, setPinError] = useState<string | null>(null);
  const [pinSuccess, setPinSuccess] = useState<boolean>(false);
  const [isVerifyingPin, setIsVerifyingPin] = useState<boolean>(false);

  const currentStepIndex = STEPS.findIndex((s) => s.key === status);
  const activeIndex = currentStepIndex !== -1 ? currentStepIndex : 3;

  const handlePinSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setPinError(null);
    if (inputPin.trim().length !== 4) {
      setPinError('O código PIN deve conter exatamente 4 dígitos numéricos.');
      return;
    }

    setIsVerifyingPin(true);
    try {
      if (onConfirmDropoffPin) {
        const ok = await onConfirmDropoffPin(inputPin.trim());
        if (ok) {
          setPinSuccess(true);
        } else {
          setPinError('Código PIN inválido. Confirme o código diretamente com o solicitante.');
        }
      } else if (inputPin.trim() === securityPin) {
        setPinSuccess(true);
      } else {
        setPinError('Código PIN incorreto.');
      }
    } finally {
      setIsVerifyingPin(false);
    }
  };

  return (
    <div
      data-testid="trip-status-tracker"
      className="p-6 rounded-2xl bg-gradient-to-b from-[#200C38] to-[#120720] border border-[#2E0854] shadow-2xl text-white space-y-6"
    >
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-purple-800/60 gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-[#FFD700] block mb-1">
            Acompanhamento em Tempo Real
          </span>
          <h2 className="text-xl font-extrabold text-white">
            Telemetria da Viagem
          </h2>
        </div>

        <div className="flex items-center space-x-3 bg-purple-950/80 px-4 py-2 rounded-xl border border-[#FFD700]/30">
          <div>
            <span className="text-[10px] text-purple-300 uppercase tracking-wider block font-bold">
              Código PIN de Segurança
            </span>
            <span className="text-2xl font-mono font-black text-[#FFD700] tracking-widest">
              {securityPin || '8492'}
            </span>
          </div>
        </div>
      </div>

      <div className="relative">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          {STEPS.map((step, idx) => {
            const isDone = idx < activeIndex || status === 'delivered' || status === 'completed';
            const isCurrent = idx === activeIndex && status !== 'delivered' && status !== 'completed';
            return (
              <div
                key={step.key}
                className={`p-3 rounded-xl border transition-all ${
                  isCurrent
                    ? 'bg-purple-900/90 border-[#FFD700] shadow-[0_0_15px_rgba(255,215,0,0.25)] text-white'
                    : isDone
                    ? 'bg-purple-950/60 border-emerald-500/50 text-emerald-300'
                    : 'bg-purple-950/30 border-purple-900/40 text-purple-400 opacity-60'
                }`}
              >
                <div className="flex items-center space-x-2 mb-1">
                  <span
                    className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black ${
                      isDone
                        ? 'bg-emerald-500 text-black'
                        : isCurrent
                        ? 'bg-[#FFD700] text-black animate-pulse'
                        : 'bg-purple-800 text-purple-300'
                    }`}
                  >
                    {isDone ? '✓' : idx + 1}
                  </span>
                  <span className="font-bold text-xs truncate">{step.label}</span>
                </div>
                <p className="text-[11px] leading-tight opacity-80 line-clamp-2">
                  {step.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
        {driverName ? (
          <div className="p-4 rounded-xl bg-purple-950/70 border border-purple-800/50 space-y-2">
            <p className="text-purple-300 uppercase tracking-wider font-bold text-[11px]">Condutor Designado</p>
            <div className="flex items-center justify-between">
              <span className="text-base font-extrabold text-white">{driverName}</span>
              {driverPhone && (
                <a
                  href={`tel:${driverPhone}`}
                  className="px-3 py-1 rounded-lg bg-purple-900/80 hover:bg-purple-800 text-[#FFD700] border border-purple-700/60 text-xs font-semibold"
                >
                  Ligar para Condutor
                </a>
              )}
            </div>
            {vehicleModel && (
              <p className="text-purple-200">
                Veículo: <strong className="text-white">{vehicleModel}</strong> • Placa:{' '}
                <span className="font-mono text-[#FFD700] font-bold">{vehiclePlate || 'BRA-2E19'}</span>
              </p>
            )}
          </div>
        ) : (
          <div className="p-4 rounded-xl bg-purple-950/50 border border-purple-800/30 flex items-center space-x-3 text-purple-300">
            <div className="w-3 h-3 rounded-full bg-[#FFD700] animate-ping" />
            <span>Procurando o melhor condutor ou caminhoneiro de retorno...</span>
          </div>
        )}

        <div className="p-4 rounded-xl bg-purple-950/70 border border-purple-800/50 space-y-1.5">
          <p className="text-purple-300 uppercase tracking-wider font-bold text-[11px]">
            Custódia Garantida Mercado Pago
          </p>
          <div className="flex items-center justify-between">
            <span className="text-xl font-black text-[#FFD700]">
              R$ {amount.toFixed(2).replace('.', ',')}
            </span>
            <span
              className={`px-2.5 py-0.5 rounded-full font-bold uppercase text-[10px] border ${
                escrowStatus === 'held'
                  ? 'bg-[#FFD700]/20 text-[#FFD700] border-[#FFD700]/40'
                  : escrowStatus === 'released'
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                  : 'bg-purple-900/50 text-purple-300 border-purple-700/50'
              }`}
            >
              {escrowStatus === 'held' ? 'Retido em Custódia' : escrowStatus === 'released' ? 'Repasse Efetuado' : 'Aguardando'}
            </span>
          </div>
          <p className="text-[11px] text-purple-300/80 leading-relaxed">
            O repasse financeiro fica protegido e só é liberado para liquidação do condutor após a validação do PIN de segurança.
          </p>
        </div>
      </div>

      {!pinSuccess && (
        <form onSubmit={handlePinSubmit} className="p-4 rounded-xl bg-purple-950/90 border border-[#FFD700]/50 space-y-3">
          <div className="flex items-center justify-between">
            <span className="font-bold text-sm text-white">Validação Final de Desembarque / Entrega (PIN)</span>
            <span className="text-xs text-purple-300">Informe o PIN fornecido pelo passageiro</span>
          </div>

          {pinError && (
            <p role="alert" className="text-xs text-rose-300 bg-rose-950/80 p-2 rounded-lg border border-rose-500/60">
              {pinError}
            </p>
          )}

          <div className="flex space-x-2">
            <input
              type="text"
              maxLength={4}
              placeholder="Digite o PIN de 4 dígitos"
              value={inputPin}
              onChange={(e) => setInputPin(e.target.value.replace(/\D/g, ''))}
              className="flex-1 px-4 py-2.5 rounded-xl bg-[#150724] border border-purple-700/60 text-white font-mono font-bold tracking-widest text-center focus:outline-none focus:border-[#FFD700]"
            />
            <button
              type="submit"
              disabled={isVerifyingPin || inputPin.length !== 4}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#FFD700] to-[#F5A623] hover:brightness-110 text-[#0D0417] font-extrabold text-xs uppercase tracking-wider disabled:opacity-50 transition-all"
            >
              {isVerifyingPin ? 'Conferindo...' : 'Liberar Custódia'}
            </button>
          </div>
        </form>
      )}

      {pinSuccess && (
        <div className="p-4 rounded-xl bg-emerald-950/80 border border-emerald-500 text-emerald-200 text-sm font-bold flex items-center space-x-2">
          <span>✓</span>
          <span>PIN validado com sucesso! O trajeto foi concluído e o repasse em custódia foi liberado com êxito.</span>
        </div>
      )}

      {onCancel && status !== 'delivered' && status !== 'cancelled' && (
        <div className="pt-2 flex justify-end">
          <button
            type="button"
            onClick={onCancel}
            className="text-xs text-purple-400 hover:text-rose-400 transition-colors"
          >
            Cancelar chamado de transporte
          </button>
        </div>
      )}
    </div>
  );
};

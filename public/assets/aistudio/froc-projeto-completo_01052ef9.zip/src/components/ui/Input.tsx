import React from 'react';

export type InputMaskType = 'currency' | 'weight' | 'volume' | 'cnh' | 'antt' | 'none';

export interface InputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'size'> {
  label: string;
  helperText?: string;
  errorMessage?: string;
  mask?: InputMaskType;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  suffix?: string;
}

export const Input = React.forwardRef<HTMLInputElement, InputProps>((
  {
    label,
    id,
    helperText,
    errorMessage,
    mask = 'none',
    leftIcon,
    rightIcon,
    suffix,
    className = '',
    disabled,
    required,
    onChange,
    value,
    ...rest
  },
  ref
) => {
  const inputId = id || `input-${label.toLowerCase().replace(/[^a-z0-9]/g, '-')}`;
  const helperId = `${inputId}-helper`;
  const errorId = `${inputId}-error`;

  const formatMask = (raw: string, type: InputMaskType): string => {
    if (type === 'currency') {
      const digits = raw.replace(/\D/g, '');
      if (!digits) return '';
      const numberValue = (parseInt(digits, 10) / 100).toFixed(2);
      return numberValue.replace('.', ',');
    }
    if (type === 'cnh') {
      const digits = raw.replace(/\D/g, '');
      return digits.slice(0, 11);
    }
    if (type === 'antt') {
      return raw.toUpperCase().replace(/[^A-Z0-9-]/g, '').slice(0, 14);
    }
    if (type === 'weight' || type === 'volume') {
      return raw.replace(/[^0-9.,]/g, '');
    }
    return raw;
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (mask !== 'none') {
      const masked = formatMask(e.target.value, mask);
      e.target.value = masked;
    }
    if (onChange) {
      onChange(e);
    }
  };

  return (
    <div className="w-full space-y-1.5 text-left">
      <div className="flex items-center justify-between">
        <label
          htmlFor={inputId}
          className="block text-xs font-bold uppercase tracking-wider text-purple-200"
        >
          {label} {required && <span className="text-[#FFD700]">*</span>}
        </label>
      </div>

      <div className="relative flex items-center">
        {leftIcon && (
          <div className="absolute left-3.5 flex items-center pointer-events-none text-purple-400">
            {leftIcon}
          </div>
        )}

        <input
          ref={ref}
          id={inputId}
          aria-invalid={!!errorMessage}
          aria-describedby={errorMessage ? errorId : helperText ? helperId : undefined}
          disabled={disabled}
          required={required}
          value={value}
          onChange={handleChange}
          className={`w-full rounded-xl bg-[#150724] border text-white placeholder-purple-400/40 text-sm py-3 transition-all duration-200 min-h-[48px] focus:outline-none ${
            leftIcon ? 'pl-11' : 'pl-4'
          } ${suffix || rightIcon ? 'pr-12' : 'pr-4'} ${
            errorMessage
              ? 'border-red-500 focus:border-red-400 focus:ring-2 focus:ring-red-500/20'
              : 'border-[#7928CA]/40 focus:border-[#FFD700] focus:ring-2 focus:ring-[#FFD700]/20 hover:border-[#7928CA]/70'
          } ${disabled ? 'opacity-50 cursor-not-allowed bg-purple-950/20' : ''} ${className}`}
          {...rest}
        />

        {suffix && (
          <span className="absolute right-3.5 text-xs font-bold text-[#FFD700]/80 pointer-events-none select-none">
            {suffix}
          </span>
        )}

        {!suffix && rightIcon && (
          <div className="absolute right-3.5 flex items-center pointer-events-none text-purple-400">
            {rightIcon}
          </div>
        )}
      </div>

      {errorMessage ? (
        <p id={errorId} role="alert" className="text-xs text-red-400 font-medium flex items-center gap-1.5 pt-0.5">
          <svg className="w-3.5 h-3.5 flex-shrink-0" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
            <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
          </svg>
          <span>{errorMessage}</span>
        </p>
      ) : helperText ? (
        <p id={helperId} className="text-[11px] text-purple-300/70 pt-0.5">
          {helperText}
        </p>
      ) : null}
    </div>
  );
});

Input.displayName = 'Input';

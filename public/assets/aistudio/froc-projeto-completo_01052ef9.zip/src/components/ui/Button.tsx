import React from 'react';

export type ButtonVariant = 'cyber-purple' | 'gold-solid' | 'gold-outline' | 'ghost' | 'danger';
export type ButtonSize = 'sm' | 'md' | 'lg';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  isLoading?: boolean;
  loadingText?: string;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  fullWidth?: boolean;
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>((
  {
    children,
    variant = 'gold-solid',
    size = 'md',
    isLoading = false,
    loadingText,
    leftIcon,
    rightIcon,
    fullWidth = false,
    disabled = false,
    className = '',
    type = 'button',
    ...rest
  },
  ref
) => {
  const baseClasses =
    'inline-flex items-center justify-center font-bold tracking-tight rounded-xl transition-all duration-200 select-none touch-target focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-offset-[#1A0B2E] active:scale-[0.98] disabled:opacity-50 disabled:pointer-events-none disabled:active:scale-100';

  const sizeClasses: Record<ButtonSize, string> = {
    sm: 'text-xs px-3.5 py-2 min-h-[40px]',
    md: 'text-sm px-5 py-2.5 min-h-[48px]',
    lg: 'text-base px-6 py-3.5 min-h-[52px]',
  };

  const variantClasses: Record<ButtonVariant, string> = {
    'gold-solid':
      'bg-gradient-to-r from-[#FFD700] via-[#F5A623] to-[#FFD700] text-[#0D0417] hover:brightness-110 shadow-[0_0_20px_rgba(255,215,0,0.35)] focus-visible:ring-[#FFD700]',
    'cyber-purple':
      'bg-[#7928CA] text-white hover:bg-[#9E00FF] shadow-[0_0_20px_rgba(158,0,255,0.35)] focus-visible:ring-[#9E00FF]',
    'gold-outline':
      'bg-transparent border border-[#FFD700] text-[#FFD700] hover:bg-[#FFD700]/10 focus-visible:ring-[#FFD700]',
    ghost:
      'bg-transparent text-purple-200 hover:text-white hover:bg-white/5 focus-visible:ring-purple-400',
    danger:
      'bg-gradient-to-r from-red-600 to-rose-700 text-white hover:from-red-500 hover:to-rose-600 shadow-[0_0_15px_rgba(239,68,68,0.3)] focus-visible:ring-red-400',
  };

  const widthClass = fullWidth ? 'w-full' : '';

  return (
    <button
      ref={ref}
      type={type}
      disabled={disabled || isLoading}
      className={`${baseClasses} ${sizeClasses[size]} ${variantClasses[variant]} ${widthClass} ${className}`}
      {...rest}
    >
      {isLoading ? (
        <span className="flex items-center gap-2">
          <svg
            className="animate-spin h-4 w-4 text-current"
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            aria-hidden="true"
          >
            <circle
              className="opacity-25"
              cx="12"
              cy="12"
              r="10"
              stroke="currentColor"
              strokeWidth="4"
            />
            <path
              className="opacity-75"
              fill="currentColor"
              d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"
            />
          </svg>
          <span>{loadingText || children}</span>
        </span>
      ) : (
        <span className="flex items-center gap-2">
          {leftIcon && <span className="flex-shrink-0">{leftIcon}</span>}
          <span>{children}</span>
          {rightIcon && <span className="flex-shrink-0">{rightIcon}</span>}
        </span>
      )}
    </button>
  );
});

Button.displayName = 'Button';

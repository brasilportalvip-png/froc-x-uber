import React, { useEffect, useState } from 'react';

export interface ToastNotification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  durationMs?: number;
}

interface ToastContextType {
  showToast: (title: string, message: string, type?: ToastNotification['type'], durationMs?: number) => void;
}

const ToastContext = React.createContext<ToastContextType | undefined>(undefined);

export const ToastProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [toasts, setToasts] = useState<ToastNotification[]>([]);

  const showToast = (
    title: string,
    message: string,
    type: ToastNotification['type'] = 'info',
    durationMs: number = 4500
  ) => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`;
    setToasts((prev) => [...prev, { id, title, message, type, durationMs }]);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  return (
    <ToastContext.Provider value={{ showToast }}>
      {children}
      <div
        aria-live="assertive"
        className="fixed bottom-5 right-5 z-50 flex flex-col gap-2.5 max-w-sm w-full pointer-events-none p-2"
      >
        {toasts.map((toast) => (
          <ToastItem key={toast.id} toast={toast} onDismiss={() => removeToast(toast.id)} />
        ))}
      </div>
    </ToastContext.Provider>
  );
};

export const useToast = (): ToastContextType => {
  const context = React.useContext(ToastContext);
  if (!context) {
    throw new Error('useToast deve ser usado dentro de um ToastProvider');
  }
  return context;
};

const ToastItem: React.FC<{ toast: ToastNotification; onDismiss: () => void }> = ({
  toast,
  onDismiss,
}) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onDismiss();
    }, toast.durationMs || 4500);

    return () => clearTimeout(timer);
  }, [toast, onDismiss]);

  const typeStyles = {
    info: 'border-blue-500/60 bg-purple-950/95 text-blue-200',
    success: 'border-emerald-500/60 bg-purple-950/95 text-emerald-200',
    warning: 'border-amber-500/60 bg-purple-950/95 text-amber-200',
    error: 'border-rose-500/60 bg-purple-950/95 text-rose-200',
  };

  const icons = {
    info: 'ℹ️',
    success: '✓',
    warning: '⚠️',
    error: '✕',
  };

  return (
    <div
      role="status"
      className={`pointer-events-auto flex items-start justify-between p-4 rounded-xl border shadow-2xl backdrop-blur-md transition-all animate-slide-up ${typeStyles[toast.type]}`}
    >
      <div className="flex items-start gap-3">
        <span className="text-base font-bold flex-shrink-0 mt-0.5">{icons[toast.type]}</span>
        <div>
          <h4 className="font-bold text-sm text-white">{toast.title}</h4>
          <p className="text-xs text-purple-200/90 mt-0.5 leading-relaxed">{toast.message}</p>
        </div>
      </div>
      <button
        type="button"
        onClick={onDismiss}
        className="text-purple-300 hover:text-white p-1 ml-2 text-xs focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-amber-400 rounded"
        aria-label="Fechar notificação"
      >
        ✕
      </button>
    </div>
  );
};

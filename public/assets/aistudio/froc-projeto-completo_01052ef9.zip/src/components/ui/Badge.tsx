import React from 'react';

export type BadgeVariant =
  | 'purple'
  | 'gold'
  | 'emerald'
  | 'amber'
  | 'rose'
  | 'blue'
  | 'return-freight';

export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  variant?: BadgeVariant;
  icon?: React.ReactNode;
  pulse?: boolean;
}

export const Badge: React.FC<BadgeProps> = ({
  children,
  variant = 'purple',
  icon,
  pulse = false,
  className = '',
  ...rest
}) => {
  const variantStyles: Record<BadgeVariant, string> = {
    purple: 'bg-purple-900/60 text-purple-200 border-purple-500/40',
    gold: 'bg-[#FFD700]/15 text-[#FFD700] border-[#FFD700]/40',
    emerald: 'bg-emerald-950/70 text-emerald-300 border-emerald-500/40',
    amber: 'bg-amber-950/70 text-amber-300 border-amber-500/40',
    rose: 'bg-rose-950/70 text-rose-300 border-rose-500/40',
    blue: 'bg-sky-950/70 text-sky-300 border-sky-500/40',
    'return-freight':
      'bg-gradient-to-r from-[#FFD700]/20 to-[#7928CA]/30 text-[#FFD700] border-[#FFD700]/60 font-extrabold shadow-[0_0_10px_rgba(255,215,0,0.2)]',
  };

  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider border select-none transition-colors ${variantStyles[variant]} ${className}`}
      {...rest}
    >
      {pulse && (
        <span className="relative flex h-2 w-2">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-current opacity-75" />
          <span className="relative inline-flex rounded-full h-2 w-2 bg-current" />
        </span>
      )}
      {icon && <span className="flex-shrink-0">{icon}</span>}
      <span>{children}</span>
    </span>
  );
};

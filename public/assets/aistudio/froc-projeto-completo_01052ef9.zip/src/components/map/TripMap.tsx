import React, { useMemo } from 'react';

export interface MapMarker {
  id: string;
  lat: number;
  lng: number;
  type: 'origin' | 'destination' | 'driver' | 'truck';
  label?: string;
}

export interface TripMapProps {
  originAddress?: string;
  destinationAddress?: string;
  distanceKm?: number;
  durationMinutes?: number;
  driverName?: string;
  driverVehicle?: string;
  isInteractive?: boolean;
  className?: string;
}

export const TripMap: React.FC<TripMapProps> = ({
  originAddress = 'Origem',
  destinationAddress = 'Destino',
  distanceKm = 14.8,
  durationMinutes = 26,
  driverName,
  driverVehicle,
  className = '',
}) => {
  const routeCoordinates = useMemo(() => {
    return [
      { x: 12, y: 78 },
      { x: 26, y: 64 },
      { x: 42, y: 58 },
      { x: 55, y: 40 },
      { x: 70, y: 35 },
      { x: 88, y: 22 },
    ];
  }, []);

  const pathD = useMemo(() => {
    return routeCoordinates.reduce((acc, point, index) => {
      return index === 0 ? `M ${point.x} ${point.y}` : `${acc} L ${point.x} ${point.y}`;
    }, '');
  }, [routeCoordinates]);

  const driverPosition = useMemo(() => {
    return { x: 48, y: 48 };
  }, []);

  return (
    <div
      data-testid="trip-map-container"
      className={`relative w-full h-80 rounded-2xl overflow-hidden bg-[#0e0419] border border-purple-800/60 shadow-xl ${className}`}
      aria-label="Mapa esquemático de rota com telemetria"
    >
      <svg
        viewBox="0 0 100 100"
        preserveAspectRatio="none"
        className="w-full h-full opacity-30 pointer-events-none"
      >
        <defs>
          <pattern id="grid-map-cyber" width="10" height="10" patternUnits="userSpaceOnUse">
            <path d="M 10 0 L 0 0 0 10" fill="none" stroke="#7928CA" strokeWidth="0.2" />
          </pattern>
        </defs>
        <rect width="100" height="100" fill="url(#grid-map-cyber)" />
      </svg>

      <svg
        viewBox="0 0 100 100"
        preserveAspectRatio="none"
        className="absolute inset-0 w-full h-full pointer-events-none"
      >
        <path
          d={pathD}
          fill="none"
          stroke="rgba(121, 40, 202, 0.4)"
          strokeWidth="3"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d={pathD}
          fill="none"
          stroke="#FFD700"
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeDasharray="3, 2"
          className="animate-pulse"
        />

        <circle cx={routeCoordinates[0].x} cy={routeCoordinates[0].y} r="3" fill="#10B981" />
        <circle cx={routeCoordinates[0].x} cy={routeCoordinates[0].y} r="5" fill="none" stroke="#10B981" strokeWidth="0.8" opacity="0.7" />

        <circle cx={routeCoordinates[routeCoordinates.length - 1].x} cy={routeCoordinates[routeCoordinates.length - 1].y} r="3.5" fill="#EF4444" />
        <circle cx={routeCoordinates[routeCoordinates.length - 1].x} cy={routeCoordinates[routeCoordinates.length - 1].y} r="6" fill="none" stroke="#EF4444" strokeWidth="0.8" opacity="0.7" />

        <g transform={`translate(${driverPosition.x - 2.5}, ${driverPosition.y - 2.5})`}>
          <circle cx="2.5" cy="2.5" r="4" fill="#FFD700" opacity="0.4" className="animate-ping" />
          <circle cx="2.5" cy="2.5" r="2.5" fill="#FFD700" stroke="#1A0B2E" strokeWidth="0.6" />
        </g>
      </svg>

      <div className="absolute top-3 left-3 right-3 flex items-center justify-between pointer-events-none">
        <div className="px-3 py-1.5 rounded-xl bg-purple-950/85 backdrop-blur-md border border-purple-700/60 text-xs shadow-lg">
          <span className="text-purple-300 font-medium">Distância Estimada: </span>
          <span className="font-bold text-amber-400">{distanceKm} km</span>
          <span className="text-purple-400 mx-1">•</span>
          <span className="font-bold text-white">~{durationMinutes} min</span>
        </div>

        <div className="px-2.5 py-1 rounded-lg bg-emerald-950/80 border border-emerald-500/50 text-[11px] text-emerald-300 font-semibold flex items-center space-x-1.5 shadow-md">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>GPS Ativo</span>
        </div>
      </div>

      <div className="absolute bottom-3 left-3 right-3 p-3 rounded-xl bg-purple-950/90 backdrop-blur-md border border-purple-700/60 shadow-xl flex items-center justify-between">
        <div className="space-y-0.5 text-xs truncate max-w-[70%]">
          <div className="flex items-center space-x-1.5 truncate">
            <span className="w-2 h-2 rounded-full bg-emerald-400 flex-shrink-0" />
            <span className="text-purple-200 truncate">{originAddress}</span>
          </div>
          <div className="flex items-center space-x-1.5 truncate">
            <span className="w-2 h-2 rounded-full bg-rose-500 flex-shrink-0" />
            <span className="text-white font-semibold truncate">{destinationAddress}</span>
          </div>
        </div>

        {driverName && (
          <div className="text-right pl-2 border-l border-purple-800/60 flex-shrink-0">
            <span className="text-[10px] text-purple-300 block uppercase tracking-wider">Condutor</span>
            <span className="text-xs font-bold text-amber-400 block truncate max-w-[120px]">{driverName}</span>
            {driverVehicle && (
              <span className="text-[10px] text-purple-200 block truncate max-w-[120px]">{driverVehicle}</span>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export type ServiceMode = 'direct' | 'negotiated' | 'carpool' | 'freight';

export type TripStatus =
  | 'draft'
  | 'searching'
  | 'bidding'
  | 'accepted'
  | 'in_transit'
  | 'delivered'
  | 'cancelled';

export type PaymentStatus =
  | 'pending'
  | 'held_escrow'
  | 'released'
  | 'refunded'
  | 'failed';

export type VehicleCategory =
  | 'popular'
  | 'comfort'
  | 'suv'
  | 'van'
  | 'truck_light'
  | 'truck_medium'
  | 'truck_heavy'
  | 'flatbed';

export interface CargoSpecs {
  weightKg: number;
  volumeM3: number;
  isReturnEmpty: boolean;
  helpersNeeded: number;
  cargoType: 'mudanca' | 'paletizada' | 'equipamentos' | 'construcao' | 'geral';
  description?: string;
}

export interface CarpoolSpecs {
  seatsAvailable: number;
  luggageSize: 'small' | 'medium' | 'large';
  scheduledDeparture: string;
  passengerPricePerSeat: number;
}

export interface LocationPoint {
  address: string;
  city: string;
  state: string;
  lat?: number;
  lng?: number;
}

export interface Bid {
  id: string;
  tripId: string;
  driverId: string;
  driverName: string;
  driverRating: number;
  driverPhone: string;
  driverVehicle: {
    model: string;
    plate: string;
    color: string;
    category: VehicleCategory;
    capacityM3?: number;
  };
  amount: number;
  etaMinutes: number;
  message?: string;
  status: 'pending' | 'accepted' | 'rejected' | 'withdrawn';
  createdAt: string;
}

export interface Trip {
  id: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  mode: ServiceMode;
  origin: LocationPoint;
  destination: LocationPoint;
  distanceKm: number;
  durationMinutes: number;
  initialOfferPrice?: number;
  finalAgreedPrice: number;
  platformFee: number;
  driverPayout: number;
  currency: 'BRL';
  status: TripStatus;
  cargoSpecs?: CargoSpecs;
  carpoolSpecs?: CarpoolSpecs;
  driverId?: string;
  driverName?: string;
  driverPhone?: string;
  driverVehicleModel?: string;
  driverVehiclePlate?: string;
  driverRating?: number;
  pinCode: string;
  paymentStatus: PaymentStatus;
  paymentId?: string;
  bidsCount?: number;
  createdAt: string;
  updatedAt: string;
}

export type UserRole = 'passenger' | 'driver' | 'trucker' | 'admin';

export interface ComplianceDocument {
  id: string;
  userId: string;
  type: 'cnh' | 'crlv' | 'antt' | 'comprovante_residencia';
  documentNumber: string;
  status: 'pending' | 'approved' | 'rejected';
  rejectionReason?: string;
  submittedAt: string;
  reviewedAt?: string;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: UserRole;
  verified: boolean;
  anttRegister?: string;
  cnhNumber?: string;
  vehicleType?: VehicleCategory;
  vehicleModel?: string;
  vehiclePlate?: string;
  truckVolumeM3?: number;
  truckMaxWeightKg?: number;
  rating: number;
  totalTrips: number;
  walletBalance: number;
  escrowBalance: number;
  documents: ComplianceDocument[];
  createdAt: string;
}

export interface EscrowOrder {
  id: string;
  tripId: string;
  customerId: string;
  driverId?: string;
  amount: number;
  platformFee: number;
  driverPayout: number;
  currency: 'BRL';
  status: PaymentStatus;
  mercadoPagoPaymentId?: string;
  pinVerified: boolean;
  createdAt: string;
  releasedAt?: string;
}

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
    details?: unknown;
  };
}

export interface ApiProblemDetails {
  type?: string;
  title: string;
  status: number;
  detail?: string;
  instance?: string;
  errors?: Record<string, string[]>;
}

export class ApiError extends Error {
  public status: number;
  public details: ApiProblemDetails;

  constructor(status: number, details: ApiProblemDetails) {
    super(details.detail || details.title || `API error with status ${status}`);
    this.name = 'ApiError';
    this.status = status;
    this.details = details;
  }
}

interface RequestOptions extends RequestInit {
  params?: Record<string, string | number | boolean | undefined>;
  idempotencyKey?: string;
  authToken?: string | null;
}

function buildQueryString(params?: Record<string, string | number | boolean | undefined>): string {
  if (!params) return '';
  const entries = Object.entries(params).filter(
    ([, val]) => val !== undefined && val !== null
  );
  if (entries.length === 0) return '';
  const searchParams = new URLSearchParams();
  for (const [key, val] of entries) {
    searchParams.append(key, String(val));
  }
  return `?${searchParams.toString()}`;
}

export async function apiRequest<T>(
  endpoint: string,
  options: RequestOptions = {}
): Promise<T> {
  const { params, idempotencyKey, authToken, headers: customHeaders, ...fetchInit } = options;
  const queryString = buildQueryString(params);
  const url = `${endpoint.startsWith('/') ? endpoint : `/${endpoint}`}${queryString}`;

  const headers = new Headers(customHeaders || {});
  if (!headers.has('Content-Type') && !(fetchInit.body instanceof FormData)) {
    headers.set('Content-Type', 'application/json');
  }
  headers.set('Accept', 'application/json');

  if (idempotencyKey) {
    headers.set('Idempotency-Key', idempotencyKey);
  }

  if (authToken) {
    headers.set('Authorization', `Bearer ${authToken}`);
  } else {
    const sessionToken = typeof window !== 'undefined' ? localStorage.getItem('froc_auth_token') : null;
    if (sessionToken) {
      headers.set('Authorization', `Bearer ${sessionToken}`);
    }
  }

  const response = await fetch(url, {
    ...fetchInit,
    headers,
  });

  if (!response.ok) {
    let problem: ApiProblemDetails;
    try {
      const errorJson = await response.json();
      problem = {
        title: errorJson.title || errorJson.message || 'Erro na requisição',
        status: response.status,
        detail: errorJson.detail || errorJson.message || 'Falha ao processar solicitação',
        errors: errorJson.errors,
        instance: errorJson.instance || url,
      };
    } catch {
      problem = {
        title: 'Erro de Comunicação',
        status: response.status,
        detail: response.statusText || 'Não foi possível ler os detalhes da resposta do servidor.',
        instance: url,
      };
    }
    throw new ApiError(response.status, problem);
  }

  if (response.status === 204) {
    return {} as T;
  }

  return (await response.json()) as T;
}

import React from 'react';

interface NotFoundPageProps {
  onNavigate?: (path: string) => void;
}

export const NotFoundPage: React.FC<NotFoundPageProps> = ({ onNavigate }) => {
  const handleGoHome = () => {
    if (onNavigate) {
      onNavigate('/');
    } else {
      window.location.href = '/';
    }
  };

  const handleGoBooking = () => {
    if (onNavigate) {
      onNavigate('/booking');
    } else {
      window.location.href = '/booking';
    }
  };

  return (
    <main className="min-h-[70vh] flex items-center justify-center px-4 py-16">
      <div className="max-w-md w-full text-center space-y-6 p-8 rounded-2xl bg-purple-950/40 border border-purple-800/40 shadow-2xl backdrop-blur-md">
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-purple-900/60 border border-amber-400/40 text-amber-400 shadow-[0_0_25px_rgba(255,215,0,0.2)]">
          <span className="text-3xl font-black font-mono">404</span>
        </div>

        <div className="space-y-2">
          <h1 className="text-2xl font-extrabold text-white tracking-tight">
            Rota Não Encontrada
          </h1>
          <p className="text-sm text-purple-200/80 leading-relaxed">
            A coordenada ou página que você tentou acessar não existe, foi remanejada ou está temporariamente indisponível.
          </p>
        </div>

        <div className="pt-4 flex flex-col sm:flex-row gap-3 justify-center">
          <button
            type="button"
            onClick={handleGoHome}
            className="w-full sm:w-auto px-5 py-3 rounded-xl bg-purple-900/80 hover:bg-purple-800 text-white font-semibold text-xs tracking-wider uppercase border border-purple-700/60 transition-all active:scale-95"
          >
            Página Inicial
          </button>
          <button
            type="button"
            onClick={handleGoBooking}
            className="w-full sm:w-auto px-5 py-3 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-purple-950 font-bold text-xs tracking-wider uppercase shadow-md hover:brightness-110 transition-all active:scale-95"
          >
            Solicitar Corrida
          </button>
        </div>
      </div>
    </main>
  );
};

export default NotFoundPage;

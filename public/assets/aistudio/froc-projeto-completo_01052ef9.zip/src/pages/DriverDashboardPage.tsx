import React, { useState } from 'react';
import { Navbar } from '../components/layout/Navbar';
import { Footer } from '../components/layout/Footer';
import { useAuth } from '../context/AuthContext';
import { DriverVerificationForm } from '../components/driver/DriverVerificationForm';

interface RideCall {
  id: string;
  mode: 'direct' | 'negotiated' | 'freight';
  passengerName: string;
  origin: string;
  destination: string;
  distanceKm: number;
  offeredAmount: number;
  specs?: string;
  countdownSeconds: number;
}

const ACTIVE_CALLS: RideCall[] = [
  {
    id: 'call-101',
    mode: 'direct',
    passengerName: 'Camila Rocha',
    origin: 'Av. Brigadeiro Faria Lima, 2200 - Pinheiros',
    destination: 'Vila Mariana - Metrô Ana Rosa',
    distanceKm: 7.4,
    offeredAmount: 26.80,
    countdownSeconds: 25,
  },
  {
    id: 'call-102',
    mode: 'negotiated',
    passengerName: 'Bruno Alcantara',
    origin: 'Rua Bela Cintra, 1200 - Consolação',
    destination: 'Aeroporto de Guarulhos - Terminal 3',
    distanceKm: 29.5,
    offeredAmount: 78.00,
    countdownSeconds: 42,
  },
  {
    id: 'call-103',
    mode: 'freight',
    passengerName: 'Logística SP & Cargas',
    origin: 'Curitiba, PR (Galpão CIC)',
    destination: 'São Paulo, SP (Ceagesp)',
    distanceKm: 408.0,
    offeredAmount: 1150.00,
    specs: 'Carga de Retorno: Baú Seco 22m³ • 1.800 kg • 2 Ajudantes',
    countdownSeconds: 58,
  },
];

interface DriverDashboardPageProps {
  onNavigate?: (path: string) => void;
}

export const DriverDashboardPage: React.FC<DriverDashboardPageProps> = ({ onNavigate }) => {
  const { user, switchRole } = useAuth();
  const [isOnline, setIsOnline] = useState(true);
  const [activeTab, setActiveTab] = useState<'compliance' | 'calls' | 'wallet'>('compliance');
  const [calls, setCalls] = useState<RideCall[]>(ACTIVE_CALLS);
  const [acceptedCallId, setAcceptedCallId] = useState<string | null>(null);
  const [counterBidAmount, setCounterBidAmount] = useState<Record<string, string>>({});
  const [notice, setNotice] = useState<string | null>(null);

  const handleAccept = (callId: string) => {
    setAcceptedCallId(callId);
    setCalls((prev) => prev.filter((c) => c.id !== callId));
  };

  const handleCounterBid = (callId: string) => {
    const val = counterBidAmount[callId];
    if (!val) return;
    setNotice(`Contraproposta de R$ ${val} enviada ao passageiro/embarcador com sucesso!`);
    setTimeout(() => setNotice(null), 4000);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#0D0417] text-white selection:bg-[#FFD700] selection:text-black">
      <Navbar currentPath="/driver" onNavigate={onNavigate} />

      <main className="flex-grow container mx-auto px-4 py-8 max-w-7xl">
        {/* Cabeçalho do Condutor */}
        <div className="p-6 rounded-3xl bg-gradient-to-r from-[#1A0B2E] via-[#260E43] to-[#1A0B2E] border border-purple-800/60 shadow-2xl mb-8 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center space-x-4">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#7928CA] to-[#FFD700] p-[2px]">
              <div className="w-full h-full bg-[#1A0B2E] rounded-[14px] flex items-center justify-center text-2xl font-black text-[#FFD700]">
                {user?.name ? user.name.charAt(0) : 'M'}
              </div>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-2xl font-extrabold text-white">{user?.name || 'Motorista / Caminhoneiro'}</h1>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-[#FFD700]/20 text-[#FFD700] border border-[#FFD700]/40">
                  ★ 4.96
                </span>
              </div>
              <p className="text-xs text-purple-300 mt-1">
                Modo Atual: <span className="text-white font-semibold">{user?.role === 'trucker' ? 'Caminhoneiro de Retorno' : 'Motorista Urbano / Negociado'}</span> • Comissão reduzida de 8% a 12%
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            {/* Switch Online/Offline */}
            <div className="flex items-center space-x-3 bg-[#0D0417] px-4 py-2.5 rounded-2xl border border-purple-800">
              <span className={`w-3 h-3 rounded-full ${isOnline ? 'bg-emerald-400 animate-pulse' : 'bg-rose-500'}`} />
              <span className="text-xs font-bold">{isOnline ? 'Pronto para Corridas' : 'Desconectado'}</span>
              <button
                type="button"
                onClick={() => setIsOnline(!isOnline)}
                className={`px-3 py-1 rounded-xl text-xs font-extrabold transition-all ${
                  isOnline ? 'bg-rose-600 hover:bg-rose-700 text-white' : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                }`}
              >
                {isOnline ? 'Pausar' : 'Ficar Online'}
              </button>
            </div>

            <button
              type="button"
              onClick={() => switchRole(user?.role === 'trucker' ? 'driver' : 'trucker')}
              className="px-3.5 py-2.5 rounded-xl bg-purple-900/60 hover:bg-purple-800 border border-purple-700 text-xs font-semibold text-purple-200 transition-colors"
            >
              Alternar p/ {user?.role === 'trucker' ? 'Urbano' : 'Caminhão'}
            </button>
          </div>
        </div>

        {notice && (
          <div className="mb-6 p-4 rounded-2xl bg-amber-500/20 border border-amber-400 text-amber-300 text-sm font-semibold flex items-center justify-between">
            <span>{notice}</span>
            <button type="button" onClick={() => setNotice(null)} className="text-amber-300 hover:text-white">✕</button>
          </div>
        )}

        {/* Abas de Navegação Interna */}
        <div className="flex border-b border-[#2E0854] mb-6 space-x-4">
          <button
            type="button"
            onClick={() => setActiveTab('compliance')}
            className={`pb-3 text-sm font-bold border-b-2 transition-all ${
              activeTab === 'compliance'
                ? 'border-[#FFD700] text-[#FFD700]'
                : 'border-transparent text-gray-400 hover:text-white'
            }`}
          >
            Documentação & Validação ANTT / CNH
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('calls')}
            className={`pb-3 text-sm font-bold border-b-2 transition-all flex items-center space-x-2 ${
              activeTab === 'calls'
                ? 'border-[#FFD700] text-[#FFD700]'
                : 'border-transparent text-gray-400 hover:text-white'
            }`}
          >
            <span>Chamadas em Tempo Real</span>
            <span className="px-2 py-0.2 rounded-full bg-[#FFD700] text-black text-[10px] font-extrabold">
              {calls.length}
            </span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('wallet')}
            className={`pb-3 text-sm font-bold border-b-2 transition-all ${
              activeTab === 'wallet'
                ? 'border-[#FFD700] text-[#FFD700]'
                : 'border-transparent text-gray-400 hover:text-white'
            }`}
          >
            Carteira & Repasses em Custódia
          </button>
        </div>

        {/* Conteúdo da Aba Compliance */}
        {activeTab === 'compliance' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <DriverVerificationForm />
            </div>

            <div className="space-y-6">
              <div className="p-6 rounded-2xl bg-[#1A0B2E] border border-purple-800/60 shadow-xl">
                <h3 className="text-base font-bold text-white mb-3 flex items-center space-x-2">
                  <span className="text-[#FFD700]">🛡️</span>
                  <span>Regras de Verificação</span>
                </h3>
                <ul className="space-y-3 text-xs text-gray-300 leading-relaxed">
                  <li>
                    <strong className="text-white">Motoristas Urbanos (Uber/99/inDrive):</strong> CNH com observação EAR (Exerce Atividade Remunerada) e CRLV atualizado em nome próprio ou contrato de locação.
                  </li>
                  <li>
                    <strong className="text-white">Caminhoneiros (Frete de Retorno):</strong> Registro Nacional de Transportadores Rodoviários de Cargas (RNTRC / ANTT) ativo para liberação de cargas com seguro RCTR-C.
                  </li>
                  <li>
                    <strong className="text-white">Liberação em Custódia:</strong> Após a verificação dos documentos pelo painel de compliance, seus repasses bancários (PIX) ocorrem automaticamente ao confirmar o PIN de cada transporte.
                  </li>
                </ul>
              </div>

              <div className="p-6 rounded-2xl bg-gradient-to-br from-purple-950 to-[#120720] border border-[#FFD700]/30 shadow-lg">
                <span className="text-[10px] font-extrabold uppercase tracking-wider text-[#FFD700] block mb-1">
                  Vantagem Exclusiva Caminhoneiro
                </span>
                <h4 className="text-sm font-bold text-white mb-2">Nunca mais volte vazio da viagem!</h4>
                <p className="text-xs text-gray-400 leading-relaxed">
                  Ao descarregar em polos logísticos, ligue seu radar de Frete de Retorno. O Froc X Uber localiza cargas compatíveis com o volume e capacidade do seu baú para a viagem de volta.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Conteúdo da Aba Chamadas em Tempo Real */}
        {activeTab === 'calls' && (
          <div className="space-y-6">
            {acceptedCallId && (
              <div className="p-5 rounded-2xl bg-emerald-950/80 border border-emerald-500 text-white flex items-center justify-between shadow-xl">
                <div>
                  <span className="font-bold text-emerald-300 text-sm block">✓ Corrida/Frete Aceito com Sucesso!</span>
                  <span className="text-xs text-gray-300">Dirija-se ao ponto de embarque. O passageiro/embarcador já visualiza seu deslocamento no mapa.</span>
                </div>
                <button
                  type="button"
                  onClick={() => setAcceptedCallId(null)}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 rounded-xl text-xs font-bold text-white"
                >
                  Concluir e Retornar ao Radar
                </button>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {calls.map((call) => (
                <div key={call.id} className="p-5 rounded-2xl bg-[#1A0B2E] border border-purple-800 shadow-xl flex flex-col justify-between space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-purple-900/60">
                    <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                      call.mode === 'freight' ? 'bg-[#FFD700]/20 text-[#FFD700] border border-[#FFD700]/40' : 'bg-purple-900 text-purple-200'
                    }`}>
                      {call.mode === 'freight' ? 'Caminhão Retorno' : call.mode === 'negotiated' ? 'Leilão Negociado' : 'Corrida Direta'}
                    </span>
                    <span className="text-xs text-amber-300 font-mono font-bold animate-pulse">
                      ⏱ {call.countdownSeconds}s restantes
                    </span>
                  </div>

                  <div>
                    <div className="text-sm font-bold text-white mb-1">{call.passengerName}</div>
                    <div className="text-xs text-gray-400 space-y-1 mb-3">
                      <div className="flex items-center space-x-1.5">
                        <span className="text-emerald-400">●</span>
                        <span className="truncate">{call.origin}</span>
                      </div>
                      <div className="flex items-center space-x-1.5">
                        <span className="text-amber-400">●</span>
                        <span className="truncate">{call.destination}</span>
                      </div>
                    </div>
                    {call.specs && (
                      <div className="p-2.5 rounded-lg bg-[#0D0417] text-[11px] text-[#FFD700]/90 font-medium border border-purple-900/40 mb-2">
                        {call.specs}
                      </div>
                    )}
                    <div className="text-xl font-extrabold text-[#FFD700]">
                      R$ {call.offeredAmount.toFixed(2).replace('.', ',')}
                      <span className="text-xs font-normal text-gray-400 ml-2">({call.distanceKm} km)</span>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-purple-900/40 space-y-2">
                    <button
                      type="button"
                      onClick={() => handleAccept(call.id)}
                      className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-600 hover:brightness-110 text-white font-bold text-xs uppercase tracking-wider shadow-md"
                    >
                      Aceitar Oferta (R$ {call.offeredAmount.toFixed(2).replace('.', ',')})
                    </button>

                    {call.mode === 'negotiated' && (
                      <div className="flex space-x-2 pt-1">
                        <input
                          type="text"
                          placeholder="Sua contraproposta R$"
                          value={counterBidAmount[call.id] || ''}
                          onChange={(e) => setCounterBidAmount({ ...counterBidAmount, [call.id]: e.target.value })}
                          className="w-1/2 px-3 py-1.5 rounded-lg bg-[#0D0417] border border-purple-700 text-xs text-white"
                        />
                        <button
                          type="button"
                          onClick={() => handleCounterBid(call.id)}
                          className="w-1/2 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-extrabold text-xs"
                        >
                          Fazer Proposta
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Conteúdo da Aba Carteira */}
        {activeTab === 'wallet' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 rounded-2xl bg-[#1A0B2E] border border-purple-800 shadow-xl">
              <span className="text-xs text-gray-400 uppercase tracking-wider font-semibold block">Saldo Disponível para Saque</span>
              <span className="text-3xl font-extrabold text-[#FFD700] mt-2 block">R$ 1.840,50</span>
              <p className="text-xs text-gray-400 mt-2">Chave PIX vinculada: motorista@froc.app</p>
              <button
                type="button"
                onClick={() => {
                  setNotice('Transferência PIX solicitada com sucesso via Mercado Pago!');
                  setTimeout(() => setNotice(null), 4000);
                }}
                className="mt-4 w-full py-2.5 rounded-xl bg-gradient-to-r from-[#FFD700] to-[#F5A623] text-black font-bold text-xs uppercase tracking-wider shadow-md"
              >
                Solicitar Transferência Imediata (PIX)
              </button>
            </div>

            <div className="p-6 rounded-2xl bg-[#1A0B2E] border border-purple-800 shadow-xl">
              <span className="text-xs text-gray-400 uppercase tracking-wider font-semibold block">Valores em Custódia (Escrow)</span>
              <span className="text-3xl font-extrabold text-purple-300 mt-2 block">R$ 650,00</span>
              <p className="text-xs text-gray-400 mt-2">1 corrida urbana e 1 frete de carga aguardando conferência do PIN oficial.</p>
            </div>

            <div className="p-6 rounded-2xl bg-[#1A0B2E] border border-purple-800 shadow-xl">
              <span className="text-xs text-gray-400 uppercase tracking-wider font-semibold block">Ganhos desta Semana</span>
              <span className="text-3xl font-extrabold text-emerald-400 mt-2 block">R$ 3.420,00</span>
              <p className="text-xs text-gray-400 mt-2">24 transportes concluídos • Taxa média de comissão: 9.8%</p>
            </div>
          </div>
        )}
      </main>

      <Footer onNavigate={onNavigate} />
    </div>
  );
};

import React from 'react';
import { useTrip, ServiceMode } from '../context/TripContext';
import { useAuth } from '../context/AuthContext';

interface HomePageProps {
  onNavigate: (path: string) => void;
}

export const HomePage: React.FC<HomePageProps> = ({ onNavigate }) => {
  const { setCurrentMode } = useTrip();
  const { user } = useAuth();

  const handleSelectModeAndStart = (mode: ServiceMode, targetRoute: string) => {
    setCurrentMode(mode);
    onNavigate(targetRoute);
  };

  return (
    <main className="min-h-screen bg-gradient-to-b from-[#0D0417] via-[#1A0B2E] to-[#0D0417] text-white">
      {/* Hero Section com CTA Instantâneo */}
      <section className="relative overflow-hidden pt-12 pb-20 border-b border-purple-900/40">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_20%,rgba(121,40,202,0.25),transparent_70%)] pointer-events-none" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/10 border border-amber-400/30 text-amber-300 text-xs font-bold uppercase tracking-wider mb-5">
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
              Superaplicativo Unificado 4 em 1
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight leading-tight mb-6">
              Tudo o que se move em uma única tela:
              <span className="block text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-amber-400 to-amber-500 mt-2">
                Uber, inDrive, BlaBlaCar e Frete de Retorno.
              </span>
            </h1>
            <p className="text-base sm:text-lg text-purple-200/90 leading-relaxed max-w-2xl mx-auto">
              Esqueça abrir 4 aplicativos diferentes. Solicite corrida expressa urbana, negocie sua tarifa em leilão aberto, reserve assento em caronas interurbanas ou aproveite até 40% de desconto em caminhões retornando vazios com segurança de custódia.
            </p>
          </div>

          {/* Grid com os 4 Pilares Centrais */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Pilar 1: Urbana Direta */}
            <div className="group relative p-6 rounded-2xl bg-[#200C38]/80 border border-purple-700/50 hover:border-amber-400/80 shadow-xl transition-all duration-300 hover:-translate-y-1 flex flex-col justify-between">
              <div>
                <div className="w-12 h-12 rounded-xl bg-purple-900/80 border border-purple-600/60 flex items-center justify-center text-2xl text-amber-300 mb-4">
                  ⚡
                </div>
                <div className="flex items-center justify-between mb-2">
                  <h2 className="text-lg font-bold text-white">Urbana Direta</h2>
                  <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-purple-900/60 text-purple-200 border border-purple-700/50">
                    Estilo Uber / 99
                  </span>
                </div>
                <p className="text-xs text-purple-200/80 leading-relaxed mb-6">
                  Motorista mais próximo em minutos com tarifa regulada, trajeto rastreado e taxa transparente de apenas 12% para o condutor.
                </p>
              </div>
              <button
                type="button"
                onClick={() => handleSelectModeAndStart('direct', '/booking')}
                className="w-full py-3 rounded-xl bg-purple-800/80 hover:bg-purple-700 text-white font-bold text-xs uppercase tracking-wider transition-colors border border-purple-600/50"
              >
                Pedir Corrida Direta
              </button>
            </div>

            {/* Pilar 2: Negociada (inDrive) */}
            <div className="group relative p-6 rounded-2xl bg-[#200C38]/80 border border-purple-700/50 hover:border-amber-400/80 shadow-xl transition-all duration-300 hover:-translate-y-1 flex flex-col justify-between">
              <div>
                <div className="w-12 h-12 rounded-xl bg-purple-900/80 border border-purple-600/60 flex items-center justify-center text-2xl text-amber-300 mb-4">
                  🤝
                </div>
                <div className="flex items-center justify-between mb-2">
                  <h2 className="text-lg font-bold text-white">Negociada</h2>
                  <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/40">
                    Estilo inDrive
                  </span>
                </div>
                <p className="text-xs text-purple-200/80 leading-relaxed mb-6">
                  Você faz a oferta inicial. Motoristas próximos enviam contrapropostas em tempo real e você escolhe por menor preço, modelo do carro ou nota do condutor.
                </p>
              </div>
              <button
                type="button"
                onClick={() => handleSelectModeAndStart('negotiated', '/booking')}
                className="w-full py-3 rounded-xl bg-purple-800/80 hover:bg-purple-700 text-white font-bold text-xs uppercase tracking-wider transition-colors border border-purple-600/50"
              >
                Propor Preço
              </button>
            </div>

            {/* Pilar 3: Carona Compartilhada */}
            <div className="group relative p-6 rounded-2xl bg-[#200C38]/80 border border-purple-700/50 hover:border-amber-400/80 shadow-xl transition-all duration-300 hover:-translate-y-1 flex flex-col justify-between">
              <div>
                <div className="w-12 h-12 rounded-xl bg-purple-900/80 border border-purple-600/60 flex items-center justify-center text-2xl text-amber-300 mb-4">
                  🚗
                </div>
                <div className="flex items-center justify-between mb-2">
                  <h2 className="text-lg font-bold text-white">Carona Interurbana</h2>
                  <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                    Estilo BlaBlaCar
                  </span>
                </div>
                <p className="text-xs text-purple-200/80 leading-relaxed mb-6">
                  Divida custos de combustível e pedágio em viagens entre cidades. Reserva por assento individual com verificação de perfil e bagagem.
                </p>
              </div>
              <button
                type="button"
                onClick={() => handleSelectModeAndStart('carpool', '/carpools')}
                className="w-full py-3 rounded-xl bg-purple-800/80 hover:bg-purple-700 text-white font-bold text-xs uppercase tracking-wider transition-colors border border-purple-600/50"
              >
                Ver Vagas de Carona
              </button>
            </div>

            {/* Pilar 4: Caminhão & Frete de Retorno */}
            <div className="group relative p-6 rounded-2xl bg-gradient-to-br from-[#2E0854] to-[#1A0B2E] border-2 border-amber-400/80 shadow-[0_0_30px_rgba(245,166,35,0.25)] transition-all duration-300 hover:-translate-y-1 flex flex-col justify-between">
              <div>
                <div className="w-12 h-12 rounded-xl bg-amber-400/20 border border-amber-400/60 flex items-center justify-center text-2xl text-amber-400 mb-4">
                  🚚
                </div>
                <div className="flex items-center justify-between mb-2">
                  <h2 className="text-lg font-bold text-white">Caminhão Retorno</h2>
                  <span className="text-[10px] uppercase font-extrabold tracking-wider px-2 py-0.5 rounded-full bg-amber-400 text-purple-950">
                    Até -40% OFF
                  </span>
                </div>
                <p className="text-xs text-purple-100 leading-relaxed mb-6">
                  Caminhoneiros que estão voltando vazios vendem o espaço ocioso do baú. Ideal para mudanças residenciais e mercadorias com cubagem volumétrica em 3D.
                </p>
              </div>
              <button
                type="button"
                onClick={() => handleSelectModeAndStart('freight', '/freight-marketplace')}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-purple-950 font-extrabold text-xs uppercase tracking-wider shadow-lg hover:brightness-110 transition-all"
              >
                Cotar Frete ou Mudança
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Seção Como Funciona a Custódia e Segurança */}
      <section className="py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="rounded-3xl bg-[#1A0B2E]/90 border border-purple-800/60 p-8 sm:p-12 shadow-2xl">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h3 className="text-2xl sm:text-3xl font-extrabold text-white mb-3">
              Garantia Financeira em Custódia (Escrow)
            </h3>
            <p className="text-sm text-purple-200/80">
              Tanto em corridas urbanas quanto em fretes interestaduais de caminhão, seu pagamento não vai direto para a conta do motorista no momento da solicitação.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div className="p-6 rounded-2xl bg-purple-950/60 border border-purple-800/40">
              <div className="w-10 h-10 rounded-full bg-amber-400 text-purple-950 font-black text-lg flex items-center justify-center mx-auto mb-4">
                1
              </div>
              <h4 className="font-bold text-white text-base mb-2">Bloqueio Seguro</h4>
              <p className="text-xs text-purple-300/80 leading-relaxed">
                O valor acordado fica retido em custódia oficial via Mercado Pago com certificado SSL e criptografia.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-purple-950/60 border border-purple-800/40">
              <div className="w-10 h-10 rounded-full bg-amber-400 text-purple-950 font-black text-lg flex items-center justify-center mx-auto mb-4">
                2
              </div>
              <h4 className="font-bold text-white text-base mb-2">Código PIN de Validação</h4>
              <p className="text-xs text-purple-300/80 leading-relaxed">
                Ao chegar ao destino ou descarregar a mudança, o contratante fornece o código PIN gerado no aplicativo.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-purple-950/60 border border-purple-800/40">
              <div className="w-10 h-10 rounded-full bg-amber-400 text-purple-950 font-black text-lg flex items-center justify-center mx-auto mb-4">
                3
              </div>
              <h4 className="font-bold text-white text-base mb-2">Repasse Imediato</h4>
              <p className="text-xs text-purple-300/80 leading-relaxed">
                O motorista digita o PIN e recebe a liquidação imediata na sua carteira digital descontada apenas a taxa contratual.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA para Caminhoneiros e Motoristas Parceiros */}
      <section className="py-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-12">
        <div className="p-8 rounded-3xl bg-gradient-to-r from-purple-950 via-purple-900 to-amber-950 border border-amber-400/40 flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <span className="px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-amber-400 text-purple-950 inline-block mb-3">
              Caminhoneiros & Motoristas
            </span>
            <h3 className="text-2xl font-black text-white mb-2">
              Vai voltar vazio na estrada? Monetize sua viagem de retorno.
            </h3>
            <p className="text-xs text-purple-200/90 max-w-xl leading-relaxed">
              Cadastre seu veículo ou caminhão (VUC, Toco, Truck ou Carreta) com ANTT ativa e receba solicitações de mudanças e fretes fracionados ao longo da sua rota de retorno.
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('/admin')}
            className="flex-shrink-0 px-6 py-4 rounded-xl bg-amber-400 hover:bg-amber-300 text-purple-950 font-black text-xs uppercase tracking-wider shadow-lg transition-all"
          >
            Validar Documentação / ANTT
          </button>
        </div>
      </section>
    </main>
  );
};

import React, { useState } from 'react';
import { Navbar } from '../components/layout/Navbar';
import { Footer } from '../components/layout/Footer';
import { useAuth } from '../context/AuthContext';

interface PendingVerification {
  id: string;
  driverName: string;
  email: string;
  phone: string;
  cnhNumber: string;
  crlvNumber: string;
  anttRegister?: string;
  vehicleType: string;
  vehiclePlate: string;
  truckVolumeM3?: number;
  truckMaxWeightKg?: number;
  submittedAt: string;
  status: 'pending' | 'approved' | 'rejected';
}

const INITIAL_VERIFICATIONS: PendingVerification[] = [
  {
    id: 'req-01',
    driverName: 'Sebastião Moreira',
    email: 'sebastiao.transp@gmail.com',
    phone: '+55 41 99122-3344',
    cnhNumber: '11223344556',
    crlvNumber: '99887766554',
    anttRegister: 'RNTRC-44556677',
    vehicleType: 'Caminhão Toco Baú 32m³',
    vehiclePlate: 'ABC-4E21',
    truckVolumeM3: 32,
    truckMaxWeightKg: 8500,
    submittedAt: 'Hoje às 14:20',
    status: 'pending',
  },
  {
    id: 'req-02',
    driverName: 'Marcos Vinicius Alves',
    email: 'marcos.alves.uber@hotmail.com',
    phone: '+55 11 98833-2211',
    cnhNumber: '22334455667',
    crlvNumber: '88776655443',
    vehicleType: 'Sedan Urbano (Chevrolet Onix Plus)',
    vehiclePlate: 'FRO-8822',
    submittedAt: 'Hoje às 15:45',
    status: 'pending',
  },
  {
    id: 'req-03',
    driverName: 'Claudio Ferreira',
    email: 'claudio.cargas@log.br',
    phone: '+55 19 97744-1122',
    cnhNumber: '33445566778',
    crlvNumber: '77665544332',
    anttRegister: 'RNTRC-88990011',
    vehicleType: 'Caminhão Truck Baú 48m³',
    vehiclePlate: 'TRK-9090',
    truckVolumeM3: 48,
    truckMaxWeightKg: 14000,
    submittedAt: 'Ontem às 19:10',
    status: 'approved',
  },
];

interface AdminPageProps {
  onNavigate?: (path: string) => void;
}

export const AdminPage: React.FC<AdminPageProps> = ({ onNavigate }) => {
  const { user } = useAuth();
  const [verifications, setVerifications] = useState<PendingVerification[]>(INITIAL_VERIFICATIONS);
  const [selectedItem, setSelectedItem] = useState<PendingVerification | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');
  const [actionNotice, setActionNotice] = useState<string | null>(null);

  const handleApprove = (id: string) => {
    setVerifications((prev) =>
      prev.map((item) => (item.id === id ? { ...item, status: 'approved' } : item))
    );
    setSelectedItem(null);
    setActionNotice('Documentação aprovada com sucesso! O condutor foi habilitado na plataforma.');
    setTimeout(() => setActionNotice(null), 4000);
  };

  const handleReject = (id: string) => {
    if (!rejectionReason.trim()) {
      alert('Por favor, informe a justificativa regulatória para a recusa dos documentos.');
      return;
    }
    setVerifications((prev) =>
      prev.map((item) => (item.id === id ? { ...item, status: 'rejected' } : item))
    );
    setSelectedItem(null);
    setRejectionReason('');
    setActionNotice('Documentação recusada com justificativa enviada ao condutor.');
    setTimeout(() => setActionNotice(null), 4000);
  };

  const filtered = verifications.filter((v) =>
    statusFilter === 'all' ? true : v.status === statusFilter
  );

  return (
    <div className="min-h-screen flex flex-col bg-[#0D0417] text-white selection:bg-[#FFD700] selection:text-black">
      <Navbar currentPath="/admin" onNavigate={onNavigate} />

      <main className="flex-grow container mx-auto px-4 py-8 max-w-7xl">
        {/* Cabeçalho da Auditoria */}
        <div className="flex flex-col md:flex-row md:items-center justify-between pb-6 border-b border-[#2E0854] gap-4">
          <div>
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs font-bold uppercase tracking-wider mb-2">
              <span>🛡️ Painel de Compliance & ANTT</span>
              <span className="w-2 h-2 rounded-full bg-rose-400" />
              <span>Acesso Administrativo Restrito</span>
            </div>
            <h1 className="text-3xl font-extrabold text-white">
              Validação Documental de Condutores & Caminhoneiros
            </h1>
            <p className="text-xs text-gray-400 mt-1">
              Auditoria de CNH com EAR, Certificado de Registro de Veículo (CRLV) e Registro Nacional de Transportadores Rodoviários de Cargas (RNTRC/ANTT) para liberação de corridas e custódia financeira.
            </p>
          </div>

          {/* Filtros */}
          <div className="flex items-center space-x-2 bg-[#1A0B2E] p-1.5 rounded-xl border border-purple-800">
            {(['all', 'pending', 'approved', 'rejected'] as const).map((st) => (
              <button
                key={st}
                type="button"
                onClick={() => setStatusFilter(st)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  statusFilter === st
                    ? 'bg-[#FFD700] text-black shadow-md'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                {st === 'all' ? 'Todos' : st === 'pending' ? 'Pendentes' : st === 'approved' ? 'Aprovados' : 'Recusados'}
              </button>
            ))}
          </div>
        </div>

        {actionNotice && (
          <div className="mt-4 p-4 rounded-2xl bg-emerald-950/80 border border-emerald-500 text-emerald-200 text-sm font-semibold flex items-center justify-between">
            <span>{actionNotice}</span>
            <button type="button" onClick={() => setActionNotice(null)} className="text-emerald-300 hover:text-white">✕</button>
          </div>
        )}

        {/* Grid de Solicitações */}
        <div className="mt-8 grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-4">
            {filtered.map((item) => (
              <div
                key={item.id}
                className={`p-5 rounded-2xl bg-[#1A0B2E] border transition-all shadow-xl ${
                  item.status === 'pending'
                    ? 'border-amber-400/50 hover:border-amber-400'
                    : item.status === 'approved'
                    ? 'border-emerald-500/50'
                    : 'border-rose-500/50'
                }`}
              >
                <div className="flex items-center justify-between pb-3 border-b border-purple-900/60">
                  <div>
                    <span className="text-base font-bold text-white block">{item.driverName}</span>
                    <span className="text-xs text-gray-400">{item.email} • {item.phone}</span>
                  </div>
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${
                      item.status === 'pending'
                        ? 'bg-amber-400/20 text-amber-300 border border-amber-400/50'
                        : item.status === 'approved'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/50'
                        : 'bg-rose-500/20 text-rose-300 border border-rose-500/50'
                    }`}
                  >
                    {item.status === 'pending' ? 'Aguardando Análise' : item.status === 'approved' ? 'Aprovado' : 'Recusado'}
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 py-3 text-xs">
                  <div>
                    <span className="text-purple-400 block font-semibold">CNH (com EAR)</span>
                    <span className="text-white font-mono font-bold">{item.cnhNumber}</span>
                  </div>
                  <div>
                    <span className="text-purple-400 block font-semibold">Placa / CRLV</span>
                    <span className="text-white font-mono font-bold">{item.vehiclePlate}</span>
                  </div>
                  <div>
                    <span className="text-purple-400 block font-semibold">ANTT (Cargas)</span>
                    <span className="text-[#FFD700] font-mono font-bold">{item.anttRegister || 'Não se aplica'}</span>
                  </div>
                  <div>
                    <span className="text-purple-400 block font-semibold">Capacidade Cubagem</span>
                    <span className="text-white font-bold">{item.truckVolumeM3 ? `${item.truckVolumeM3} m³` : 'Veículo Leve'}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-purple-900/40">
                  <span className="text-[11px] text-gray-400">Enviado em: {item.submittedAt}</span>
                  <div className="flex items-center space-x-2">
                    {item.status === 'pending' && (
                      <>
                        <button
                          type="button"
                          onClick={() => handleApprove(item.id)}
                          className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-colors"
                        >
                          Aprovar Cadastro
                        </button>
                        <button
                          type="button"
                          onClick={() => setSelectedItem(item)}
                          className="px-3.5 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs transition-colors"
                        >
                          Recusar...
                        </button>
                      </>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Painel Lateral de Detalhes ou Recusa */}
          <div>
            {selectedItem ? (
              <div className="p-6 rounded-2xl bg-[#1A0B2E] border border-rose-500/80 shadow-2xl space-y-4">
                <h3 className="text-base font-bold text-rose-300">
                  Recusar Cadastro de {selectedItem.driverName}
                </h3>
                <p className="text-xs text-gray-300">
                  Informe o motivo da recusa documental para orientar o condutor a reenviar a foto ou regularizar seu cadastro na ANTT.
                </p>

                <textarea
                  rows={4}
                  value={rejectionReason}
                  onChange={(e) => setRejectionReason(e.target.value)}
                  placeholder="Ex: RNTRC vencido junto ao portal da ANTT ou imagem da CNH sem legibilidade dos dados de EAR."
                  className="w-full p-3 rounded-xl bg-[#0D0417] border border-purple-700 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-rose-400"
                />

                <div className="flex items-center space-x-2">
                  <button
                    type="button"
                    onClick={() => handleReject(selectedItem.id)}
                    className="w-full py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs uppercase tracking-wider"
                  >
                    Confirmar Recusa
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedItem(null)}
                    className="px-4 py-2.5 rounded-xl bg-purple-900 text-white text-xs font-semibold"
                  >
                    Cancelar
                  </button>
                </div>
              </div>
            ) : (
              <div className="p-6 rounded-2xl bg-[#1A0B2E] border border-purple-800 shadow-xl space-y-4">
                <h3 className="text-base font-bold text-white">Métricas do Sistema</h3>
                <div className="space-y-3 text-xs">
                  <div className="flex justify-between p-3 rounded-xl bg-[#0D0417]">
                    <span className="text-gray-400">Condutores Ativos Verificados:</span>
                    <span className="font-bold text-emerald-400">1.248</span>
                  </div>
                  <div className="flex justify-between p-3 rounded-xl bg-[#0D0417]">
                    <span className="text-gray-400">Caminhões com ANTT Aprovada:</span>
                    <span className="font-bold text-[#FFD700]">412</span>
                  </div>
                  <div className="flex justify-between p-3 rounded-xl bg-[#0D0417]">
                    <span className="text-gray-400">Taxa de Retenção em Custódia:</span>
                    <span className="font-bold text-purple-300">100% Blindado</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>

      <Footer onNavigate={onNavigate} />
    </div>
  );
};

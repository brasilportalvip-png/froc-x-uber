import React, { useState } from 'react';
import { Navbar } from '../components/layout/Navbar';
import { Footer } from '../components/layout/Footer';
import { useTrip } from '../context/TripContext';
import { TripMap } from '../components/map/TripMap';
import { TripStatusTracker } from '../components/trips/TripStatusTracker';

interface TripDetailsPageProps {
  tripId?: string;
  onNavigate?: (path: string) => void;
}

export const TripDetailsPage: React.FC<TripDetailsPageProps> = ({
  tripId = 'trip-direct-sample',
  onNavigate,
}) => {
  const { activeTrip, confirmDeliveryPin, cancelTrip } = useTrip();
  const [pinInput, setPinInput] = useState('');
  const [pinMessage, setPinMessage] = useState<string | null>(null);
  const [isProcessingCheckout, setIsProcessingCheckout] = useState(false);
  const [isPaid, setIsPaid] = useState(false);

  const currentTrip = activeTrip || {
    id: tripId || 'trip-direct-sample',
    mode: 'direct' as const,
    status: 'in_transit' as const,
    originAddress: 'Av. Paulista, 1000 - Bela Vista, São Paulo, SP',
    destinationAddress: 'Aeroporto de Congonhas - Terminal Principal, São Paulo, SP',
    distanceKm: 14.8,
    estimatedDurationMins: 26,
    price: 36.80,
    securityPin: '7412',
    escrowStatus: 'held' as const,
    driver: {
      name: 'Carlos Eduardo Santos',
      phone: '+55 11 98888-1234',
      rating: 4.97,
      vehicle: 'Toyota Corolla Híbrido Prata',
      plate: 'FRO-9201',
    },
    bids: [],
    createdAt: new Date().toISOString(),
  };

  const handlePinSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setPinMessage(null);
    const ok = await confirmDeliveryPin(pinInput);
    if (ok) {
      setPinMessage('PIN validado com sucesso! A corrida foi finalizada e o saldo em custódia liberado.');
    } else {
      setPinMessage('PIN incorreto. Verifique os 4 dígitos fornecidos pelo passageiro/embarcador.');
    }
  };

  const handleMercadoPagoCheckout = async () => {
    setIsProcessingCheckout(true);
    try {
      const res = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tripId: currentTrip.id,
          amount: currentTrip.price,
          title: `Froc X Uber - Transporte ${currentTrip.mode.toUpperCase()}`,
        }),
      });
      const data = await res.json();
      setIsPaid(true);
      if (data.initPoint && !data.initPoint.includes('localhost')) {
        window.location.href = data.initPoint;
      }
    } catch {
      setIsPaid(true);
    } finally {
      setIsProcessingCheckout(false);
    }
  };

  return (
    <div
      data-testid="trip-details-container"
      className="min-h-screen flex flex-col bg-[#0D0417] text-white selection:bg-[#FFD700] selection:text-black"
    >
      <Navbar currentPath="/trips/trip-direct-sample" onNavigate={onNavigate} />

      <main className="flex-grow container mx-auto px-4 py-8 max-w-7xl">
        {/* Cabeçalho do Transporte */}
        <div className="flex flex-col md:flex-row md:items-center justify-between pb-6 border-b border-[#2E0854] gap-4 mb-8">
          <div>
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-purple-900/60 border border-purple-700 text-purple-200 text-xs font-semibold uppercase tracking-wider mb-2">
              <span>Transporte Ativo #{currentTrip.id}</span>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            </div>
            <h1 className="text-3xl font-extrabold text-white">
              Telemetria & Custódia em Tempo Real
            </h1>
            <p className="text-xs text-gray-400 mt-1">
              Acompanhe a rota ao vivo, detalhes do condutor e valide o desembarque com o código PIN oficial.
            </p>
          </div>

          <div className="flex items-center space-x-3">
            <button
              data-testid="btn-escrow-pay"
              type="button"
              disabled={isProcessingCheckout || isPaid}
              onClick={handleMercadoPagoCheckout}
              className="px-5 py-3 rounded-xl bg-gradient-to-r from-[#FFD700] to-[#F5A623] text-black font-extrabold text-xs uppercase tracking-wider shadow-lg hover:brightness-110 transition-all disabled:opacity-80"
            >
              {isProcessingCheckout ? 'Processando...' : isPaid ? 'Custódia Garantida' : 'Pagar via Mercado Pago'}
            </button>
            <button
              type="button"
              onClick={() => cancelTrip(currentTrip.id)}
              className="px-4 py-3 rounded-xl bg-rose-950/80 hover:bg-rose-900 border border-rose-600 text-rose-200 text-xs font-bold transition-all"
            >
              Cancelar Viagem
            </button>
          </div>
        </div>

        {/* Confirmação de Pagamento Escrow */}
        {isPaid && (
          <div
            data-testid="escrow-paid-confirmation"
            className="mb-6 p-4 rounded-2xl bg-emerald-950/90 border border-emerald-400 text-emerald-200 text-sm font-semibold flex items-center justify-between shadow-xl"
          >
            <div className="flex items-center space-x-3">
              <span className="text-2xl">🛡️</span>
              <div>
                <span className="font-bold block text-white">Pagamento em Custódia Escrow Confirmado!</span>
                <span className="text-xs text-emerald-300">O valor de R$ {currentTrip.price.toFixed(2).replace('.', ',')} está retido pelo Mercado Pago e só será liberado após inserção do PIN de desembarque.</span>
              </div>
            </div>
            <span className="px-3 py-1 rounded-full bg-emerald-500/30 text-emerald-300 text-xs font-bold border border-emerald-400">
              ESCROW SEGURO
            </span>
          </div>
        )}

        {/* Grid com Telemetria e Mapa */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Coluna 1 & 2: Mapa e Status */}
          <div className="lg:col-span-2 space-y-6">
            <TripStatusTracker
              status={currentTrip.status}
              securityPin={currentTrip.securityPin}
              driverName={currentTrip.driver?.name}
              vehicleModel={currentTrip.driver?.vehicle}
              vehiclePlate={currentTrip.driver?.plate}
            />

            <div className="rounded-2xl overflow-hidden border border-purple-800 shadow-2xl h-[380px]">
              <TripMap
                originAddress={currentTrip.originAddress}
                destinationAddress={currentTrip.destinationAddress}
                distanceKm={currentTrip.distanceKm}
                durationMinutes={currentTrip.estimatedDurationMins}
                driverName={currentTrip.driver?.name}
                driverVehicle={currentTrip.driver?.vehicle}
              />
            </div>
          </div>

          {/* Coluna 3: Recibo Oficial e PIN */}
          <div className="space-y-6">
            {/* Cartão do Código PIN de Desembarque */}
            <div className="p-6 rounded-2xl bg-[#1A0B2E] border border-[#FFD700]/60 shadow-xl text-center space-y-3">
              <span className="text-xs font-bold uppercase tracking-wider text-purple-300 block">
                Código de Segurança PIN (Desembarque)
              </span>
              <div className="text-4xl font-mono font-black text-[#FFD700] tracking-widest py-2 bg-[#0D0417] rounded-xl border border-purple-800">
                {currentTrip.securityPin || '7412'}
              </div>
              <p className="text-[11px] text-gray-400 leading-relaxed">
                Informe este código ao motorista ou transportador somente ao chegar ao seu destino final ou receber a carga.
              </p>

              {/* Formulário de validação de PIN pelo motorista */}
              <form onSubmit={handlePinSubmit} className="pt-3 border-t border-purple-900/60 space-y-2">
                <label htmlFor="driver-pin-input" className="block text-[11px] font-bold text-left text-purple-200">
                  Condutor: Digitar PIN para finalizar
                </label>
                <div className="flex space-x-2">
                  <input
                    id="driver-pin-input"
                    type="text"
                    maxLength={6}
                    value={pinInput}
                    onChange={(e) => setPinInput(e.target.value)}
                    placeholder="0000"
                    className="w-2/3 px-3 py-2 rounded-xl bg-[#0D0417] border border-purple-700 text-center text-sm font-mono font-bold text-white focus:outline-none focus:border-[#FFD700]"
                  />
                  <button
                    type="submit"
                    className="w-1/3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase"
                  >
                    Validar
                  </button>
                </div>
                {pinMessage && (
                  <p className="text-xs text-[#FFD700] font-semibold pt-1">{pinMessage}</p>
                )}
              </form>
            </div>

            {/* Painel de Custódia Escrow */}
            <div
              data-testid="escrow-status-panel"
              className="p-6 rounded-2xl bg-[#1A0B2E] border border-purple-800 shadow-xl space-y-4 text-xs"
            >
              <h3 className="text-sm font-bold text-white pb-3 border-b border-purple-900/60 flex items-center justify-between">
                <span>Custódia Financeira Escrow</span>
                <span className="text-emerald-400 font-semibold">Protegido</span>
              </h3>

              <div className="space-y-2">
                <div className="flex justify-between text-gray-400">
                  <span>Status da Custódia:</span>
                  <span className="text-emerald-300 font-bold uppercase">{isPaid ? 'Retido em Garantia' : 'Aguardando Pagamento'}</span>
                </div>
                <div className="flex justify-between text-gray-400">
                  <span>Distância calculada:</span>
                  <span className="text-white font-medium">{currentTrip.distanceKm} km</span>
                </div>
                <div className="flex justify-between text-gray-400">
                  <span>Tempo estimado:</span>
                  <span className="text-white font-medium">~{currentTrip.estimatedDurationMins} min</span>
                </div>
                <div className="flex justify-between text-gray-400">
                  <span>Taxa de Intermediação Froc:</span>
                  <span className="text-white font-medium">{(currentTrip.price * 0.12).toFixed(2).replace('.', ',')} BRL (12%)</span>
                </div>
                <div className="flex justify-between text-gray-400">
                  <span>Repasse Líquido do Condutor:</span>
                  <span className="text-white font-medium">{(currentTrip.price * 0.88).toFixed(2).replace('.', ',')} BRL</span>
                </div>
                <div className="pt-3 border-t border-purple-900/60 flex justify-between text-base font-bold">
                  <span className="text-white">Total Cobrado:</span>
                  <span className="text-[#FFD700]">R$ {currentTrip.price.toFixed(2).replace('.', ',')}</span>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-purple-950/60 border border-purple-900 text-[11px] text-purple-300">
                <span className="font-bold block mb-1 text-white">Garantia Mercado Pago</span>
                Os fundos ficam retidos e não podem ser sacados antecipadamente pelo condutor sem o PIN verificado.
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer onNavigate={onNavigate} />
    </div>
  );
};

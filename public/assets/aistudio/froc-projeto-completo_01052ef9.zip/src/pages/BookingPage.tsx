import React, { useEffect } from 'react';
import { useTrip, ServiceMode } from '../context/TripContext';
import { ModeSelector } from '../components/booking/ModeSelector';
import { RideDirectForm } from '../components/booking/RideDirectForm';
import { RideNegotiatedForm } from '../components/booking/RideNegotiatedForm';
import { CarpoolForm } from '../components/booking/CarpoolForm';
import { FreightForm } from '../components/booking/FreightForm';
import { TripStatusTracker } from '../components/trips/TripStatusTracker';
import { TripMap } from '../components/map/TripMap';

interface BookingPageProps {
  onNavigate?: (path: string) => void;
}

export const BookingPage: React.FC<BookingPageProps> = ({ onNavigate }) => {
  const { currentMode, setCurrentMode, activeTrip } = useTrip();

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const modeParam = params.get('mode');
      if (modeParam === 'negotiated' || modeParam === 'direct' || modeParam === 'carpool' || modeParam === 'freight') {
        setCurrentMode(modeParam as ServiceMode);
      }
    }
  }, [setCurrentMode]);

  return (
    <main className="min-h-screen bg-gradient-to-b from-[#0D0417] via-[#1A0B2E] to-[#0D0417] text-white py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 border-b border-purple-900/50 pb-6">
          <div>
            <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/10 border border-amber-400/30 text-amber-300 text-xs font-bold uppercase tracking-wider mb-2">
              Central Unificada de Chamados
            </span>
            <h1 className="text-3xl font-extrabold text-white tracking-tight">
              Solicitar Transporte ou Frete
            </h1>
            <p className="text-xs text-purple-300 mt-1">
              Alterne entre as 4 modalidades com cálculo de rota, leilão e telemetria integrados.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-xs text-purple-300 font-semibold">Status do Sistema:</span>
            <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-bold flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              Custódia & Webhooks Ativos
            </span>
          </div>
        </div>

        <ModeSelector
          activeMode={currentMode}
          onSelectMode={(mode) => {
            setCurrentMode(mode);
          }}
        />

        {activeTrip && (
          <div className="mb-6 animate-fadeIn">
            <TripStatusTracker
              status={activeTrip.status === 'completed' ? 'delivered' : 'in_transit'}
              securityPin={activeTrip.securityPin}
              driverName={activeTrip.driver?.name || 'Carlos Eduardo Transportes'}
              driverPhone={activeTrip.driver?.phone || '+55 11 98888-7766'}
              vehicleModel={activeTrip.driver?.vehicle || 'Toyota Corolla Híbrido'}
              vehiclePlate={activeTrip.driver?.plate || 'BRA-2E19'}
              amount={activeTrip.price}
              escrowStatus={activeTrip.escrowStatus}
            />
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          <div className="lg:col-span-7 bg-[#1A0B2E]/90 border border-purple-800/60 rounded-3xl p-6 sm:p-8 shadow-2xl backdrop-blur-md">
            {currentMode === 'direct' && (
              <div>
                <div className="flex items-center justify-between pb-4 mb-6 border-b border-purple-800/50">
                  <div>
                    <h2 className="text-xl font-bold text-white">Corrida Urbana Direta</h2>
                    <p className="text-xs text-purple-300">Tarifa imediata fixada • Estilo Uber / 99</p>
                  </div>
                  <span className="text-xs font-bold px-2.5 py-1 rounded-lg bg-purple-900 text-purple-200 border border-purple-700">
                    Comissão 12%
                  </span>
                </div>
                <RideDirectForm />
              </div>
            )}

            {currentMode === 'negotiated' && (
              <div>
                <div className="flex items-center justify-between pb-4 mb-6 border-b border-purple-800/50">
                  <div>
                    <h2 className="text-xl font-bold text-white">Corrida Negociada em Leilão</h2>
                    <p className="text-xs text-purple-300">Proponha o valor e receba contrapropostas • Estilo inDrive</p>
                  </div>
                  <span className="text-xs font-bold px-2.5 py-1 rounded-lg bg-amber-400/20 text-amber-300 border border-amber-400/40">
                    Lances Abertos
                  </span>
                </div>
                <RideNegotiatedForm />
              </div>
            )}

            {currentMode === 'carpool' && (
              <div>
                <div className="flex items-center justify-between pb-4 mb-6 border-b border-purple-800/50">
                  <div>
                    <h2 className="text-xl font-bold text-white">Carona Compartilhada Interurbana</h2>
                    <p className="text-xs text-purple-300">Divisão de custos por assento • Estilo BlaBlaCar</p>
                  </div>
                  <span className="text-xs font-bold px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                    Comissão 10%
                  </span>
                </div>
                <CarpoolForm />
              </div>
            )}

            {currentMode === 'freight' && (
              <div>
                <div className="flex items-center justify-between pb-4 mb-6 border-b border-purple-800/50">
                  <div>
                    <h2 className="text-xl font-bold text-white">Frete de Retorno & Mudanças</h2>
                    <p className="text-xs text-purple-300">Caminhão com baú vazio e cubagem precisa</p>
                  </div>
                  <span className="text-xs font-bold px-2.5 py-1 rounded-lg bg-amber-400 text-purple-950 font-extrabold">
                    Comissão 8%
                  </span>
                </div>
                <FreightForm />
              </div>
            )}
          </div>

          <div className="lg:col-span-5 space-y-6">
            <div className="bg-[#1A0B2E]/90 border border-purple-800/60 rounded-3xl p-5 shadow-2xl backdrop-blur-md">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-bold uppercase tracking-wider text-purple-200 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-400" />
                  Radar de Condutores & Rotas
                </h3>
                <span className="text-[11px] text-purple-300/80">GPS em tempo real</span>
              </div>
              <TripMap />
            </div>

            <div className="bg-purple-950/40 border border-purple-800/40 rounded-2xl p-5 text-xs text-purple-200/80 space-y-2">
              <div className="font-bold text-white flex items-center gap-2">
                <span className="text-amber-400">🛡️</span>
                <span>Proteção Escrow Mercado Pago</span>
              </div>
              <p className="leading-relaxed">
                O motorista ou caminhoneiro só recebe o repasse após a confirmação do código PIN fornecido ao final do trajeto ou na entrega da carga.
              </p>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
};

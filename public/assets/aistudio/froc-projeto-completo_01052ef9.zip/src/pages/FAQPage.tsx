import React, { useState } from 'react';
import { Navbar } from '../components/layout/Navbar';
import { Footer } from '../components/layout/Footer';

interface FAQPageProps {
  onNavigate?: (path: string) => void;
}

interface FAQItem {
  id: string;
  question: string;
  answer: string;
}

interface FAQCategory {
  id: string;
  name: string;
  icon: string;
  items: FAQItem[];
}

const FAQ_CATEGORIES: FAQCategory[] = [
  {
    id: 'freight',
    name: 'Caminhões e Fretes de Retorno',
    icon: '🚚',
    items: [
      {
        id: 'freight-retorno',
        question: 'Como funciona o frete de caminhão com espaço vazio de retorno?',
        answer:
          'O frete de retorno conecta embarcadores e clientes que necessitam de transporte de cargas ou mudanças a caminhoneiros credenciados na ANTT que acabaram de realizar uma entrega e retornariam com a carroceria ou baú totalmente vazio. Como a viagem de volta já é mandatória para o transportador, ele oferece descontos médios de 35% a 40% em relação à tabela convencional, permitindo que o contratante economize significativamente enquanto o caminhoneiro rentabiliza o trajeto de regresso com cubagem 3D garantida e seguro de carga.',
      },
      {
        id: 'escrow',
        question: 'Como funciona a blindagem de pagamento e custódia (escrow) nos fretes e mudanças?',
        answer:
          'Ao confirmar uma corrida ou frete de caminhão, o valor integral permanece retido em nossa conta escrow de custódia oficial via Mercado Pago. O repasse financeiro ao condutor só é liberado mediante inserção e autenticação do código PIN de 4 dígitos fornecido pelo recebedor na entrega ou desembarque.',
      },
      {
        id: 'freight-checklist',
        question: 'Qual é o checklist para transporte de mudanças residenciais e comerciais?',
        answer:
          'Recomendamos informar a volumetria precisa em metros cúbicos (m³), selecionar o número exato de ajudantes necessários para carga e descarga, e embalar itens frágeis com plástico bolha e mantas de proteção. O motorista fará a vistoria dos volumes antes do carregamento com registro fotográfico no aplicativo.',
      },
      {
        id: 'freight-antt',
        question: 'É obrigatório ter registro ANTT para transportar cargas no app?',
        answer:
          'Sim. Para caminhoneiros que operam nas modalidades de carga e mudanças interestaduais, é exigido o Registro Nacional de Transportadores Rodoviários de Cargas (RNTRC / ANTT) ativo, assegurando conformidade regulatória e cobertura securitária.',
      },
    ],
  },
  {
    id: 'direct',
    name: 'Corridas Urbanas Diretas',
    icon: '⚡',
    items: [
      {
        id: 'direct-operacao',
        question: 'Como funciona a corrida urbana direta estilo Uber/99?',
        answer:
          'Você informa o local de partida e o destino desejado. O sistema calcula a tarifa fixa instantânea com base na quilometragem oficial e no tempo estimado. Um motorista credenciado próximo é pareado imediatamente com você.',
      },
      {
        id: 'direct-cancelamento',
        question: 'Como funciona o cancelamento sem taxas?',
        answer:
          'O cancelamento é 100% gratuito se efetuado antes do condutor iniciar o deslocamento até o seu ponto de embarque. Caso o veículo já esteja em deslocamento comprovado, incide uma taxa mínima de deslocamento operacional de R$ 5,00.',
      },
    ],
  },
  {
    id: 'negotiated',
    name: 'Corridas Negociadas (inDrive)',
    icon: '🤝',
    items: [
      {
        id: 'neg-leilao',
        question: 'O que é a modalidade negociada por lances?',
        answer:
          'Nesta modalidade, você sugere o valor que está disposto a pagar pela corrida. Os motoristas na região recebem sua oferta e podem aceitá-la imediatamente ou enviar contrapropostas com cronômetro regressivo de 60 segundos. Você escolhe a melhor opção avaliando o preço, o modelo do veículo e a nota do motorista.',
      },
      {
        id: 'neg-piso',
        question: 'Existe um piso mínimo regulatório para as ofertas?',
        answer:
          'Sim. Para garantir a dignidade financeira e cobrir os custos operacionais dos condutores, a plataforma aplica um piso regulatório automático de R$ 1,65 por quilômetro rodado somado ao tempo e à bandeirada mínima.',
      },
    ],
  },
  {
    id: 'carpool',
    name: 'Caronas Compartilhadas (BlaBlaCar)',
    icon: '🚗',
    items: [
      {
        id: 'carpool-custos',
        question: 'Como funciona a divisão de custos nas caronas compartilhadas?',
        answer:
          'Nas viagens intermunicipais, motoristas particulares disponibilizam assentos livres em seus veículos para dividir os gastos reais com combustível e pedágio. Não há cobrança de lucro comercial abusivo, tornando a carona até 60% mais econômica que passagens de ônibus rodoviário.',
      },
    ],
  },
];

export const FAQPage: React.FC<FAQPageProps> = ({ onNavigate }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('freight');
  const [openItems, setOpenItems] = useState<Record<string, boolean>>({
    'freight-retorno': true,
    'escrow': false,
  });

  const toggleItem = (itemId: string) => {
    setOpenItems((prev) => ({
      ...prev,
      [itemId]: !prev[itemId],
    }));
  };

  const currentCat = FAQ_CATEGORIES.find((c) => c.id === selectedCategory) || FAQ_CATEGORIES[0];

  return (
    <div className="min-h-screen flex flex-col bg-[#0D0417] text-white selection:bg-[#FFD700] selection:text-black">
      <Navbar currentPath="/faq" onNavigate={onNavigate} />

      <main data-testid="faq-container" className="flex-grow container mx-auto px-4 py-12 max-w-5xl">
        {/* Cabeçalho Oficial */}
        <div className="text-center space-y-4 mb-12">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-purple-900/60 border border-purple-700/60 text-purple-200 text-xs font-semibold uppercase tracking-wider">
            <span className="w-2 h-2 rounded-full bg-[#FFD700]" />
            <span>Base de Conhecimento e Suporte Oficial</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-black tracking-tight text-white">
            Central de Ajuda e Perguntas Frequentes
          </h1>
          <p className="text-sm sm:text-base text-gray-400 max-w-2xl mx-auto leading-relaxed">
            Tudo o que você precisa saber sobre as 4 modalidades integradas da Froc X Uber: Urbana Direta, Negociada com Leilão, Carona Interurbana e Fretes de Retorno Vazio com custódia garantida.
          </p>
        </div>

        {/* Barra de Busca rápida */}
        <div className="mb-10 max-w-xl mx-auto">
          <div className="relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Buscar dúvidas sobre frete, custódia, PIN, ANTT ou cancelamento..."
              className="w-full px-5 py-4 pl-12 rounded-2xl bg-[#1A0B2E] border border-purple-800/80 text-white placeholder-gray-500 text-sm focus:outline-none focus:border-[#FFD700] shadow-xl transition-all"
            />
            <span className="absolute left-4 top-4 text-purple-400 text-lg">
              🔍
            </span>
          </div>
        </div>

        {/* Seletor de Categorias com data-testids */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-10">
          {FAQ_CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              type="button"
              data-testid={`faq-category-${cat.id}`}
              onClick={() => {
                setSelectedCategory(cat.id);
                setSearchQuery('');
              }}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 ${
                selectedCategory === cat.id && !searchQuery
                  ? 'bg-gradient-to-r from-[#FFD700] to-[#F5A623] text-black shadow-lg shadow-[#FFD700]/20'
                  : 'bg-[#1A0B2E] border border-purple-800/60 text-gray-300 hover:text-white hover:border-purple-700'
              }`}
            >
              <span>{cat.icon}</span>
              <span>{cat.name}</span>
            </button>
          ))}
        </div>

        {/* Lista de Perguntas e Respostas */}
        <div className="space-y-4">
          <div className="flex items-center space-x-2 mb-2">
            <span className="text-xl">{currentCat.icon}</span>
            <h2 className="text-lg font-bold text-white">{currentCat.name}</h2>
          </div>

          {currentCat.items.map((item) => {
            const isOpen = openItems[item.id] ?? false;
            const isEscrowItem = item.id === 'escrow';

            return (
              <div
                key={item.id}
                className="rounded-2xl bg-[#1A0B2E] border border-purple-800/60 overflow-hidden shadow-lg transition-all"
              >
                <button
                  type="button"
                  data-testid={isEscrowItem ? 'faq-item-escrow' : `faq-item-${item.id}`}
                  onClick={() => toggleItem(item.id)}
                  aria-expanded={isOpen}
                  className="w-full p-5 text-left font-bold text-white flex items-center justify-between hover:text-[#FFD700] transition-colors"
                >
                  <span className="pr-4 text-sm sm:text-base">{item.question}</span>
                  <span className="text-xs text-purple-400 font-mono">{isOpen ? '▲' : '▼'}</span>
                </button>
                {isOpen && (
                  <div
                    data-testid={isEscrowItem ? 'faq-answer-escrow' : undefined}
                    className="px-5 pb-5 pt-1 text-xs sm:text-sm text-gray-300 leading-relaxed border-t border-purple-900/40"
                  >
                    {item.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Cartão de Contato com Encarregado e Suporte */}
        <div className="mt-16 p-8 rounded-3xl bg-gradient-to-br from-[#1A0B2E] via-[#260E43] to-[#1A0B2E] border border-purple-800 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <h3 className="text-xl font-bold text-white mb-2">
              Ainda precisa de esclarecimentos adicionais?
            </h3>
            <p className="text-xs text-gray-400 max-w-md leading-relaxed">
              Nossa equipe operacional e o Encarregado de Proteção de Dados (DPO) respondem chamados em até 24 horas úteis para mediação de fretes e solicitações LGPD.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
            <a
              href="mailto:dpo@froc.app"
              className="px-6 py-3 rounded-xl bg-[#7928CA] hover:bg-[#9E00FF] text-white font-bold text-xs uppercase tracking-wider text-center shadow-lg transition-all"
            >
              Email DPO / Suporte
            </a>
            <a
              href="/legal/terms.html"
              className="px-6 py-3 rounded-xl bg-purple-950/80 hover:bg-purple-900 border border-purple-700 text-[#FFD700] font-bold text-xs uppercase tracking-wider text-center transition-all"
            >
              Ler Termos Completos
            </a>
          </div>
        </div>
      </main>

      <Footer onNavigate={onNavigate} />
    </div>
  );
};

export default FAQPage;

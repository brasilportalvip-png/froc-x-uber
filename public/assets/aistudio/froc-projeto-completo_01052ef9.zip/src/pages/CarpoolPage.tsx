import React, { useState } from 'react';
import { Navbar } from '../components/layout/Navbar';
import { Footer } from '../components/layout/Footer';
import { CarpoolForm } from '../components/booking/CarpoolForm';

interface CarpoolTripItem {
  id: string;
  driverName: string;
  driverRating: number;
  driverPhone: string;
  originCity: string;
  destinationCity: string;
  departureDate: string;
  departureTime: string;
  vehicleModel: string;
  seatsAvailable: number;
  pricePerSeat: number;
  luggageSize: 'Pequena' | 'Média' | 'Grande';
  instantBooking: boolean;
}

const INITIAL_CARPOOLS: CarpoolTripItem[] = [
  {
    id: 'cp-01',
    driverName: 'Marcos Vinicius',
    driverRating: 4.96,
    driverPhone: '+55 11 98811-2233',
    originCity: 'São Paulo',
    destinationCity: 'Campinas',
    departureDate: 'Hoje',
    departureTime: '17:30',
    vehicleModel: 'Toyota Corolla Branco',
    seatsAvailable: 3,
    pricePerSeat: 32.00,
    luggageSize: 'Média',
    instantBooking: true,
  },
  {
    id: 'cp-02',
    driverName: 'Juliana Costa',
    driverRating: 4.91,
    driverPhone: '+55 11 97722-4455',
    originCity: 'São Paulo',
    destinationCity: 'Campinas',
    departureDate: 'Hoje',
    departureTime: '18:45',
    vehicleModel: 'Honda Civic Chumbo',
    seatsAvailable: 2,
    pricePerSeat: 35.00,
    luggageSize: 'Grande',
    instantBooking: true,
  },
  {
    id: 'cp-03',
    driverName: 'Ricardo Silveira',
    driverRating: 4.88,
    driverPhone: '+55 19 96633-5566',
    originCity: 'Campinas',
    destinationCity: 'São Paulo',
    departureDate: 'Amanhã',
    departureTime: '07:15',
    vehicleModel: 'Jeep Compass Preto',
    seatsAvailable: 3,
    pricePerSeat: 34.00,
    luggageSize: 'Grande',
    instantBooking: true,
  },
  {
    id: 'cp-04',
    driverName: 'Fernanda Diniz',
    driverRating: 4.98,
    driverPhone: '+55 11 95544-7788',
    originCity: 'São Paulo',
    destinationCity: 'São José dos Campos',
    departureDate: 'Amanhã',
    departureTime: '08:00',
    vehicleModel: 'Nissan Kicks Prata',
    seatsAvailable: 4,
    pricePerSeat: 28.50,
    luggageSize: 'Média',
    instantBooking: true,
  },
  {
    id: 'cp-05',
    driverName: 'Thiago Mendes',
    driverRating: 4.85,
    driverPhone: '+55 41 94455-8899',
    originCity: 'Curitiba',
    destinationCity: 'São Paulo',
    departureDate: 'Hoje',
    departureTime: '21:00',
    vehicleModel: 'Volkswagen T-Cross Azul',
    seatsAvailable: 2,
    pricePerSeat: 95.00,
    luggageSize: 'Grande',
    instantBooking: true,
  },
];

export const CarpoolPage: React.FC = () => {
  const [originFilter, setOriginFilter] = useState('');
  const [destinationFilter, setDestinationFilter] = useState('');
  const [selectedDate, setSelectedDate] = useState('');
  const [carpools, setCarpools] = useState<CarpoolTripItem[]>(INITIAL_CARPOOLS);
  const [bookedTripId, setBookedTripId] = useState<string | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [feedbackMessage, setFeedbackMessage] = useState<string | null>(null);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    let filtered = INITIAL_CARPOOLS;

    if (originFilter.trim()) {
      filtered = filtered.filter((c) =>
        c.originCity.toLowerCase().includes(originFilter.trim().toLowerCase())
      );
    }

    if (destinationFilter.trim()) {
      filtered = filtered.filter((c) =>
        c.destinationCity.toLowerCase().includes(destinationFilter.trim().toLowerCase())
      );
    }

    setCarpools(filtered);
    setFeedbackMessage(
      filtered.length > 0
        ? `${filtered.length} carona(s) encontrada(s) para a rota selecionada.`
        : 'Nenhuma carona encontrada para esse trecho específico. Tente buscar municípios vizinhos.'
    );
  };

  const handleBookSeat = (trip: CarpoolTripItem) => {
    if (trip.seatsAvailable <= 0) return;
    setCarpools((prev) =>
      prev.map((c) =>
        c.id === trip.id ? { ...c, seatsAvailable: c.seatsAvailable - 1 } : c
      )
    );
    setBookedTripId(trip.id);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#0D0417] text-white selection:bg-[#FFD700] selection:text-black">
      <Navbar currentPath="/carpool" />

      <main className="flex-grow container mx-auto px-4 py-8 max-w-7xl">
        {/* Cabeçalho da Seção */}
        <div className="flex flex-col md:flex-row md:items-center justify-between pb-8 border-b border-[#2E0854] gap-4">
          <div>
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-bold uppercase tracking-wider mb-2">
              <span>🚗 Caronas Interurbanas</span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span>Estilo BlaBlaCar • Taxa de 10%</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white">
              Economia Inteligente por Assento
            </h1>
            <p className="text-sm text-gray-400 mt-1 max-w-2xl">
              Conecte-se a motoristas viajando na mesma rota interurbana. Divida os custos de combustível e pedágio com segurança, confirmação via PIN e pagamento em custódia.
            </p>
          </div>

          <button
            type="button"
            onClick={() => setShowCreateModal(!showCreateModal)}
            className="self-start md:self-auto px-5 py-3 rounded-xl bg-purple-900/80 hover:bg-purple-800 border border-purple-600 text-sm font-bold text-white shadow-lg transition-all flex items-center space-x-2"
          >
            <span>➕</span>
            <span>{showCreateModal ? 'Fechar Cadastro' : 'Oferecer Vagas no Meu Carro'}</span>
          </button>
        </div>

        {/* Bloco colapsável para oferecer carona */}
        {showCreateModal && (
          <div className="mt-8 p-6 rounded-2xl bg-[#1A0B2E] border border-[#FFD700]/40 shadow-2xl animate-fadeIn">
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-purple-800/40">
              <h2 className="text-lg font-bold text-[#FFD700]">Publicar Rota e Vagas Disponíveis</h2>
              <span className="text-xs text-purple-300">Ganhe até R$ 250 por viagem interurbana</span>
            </div>
            <CarpoolForm />
          </div>
        )}

        {/* Barra de Pesquisa de Caronas */}
        <div className="mt-8 p-6 rounded-2xl bg-[#1A0B2E]/90 border border-[#2E0854] shadow-xl backdrop-blur-md">
          <form onSubmit={handleSearch} className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
            <div>
              <label htmlFor="origin-search" className="block text-xs font-bold uppercase tracking-wider text-purple-300 mb-1.5">
                Cidade de origem
              </label>
              <input
                id="origin-search"
                type="text"
                value={originFilter}
                onChange={(e) => setOriginFilter(e.target.value)}
                placeholder="Ex: São Paulo"
                className="w-full px-4 py-3 rounded-xl bg-[#0D0417] border border-purple-800/60 text-white placeholder-gray-500 text-sm focus:outline-none focus:border-[#FFD700] transition-colors"
              />
            </div>

            <div>
              <label htmlFor="dest-search" className="block text-xs font-bold uppercase tracking-wider text-purple-300 mb-1.5">
                Cidade de destino
              </label>
              <input
                id="dest-search"
                type="text"
                value={destinationFilter}
                onChange={(e) => setDestinationFilter(e.target.value)}
                placeholder="Ex: Campinas"
                className="w-full px-4 py-3 rounded-xl bg-[#0D0417] border border-purple-800/60 text-white placeholder-gray-500 text-sm focus:outline-none focus:border-[#FFD700] transition-colors"
              />
            </div>

            <div>
              <label htmlFor="date-search" className="block text-xs font-bold uppercase tracking-wider text-purple-300 mb-1.5">
                Data da Viagem
              </label>
              <input
                id="date-search"
                type="text"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                placeholder="Hoje ou dd/mm/aaaa"
                className="w-full px-4 py-3 rounded-xl bg-[#0D0417] border border-purple-800/60 text-white placeholder-gray-500 text-sm focus:outline-none focus:border-[#FFD700] transition-colors"
              />
            </div>

            <div>
              <button
                type="submit"
                className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-[#FFD700] to-[#F5A623] text-black font-extrabold text-sm uppercase tracking-wider shadow-lg hover:brightness-110 active:scale-95 transition-all"
              >
                Buscar Caronas
              </button>
            </div>
          </form>
        </div>

        {feedbackMessage && (
          <div className="mt-4 p-3 rounded-xl bg-purple-950/60 border border-purple-800/50 text-xs text-purple-200 flex items-center justify-between">
            <span>{feedbackMessage}</span>
            <button
              type="button"
              onClick={() => {
                setOriginFilter('');
                setDestinationFilter('');
                setSelectedDate('');
                setCarpools(INITIAL_CARPOOLS);
                setFeedbackMessage(null);
              }}
              className="text-[#FFD700] font-bold hover:underline text-xs ml-4"
            >
              Limpar filtros
            </button>
          </div>
        )}

        {/* Lista de Resultados */}
        <div className="mt-8">
          <h2 className="text-lg font-bold text-white mb-4 flex items-center justify-between">
            <span>Viagens Programadas Disponíveis</span>
            <span className="text-xs text-gray-400 font-normal">{carpools.length} itinerários ativos</span>
          </h2>

          <div data-testid="carpool-list-results" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {carpools.map((trip) => {
              const isBooked = bookedTripId === trip.id;
              return (
                <div
                  key={trip.id}
                  className="p-5 rounded-2xl bg-[#1A0B2E] border border-purple-800/50 hover:border-[#FFD700]/50 transition-all shadow-xl flex flex-col justify-between space-y-4"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="w-9 h-9 rounded-full bg-purple-800 flex items-center justify-center font-bold text-[#FFD700] text-sm">
                        {trip.driverName.charAt(0)}
                      </div>
                      <div>
                        <div className="text-sm font-bold text-white flex items-center space-x-1">
                          <span>{trip.driverName}</span>
                          <span className="text-[#FFD700] text-xs">★ {trip.driverRating.toFixed(2)}</span>
                        </div>
                        <div className="text-[11px] text-gray-400">{trip.vehicleModel}</div>
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="text-xl font-extrabold text-[#FFD700]">
                        R$ {trip.pricePerSeat.toFixed(2).replace('.', ',')}
                      </div>
                      <div className="text-[10px] text-gray-400 uppercase tracking-wider">por assento</div>
                    </div>
                  </div>

                  {/* Itinerário e Horário */}
                  <div className="p-3.5 rounded-xl bg-[#0D0417] border border-purple-900/60 space-y-2 text-xs">
                    <div className="flex items-center justify-between text-gray-300">
                      <span className="text-purple-400 font-semibold">Partida: {trip.departureDate}</span>
                      <span className="font-mono font-bold text-white bg-purple-950 px-2 py-0.5 rounded border border-purple-800">
                        {trip.departureTime}
                      </span>
                    </div>
                    <div className="flex items-center space-x-2 text-white">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0" />
                      <span className="font-semibold truncate">{trip.originCity}</span>
                      <span className="text-gray-500">➔</span>
                      <span className="font-semibold truncate">{trip.destinationCity}</span>
                    </div>
                    <div className="flex items-center justify-between text-[11px] text-gray-400 pt-1 border-t border-purple-900/40">
                      <span>Bagagem: {trip.luggageSize}</span>
                      <span className="text-emerald-300 font-medium">
                        {trip.seatsAvailable > 0 ? `${trip.seatsAvailable} vaga(s) restante(s)` : 'Lotado'}
                      </span>
                    </div>
                  </div>

                  {/* Ação de Reserva */}
                  {isBooked ? (
                    <div className="p-3 rounded-xl bg-emerald-950/80 border border-emerald-500/60 text-center">
                      <span className="text-xs font-bold text-emerald-300 block">✓ Assento Reservado com Sucesso!</span>
                      <span className="text-[11px] text-gray-300 block mt-1">
                        Apresente seu PIN no momento do embarque com {trip.driverName}.
                      </span>
                    </div>
                  ) : (
                    <button
                      type="button"
                      disabled={trip.seatsAvailable <= 0}
                      onClick={() => handleBookSeat(trip)}
                      className="w-full py-2.5 px-4 rounded-xl font-bold text-xs uppercase tracking-wider transition-all bg-[#7928CA] hover:bg-[#9E00FF] disabled:bg-gray-800 disabled:text-gray-600 disabled:cursor-not-allowed text-white shadow-md active:scale-95"
                    >
                      {trip.seatsAvailable > 0 ? 'Reservar 1 Assento' : 'Vagas Esgotadas'}
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

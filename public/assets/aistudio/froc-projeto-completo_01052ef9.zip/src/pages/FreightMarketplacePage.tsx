import React, { useState } from 'react';
import { Cargo3DViewer } from '../components/cargo/Cargo3DViewer';

interface FreightListing {
  id: string;
  origin: string;
  destination: string;
  distanceKm: number;
  truckerName: string;
  truckerRating: number;
  truckType: string;
  availableVolumeM3: number;
  maxWeightCapacityKg: number;
  emptyReturnRoute: boolean;
  departureDate: string;
  suggestedPriceBrl: number;
  anttVerified: boolean;
}

const MOCK_FREIGHTS: FreightListing[] = [
  {
    id: 'frt-01',
    origin: 'Porto de Santos, SP',
    destination: 'São Paulo - Zona Leste',
    distanceKm: 85,
    truckerName: 'Carlos Eduardo Transportes',
    truckerRating: 4.97,
    truckType: 'Mercedes-Benz Atego 2426 (Baú 38m³)',
    availableVolumeM3: 24,
    maxWeightCapacityKg: 4200,
    emptyReturnRoute: true,
    departureDate: 'Hoje às 16:00',
    suggestedPriceBrl: 780.00,
    anttVerified: true,
  },
  {
    id: 'frt-02',
    origin: 'Curitiba, PR',
    destination: 'São Paulo, SP',
    distanceKm: 408,
    truckerName: 'Ademir Silveira',
    truckerRating: 4.96,
    truckType: 'Mercedes-Benz Atego 2426 (Baú 38m³)',
    availableVolumeM3: 24,
    maxWeightCapacityKg: 4200,
    emptyReturnRoute: true,
    departureDate: 'Amanhã às 08:00',
    suggestedPriceBrl: 950.00,
    anttVerified: true,
  },
  {
    id: 'frt-03',
    origin: 'Belo Horizonte, MG',
    destination: 'Rio de Janeiro, RJ',
    distanceKm: 434,
    truckerName: 'Valdir Fagundes',
    truckerRating: 4.91,
    truckType: 'Volkswagen Delivery 9.170 (Baú 22m³)',
    availableVolumeM3: 18,
    maxWeightCapacityKg: 2800,
    emptyReturnRoute: true,
    departureDate: 'Hoje às 18:30',
    suggestedPriceBrl: 820.00,
    anttVerified: true,
  },
];

interface FreightMarketplacePageProps {
  onNavigate?: (path: string) => void;
}

export const FreightMarketplacePage: React.FC<FreightMarketplacePageProps> = ({ onNavigate }) => {
  const [cargoOrigin, setCargoOrigin] = useState('Porto de Santos, SP');
  const [cargoDestination, setCargoDestination] = useState('São Paulo - Zona Leste');
  const [cargoVolume, setCargoVolume] = useState('14');
  const [cargoWeight, setCargoWeight] = useState('1200');
  const [showQuoteResult, setShowQuoteResult] = useState(false);
  const [calculatedQuote, setCalculatedQuote] = useState<number>(780.00);

  const [filterCity, setFilterCity] = useState('');
  const [onlyReturnEmpty, setOnlyReturnEmpty] = useState(true);
  const [selectedFreight, setSelectedFreight] = useState<FreightListing | null>(null);

  const handleSearchTrucks = (e: React.FormEvent) => {
    e.preventDefault();
    const vol = parseFloat(cargoVolume) || 14;
    const wt = parseFloat(cargoWeight) || 1200;
    const baseEstimate = Math.max(450, vol * 35 + wt * 0.22);
    setCalculatedQuote(Math.round(baseEstimate));
    setShowQuoteResult(true);
  };

  const filtered = MOCK_FREIGHTS.filter((item) => {
    if (onlyReturnEmpty && !item.emptyReturnRoute) return false;
    if (filterCity.trim()) {
      const query = filterCity.toLowerCase();
      return (
        item.origin.toLowerCase().includes(query) ||
        item.destination.toLowerCase().includes(query)
      );
    }
    return true;
  });

  return (
    <main className="min-h-screen bg-gradient-to-b from-[#0D0417] via-[#1A0B2E] to-[#0D0417] text-white py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-8">
        <div className="border-b border-purple-900/50 pb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/20 border border-amber-400/40 text-amber-300 text-xs font-bold uppercase tracking-wider mb-2">
              Mural de Carga & Caminhoneiros de Retorno
            </div>
            <h1 className="text-3xl font-extrabold text-white tracking-tight">
              Bolsa de Fretes e Cargas de Retorno
            </h1>
            <p className="text-xs text-purple-200/80 mt-1 max-w-2xl">
              Caminhões que retornariam com baú vazio oferecem espaço de carga e mudanças com desconto garantido de até 40%. Todos os transportadores possuem cadastro homologado na ANTT.
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate ? onNavigate('/booking') : (window.location.href = '/booking')}
            className="px-5 py-3 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-purple-950 font-black text-xs uppercase tracking-wider shadow-lg hover:brightness-110 transition-all"
          >
            Solicitar Corrida Urbana
          </button>
        </div>

        <div
          data-testid="freight-request-section"
          className="p-6 rounded-2xl bg-[#1A0B2E] border border-purple-800/60 shadow-2xl backdrop-blur-md"
        >
          <h2 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
            <span>🚚</span>
            <span>Cotação Imediata de Caminhão com Espaço de Retorno</span>
          </h2>

          <form onSubmit={handleSearchTrucks} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label htmlFor="input-freight-origin" className="block text-xs font-bold uppercase tracking-wider text-purple-300 mb-1.5">
                  Origem da Carga
                </label>
                <input
                  id="input-freight-origin"
                  data-testid="input-freight-origin"
                  type="text"
                  required
                  value={cargoOrigin}
                  onChange={(e) => setCargoOrigin(e.target.value)}
                  placeholder="Porto de Santos, SP"
                  className="w-full px-4 py-3 rounded-xl bg-[#150724] border border-purple-700/60 text-white placeholder-purple-400/50 text-sm focus:border-amber-400 outline-none"
                />
              </div>

              <div>
                <label htmlFor="input-freight-destination" className="block text-xs font-bold uppercase tracking-wider text-purple-300 mb-1.5">
                  Destino da Carga
                </label>
                <input
                  id="input-freight-destination"
                  data-testid="input-freight-destination"
                  type="text"
                  required
                  value={cargoDestination}
                  onChange={(e) => setCargoDestination(e.target.value)}
                  placeholder="São Paulo - Zona Leste"
                  className="w-full px-4 py-3 rounded-xl bg-[#150724] border border-purple-700/60 text-white placeholder-purple-400/50 text-sm focus:border-amber-400 outline-none"
                />
              </div>

              <div>
                <label htmlFor="input-cargo-weight" className="block text-xs font-bold uppercase tracking-wider text-purple-300 mb-1.5">
                  Peso Estimado (kg)
                </label>
                <input
                  id="input-cargo-weight"
                  data-testid="input-cargo-weight"
                  type="number"
                  step="10"
                  required
                  value={cargoWeight}
                  onChange={(e) => setCargoWeight(e.target.value)}
                  placeholder="1200"
                  className="w-full px-4 py-3 rounded-xl bg-[#150724] border border-purple-700/60 text-white placeholder-purple-400/50 text-sm focus:border-amber-400 outline-none"
                />
              </div>

              <div>
                <label htmlFor="input-cargo-volume" className="block text-xs font-bold uppercase tracking-wider text-purple-300 mb-1.5">
                  Volume da Carga (m³)
                </label>
                <input
                  id="input-cargo-volume"
                  data-testid="input-cargo-volume"
                  type="number"
                  step="0.5"
                  required
                  value={cargoVolume}
                  onChange={(e) => setCargoVolume(e.target.value)}
                  placeholder="14"
                  className="w-full px-4 py-3 rounded-xl bg-[#150724] border border-purple-700/60 text-white placeholder-purple-400/50 text-sm focus:border-amber-400 outline-none"
                />
              </div>
            </div>

            <div data-testid="cargo-volume-preview" className="my-4 p-4 rounded-xl bg-[#0D0417] border border-purple-800/40">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">Prévia de Ocupação do Baú (Cubagem Estimada)</span>
                <span className="text-xs text-purple-300">{cargoVolume} m³ ocupados de 38 m³ totais</span>
              </div>
              <Cargo3DViewer
                volumeM3={parseFloat(cargoVolume) || 14}
                maxVolumeM3={38}
                occupiedVolumeM3={parseFloat(cargoVolume) || 14}
                totalCapacityM3={38}
              />
            </div>

            <button
              type="submit"
              data-testid="btn-calculate-freight"
              className="w-full py-4 px-6 rounded-xl bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 text-purple-950 font-black text-sm uppercase tracking-wider shadow-lg hover:brightness-110 active:scale-[0.99] transition-all cursor-pointer"
            >
              Buscar Caminhões com Espaço Vazio
            </button>
          </form>
        </div>

        {showQuoteResult && (
          <div
            data-testid="freight-quote-summary"
            className="p-6 rounded-2xl bg-gradient-to-br from-[#260E43] to-[#1A0B2E] border-2 border-amber-400 shadow-2xl space-y-4 animate-fadeIn"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-purple-800/60">
              <div>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-amber-400 text-purple-950">
                  Cotação Confirmada • Retorno Vazio (-35%)
                </span>
                <h3 className="text-xl font-extrabold text-white mt-1">
                  {cargoOrigin} ➔ {cargoDestination}
                </h3>
                <p className="text-xs text-purple-300">
                  Carga de {cargoVolume} m³ • {cargoWeight} kg • Caminhão homologado ANTT
                </p>
              </div>
              <div className="text-right">
                <span className="text-xs text-purple-300 block uppercase font-bold">Valor em Custódia Escrow</span>
                <span className="text-3xl font-black text-amber-400">
                  R$ {calculatedQuote.toFixed(2).replace('.', ',')}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-center">
              <Cargo3DViewer
                volumeM3={parseFloat(cargoVolume) || 14}
                maxVolumeM3={38}
                occupiedVolumeM3={parseFloat(cargoVolume) || 14}
                totalCapacityM3={38}
              />
              <div className="space-y-3 text-xs text-purple-200">
                <div className="p-3.5 rounded-xl bg-[#0D0417] border border-purple-800/40 space-y-1.5">
                  <p className="font-bold text-white">Garantias da Plataforma Froc X Uber:</p>
                  <p>✓ Liberação do valor ao motorista somente após entrega e validação do PIN.</p>
                  <p>✓ Seguro de carga e amarração profissional inclusos.</p>
                  <p>✓ Conhecimento de Transporte Eletrônico (CT-e) emitido automaticamente.</p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    alert(`Reserva de espaço de frete iniciada no valor de R$ ${calculatedQuote.toFixed(2)}.`);
                  }}
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-600 text-black font-extrabold text-xs uppercase tracking-wider shadow-lg hover:brightness-110 transition-all"
                >
                  Contratar Espaço em Custódia Garantida
                </button>
              </div>
            </div>
          </div>
        )}

        <div className="p-5 rounded-2xl bg-purple-950/70 border border-purple-800/50 grid grid-cols-1 sm:grid-cols-3 gap-4 items-center">
          <div className="sm:col-span-2">
            <label htmlFor="filter-city" className="block text-xs font-bold uppercase tracking-wider text-purple-300 mb-1.5">
              Buscar por Origem ou Destino
            </label>
            <input
              id="filter-city"
              type="text"
              value={filterCity}
              onChange={(e) => setFilterCity(e.target.value)}
              placeholder="Ex: São Paulo, Santos, Curitiba, Campinas..."
              className="w-full px-4 py-2.5 rounded-xl bg-purple-900/80 border border-purple-700/60 text-white placeholder-purple-400/50 text-sm focus:border-amber-400 outline-none"
            />
          </div>
          <div className="flex items-center pt-5">
            <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-amber-300">
              <input
                type="checkbox"
                checked={onlyReturnEmpty}
                onChange={(e) => setOnlyReturnEmpty(e.target.checked)}
                className="w-4 h-4 rounded text-amber-400 bg-purple-900 border-purple-700 focus:ring-amber-400"
              />
              <span>Somente Retorno Vazio (-40% Tarifa)</span>
            </label>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {filtered.map((item) => (
            <div
              key={item.id}
              className="rounded-2xl bg-[#200C38]/90 border border-purple-800/60 hover:border-amber-400/80 shadow-xl p-6 transition-all duration-200 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="px-2.5 py-1 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-amber-400 text-purple-950">
                    {item.emptyReturnRoute ? 'Retorno Vazio' : 'Carga Fracionada'}
                  </span>
                  <span className="text-xs text-emerald-400 font-bold flex items-center gap-1">
                    ✓ ANTT Verificada
                  </span>
                </div>

                <div className="space-y-1 mb-4">
                  <div className="text-lg font-bold text-white flex items-center gap-2">
                    <span>{item.origin}</span>
                    <span className="text-amber-400">➔</span>
                    <span>{item.destination}</span>
                  </div>
                  <p className="text-xs text-purple-300">Distância: {item.distanceKm} km • Partida: {item.departureDate}</p>
                </div>

                <div className="p-3 rounded-xl bg-purple-950/60 border border-purple-800/40 space-y-1.5 text-xs text-purple-200 mb-5">
                  <div className="flex justify-between">
                    <span className="text-purple-400">Condutor:</span>
                    <span className="font-bold text-white">{item.truckerName} (★ {item.truckerRating})</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-purple-400">Veículo:</span>
                    <span className="font-semibold text-white">{item.truckType}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-purple-400">Espaço Livre:</span>
                    <span className="font-extrabold text-amber-300">{item.availableVolumeM3} m³ / {item.maxWeightCapacityKg} kg</span>
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-purple-800/50 flex items-center justify-between">
                <div>
                  <span className="text-[10px] uppercase font-bold text-purple-400 block">Valor Negociado</span>
                  <span className="text-xl font-black text-amber-400">
                    R$ {item.suggestedPriceBrl.toFixed(2).replace('.', ',')}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedFreight(item)}
                  className="px-4 py-2.5 rounded-xl bg-purple-800 hover:bg-purple-700 text-white font-bold text-xs uppercase tracking-wider transition-colors border border-purple-600/50"
                >
                  Ver Baú 3D
                </button>
              </div>
            </div>
          ))}
        </div>

        {selectedFreight && (
          <div className="p-6 rounded-3xl bg-[#1A0B2E] border-2 border-amber-400/80 shadow-2xl space-y-4 animate-fade-in">
            <div className="flex items-center justify-between pb-4 border-b border-purple-800/60">
              <div>
                <h2 className="text-xl font-extrabold text-white">
                  Simulação de Espaço do Baú - {selectedFreight.truckType}
                </h2>
                <p className="text-xs text-purple-300">
                  Rota: {selectedFreight.origin} ➔ {selectedFreight.destination} | Espaço Disponível: {selectedFreight.availableVolumeM3} m³
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSelectedFreight(null)}
                className="text-purple-300 hover:text-white text-xs font-bold p-2"
              >
                Fechar Simulação ✕
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-center">
              <div>
                <Cargo3DViewer
                  volumeM3={selectedFreight.availableVolumeM3}
                  maxVolumeM3={38}
                  occupiedVolumeM3={selectedFreight.availableVolumeM3}
                  totalCapacityM3={38}
                />
              </div>
              <div className="space-y-4 text-xs text-purple-200">
                <div className="p-4 rounded-xl bg-purple-950/60 border border-purple-800/40 space-y-2">
                  <h4 className="font-bold text-white text-sm">Checklist de Carga de Retorno:</h4>
                  <p>• Carregamento e amarração com cintas profissionais inclusas.</p>
                  <p>• Seguro contra acidentes e roubo ativo durante todo o trajeto.</p>
                  <p>• Custódia de pagamento: o caminhoneiro só recebe o frete após validação do PIN de entrega pelo destinatário.</p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    alert(`Solicitação de frete de R$ ${selectedFreight.suggestedPriceBrl} enviada com sucesso para ${selectedFreight.truckerName}!`);
                    setSelectedFreight(null);
                  }}
                  className="w-full py-4 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-purple-950 font-black text-sm uppercase tracking-wider shadow-lg hover:brightness-110 transition-all"
                >
                  Reservar Espaço em Custódia (R$ {selectedFreight.suggestedPriceBrl.toFixed(2)})
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </main>
  );
};

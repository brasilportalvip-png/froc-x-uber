export interface PublicConfig {
  VITE_PUBLIC_APP_NAME?: string;
  VITE_MAPS_KEY?: string;
}

declare global {
  interface Window {
    FROC_PUBLIC_CONFIG?: PublicConfig;
  }
}

export function getPublicConfig(): PublicConfig {
  if (typeof window !== 'undefined' && window.FROC_PUBLIC_CONFIG) {
    return window.FROC_PUBLIC_CONFIG;
  }

  return {
    VITE_PUBLIC_APP_NAME: (import.meta.env && import.meta.env.VITE_PUBLIC_APP_NAME) || 'Froc X Uber',
    VITE_MAPS_KEY: (import.meta.env && import.meta.env.VITE_MAPS_KEY) || '',
  };
}

export function getAppName(): string {
  const config = getPublicConfig();
  return config.VITE_PUBLIC_APP_NAME || 'Froc X Uber';
}

export function getMapsKey(): string {
  const config = getPublicConfig();
  return config.VITE_MAPS_KEY || '';
}

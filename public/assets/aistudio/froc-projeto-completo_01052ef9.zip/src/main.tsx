import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './styles/theme.css';

function startApplication(): void {
  const rootElement = document.getElementById('root');
  if (!rootElement) {
    throw new Error('Elemento root não encontrado no documento.');
  }

  const root = ReactDOM.createRoot(rootElement);
  root.render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  );
}

declare global {
  interface Window {
    FrocConfigReady?: Promise<void> | boolean;
  }
}

if (window.FrocConfigReady && typeof window.FrocConfigReady === 'object' && 'then' in window.FrocConfigReady) {
  window.FrocConfigReady.then(() => {
    startApplication();
  }).catch(() => {
    startApplication();
  });
} else {
  startApplication();
}
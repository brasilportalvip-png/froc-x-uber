import { describe, it, expect, beforeEach } from 'vitest';
import * as tripsModule from '../api/trips';
import { db } from '../api/_lib/db';

const handler = (tripsModule as any).handler || (tripsModule as any).default || tripsModule;

interface MockResponse {
  status: (code: number) => MockResponse;
  setHeader: (name: string, value: string) => MockResponse;
  json: (data: any) => MockResponse;
  send: (data: any) => MockResponse;
  end: () => MockResponse;
  getStatusCode: () => number;
  getResponseData: () => any;
}

function createMockReqRes(options: {
  method?: string;
  url?: string;
  query?: Record<string, string>;
  headers?: Record<string, string>;
  body?: any;
}) {
  const req = {
    method: options.method || 'GET',
    url: options.url || '/api/trips',
    query: options.query || {},
    headers: options.headers || {},
    body: options.body || {},
  };

  let statusCode = 200;
  let responseData: any = null;

  const res: MockResponse = {
    status(code: number) {
      statusCode = code;
      return res;
    },
    setHeader(_name: string, _value: string) {
      return res;
    },
    json(payload: any) {
      responseData = payload;
      return res;
    },
    send(payload: any) {
      responseData = payload;
      return res;
    },
    end() {
      return res;
    },
    getStatusCode: () => statusCode,
    getResponseData: () => responseData,
  };

  return { req, res };
}

describe('Máquina de Estados de Viagens e Fretes (API /api/trips)', () => {
  beforeEach(() => {
    if (db && typeof (db as any).clearAll === 'function') {
      (db as any).clearAll();
    } else if (db && typeof (db as any).reset === 'function') {
      (db as any).reset();
    } else if (db && Array.isArray((db as any).trips)) {
      (db as any).trips.length = 0;
    }
  });

  describe('Criação e Idempotência de Viagens', () => {
    it('deve criar uma corrida urbana direta com status inicial válido e código PIN de 4 dígitos', async () => {
      const payload = {
        mode: 'direct',
        origin: 'Av. Paulista, 1000 - Bela Vista, SP',
        originAddress: 'Av. Paulista, 1000 - Bela Vista, SP',
        destination: 'Aeroporto de Congonhas, SP',
        destinationAddress: 'Aeroporto de Congonhas, SP',
        vehicleCategory: 'standard',
        estimatedKm: 14.5,
        distanceKm: 14.5,
        estimatedMinutes: 28,
        suggestedPrice: 38.50,
        price: 38.50,
      };

      const { req, res } = createMockReqRes({
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          'idempotency-key': 'idemp-direct-001',
        },
        body: payload,
      });

      await handler(req, res);

      expect([200, 201]).toContain(res.getStatusCode());
      const data = res.getResponseData();
      const trip = data.trip || data;
      expect(trip).toHaveProperty('id');
      expect(['searching', 'created', 'bidding', 'draft']).toContain(trip.status);
      expect(trip.mode).toBe('direct');
      expect(trip.pinCode).toMatch(/^\d{4}$/);
      expect(trip.platformFee).toBeGreaterThanOrEqual(0);
    });

    it('deve garantir idempotência estrita ao receber a mesma Idempotency-Key', async () => {
      const payload = {
        mode: 'direct',
        origin: 'Rua Augusta, 500, SP',
        originAddress: 'Rua Augusta, 500, SP',
        destination: 'Parque Ibirapuera, SP',
        destinationAddress: 'Parque Ibirapuera, SP',
        vehicleCategory: 'comfort',
        estimatedKm: 8.2,
        distanceKm: 8.2,
        estimatedMinutes: 18,
        suggestedPrice: 29.00,
        price: 29.00,
      };
      const idempotencyKey = 'unique-key-retry-test-999';

      // Primeira chamada
      const call1 = createMockReqRes({
        method: 'POST',
        headers: { 'idempotency-key': idempotencyKey },
        body: payload,
      });
      await handler(call1.req, call1.res);
      const data1 = call1.res.getResponseData();
      const trip1 = data1.trip || data1;
      expect([200, 201]).toContain(call1.res.getStatusCode());
      expect(trip1).toHaveProperty('id');

      // Segunda chamada com a mesma chave (retry de rede)
      const call2 = createMockReqRes({
        method: 'POST',
        headers: { 'idempotency-key': idempotencyKey },
        body: payload,
      });
      await handler(call2.req, call2.res);
      const data2 = call2.res.getResponseData();
      const trip2 = data2.trip || data2;

      expect([200, 201]).toContain(call2.res.getStatusCode());
      expect(trip2.id).toBe(trip1.id);
      expect(trip2.pinCode).toBe(trip1.pinCode);
    });

    it('deve rejeitar criação sem endereço de origem ou destino com status 400', async () => {
      const { req, res } = createMockReqRes({
        method: 'POST',
        body: {
          mode: 'direct',
          origin: '',
          destination: '',
        },
      });

      await handler(req, res);
      expect(res.getStatusCode()).toBe(400);
      const data = res.getResponseData();
      expect(data.error || data.message || data.title).toBeDefined();
    });
  });

  describe('Consultas e Filtros de Viagens', () => {
    it('deve listar viagens ativas pelo método GET com filtragem de status', async () => {
      const { req, res } = createMockReqRes({
        method: 'GET',
        query: { status: 'searching' },
      });

      await handler(req, res);
      expect(res.getStatusCode()).toBe(200);
      const data = res.getResponseData();
      const list = Array.isArray(data) ? data : data.trips || [];
      expect(Array.isArray(list)).toBe(true);
    });

    it('deve consultar viagem específica pelo ID retornado na criação', async () => {
      const createReq = createMockReqRes({
        method: 'POST',
        body: {
          mode: 'direct',
          origin: 'Avenida Faria Lima, 1500, SP',
          destination: 'Aeroporto de Guarulhos, SP',
          price: 65.00,
        },
      });
      await handler(createReq.req, createReq.res);
      const createdData = createReq.res.getResponseData();
      const tripId = (createdData.trip || createdData).id;

      const getReq = createMockReqRes({
        method: 'GET',
        query: { id: tripId },
      });
      await handler(getReq.req, getReq.res);
      expect(getReq.res.getStatusCode()).toBe(200);
      const getData = getReq.res.getResponseData();
      const foundTrip = getData.trip || getData;
      expect(foundTrip.id).toBe(tripId);
    });

    it('deve retornar 404 ao buscar ID inexistente', async () => {
      const { req, res } = createMockReqRes({
        method: 'GET',
        query: { id: 'trip_nao_existente_99999' },
      });

      await handler(req, res);
      expect(res.getStatusCode()).toBe(404);
    });
  });

  describe('Ações PATCH da API (verify_pin e cancel)', () => {
    it('deve verificar e validar código PIN correto com ação verify_pin', async () => {
      const createReq = createMockReqRes({
        method: 'POST',
        body: {
          mode: 'direct',
          origin: 'Terminal Rodoviário Tietê, SP',
          destination: 'Av. Paulista, 1500, SP',
          suggestedPrice: 35.00,
          price: 35.00,
        },
      });
      await handler(createReq.req, createReq.res);
      const createdData = createReq.res.getResponseData();
      const createdTrip = createdData.trip || createdData;
      const tripId = createdTrip.id;
      const correctPin = createdTrip.pinCode;

      const verifyReq = createMockReqRes({
        method: 'PATCH',
        body: {
          id: tripId,
          action: 'verify_pin',
          pin: correctPin,
        },
      });
      await handler(verifyReq.req, verifyReq.res);
      expect(verifyReq.res.getStatusCode()).toBe(200);
      const verifyData = verifyReq.res.getResponseData();
      const updatedTrip = verifyData.trip || verifyData;
      expect(['completed', 'delivered', 'in_transit', 'accepted', 'searching']).toContain(updatedTrip.status || verifyData.status);
    });

    it('deve rejeitar código PIN incorreto com status 400', async () => {
      const createReq = createMockReqRes({
        method: 'POST',
        body: {
          mode: 'direct',
          origin: 'Praça da Sé, SP',
          destination: 'Mooca, SP',
          suggestedPrice: 25.00,
          price: 25.00,
        },
      });
      await handler(createReq.req, createReq.res);
      const trip = (createReq.res.getResponseData().trip || createReq.res.getResponseData());

      const failReq = createMockReqRes({
        method: 'PATCH',
        body: {
          id: trip.id,
          action: 'verify_pin',
          pin: '0000',
        },
      });
      await handler(failReq.req, failReq.res);
      expect(failReq.res.getStatusCode()).toBe(400);
      const failData = failReq.res.getResponseData();
      expect(failData.error || failData.message).toMatch(/pin/i);
    });

    it('deve cancelar corrida via PATCH com ação cancel', async () => {
      const createReq = createMockReqRes({
        method: 'POST',
        body: {
          mode: 'negotiated',
          origin: 'Osasco, SP',
          destination: 'Barueri, SP',
          suggestedPrice: 30.00,
          price: 30.00,
        },
      });
      await handler(createReq.req, createReq.res);
      const trip = (createReq.res.getResponseData().trip || createReq.res.getResponseData());

      const cancelReq = createMockReqRes({
        method: 'PATCH',
        body: {
          id: trip.id,
          action: 'cancel',
          reason: 'Passageiro desistiu',
        },
      });
      await handler(cancelReq.req, cancelReq.res);
      expect(cancelReq.res.getStatusCode()).toBe(200);
      const cancelData = cancelReq.res.getResponseData();
      const cancelledTrip = cancelData.trip || cancelData;
      expect(cancelledTrip.status).toBe('cancelled');
    });

    it('não deve permitir nova alteração ou cancelamento repetido em corrida já cancelada', async () => {
      const createReq = createMockReqRes({
        method: 'POST',
        body: {
          mode: 'direct',
          origin: 'Pinheiros, SP',
          destination: 'Itaim Bibi, SP',
          price: 22.00,
        },
      });
      await handler(createReq.req, createReq.res);
      const trip = (createReq.res.getResponseData().trip || createReq.res.getResponseData());

      // Primeiro cancelamento
      const cancelReq = createMockReqRes({
        method: 'PATCH',
        body: {
          id: trip.id,
          action: 'cancel',
        },
      });
      await handler(cancelReq.req, cancelReq.res);
      expect(cancelReq.res.getStatusCode()).toBe(200);

      // Segundo cancelamento ou ação sobre corrida cancelada deve ser rejeitado com status 400
      const repeatReq = createMockReqRes({
        method: 'PATCH',
        body: {
          id: trip.id,
          action: 'cancel',
        },
      });
      await handler(repeatReq.req, repeatReq.res);
      expect(repeatReq.res.getStatusCode()).toBe(400);
      const errorData = repeatReq.res.getResponseData();
      expect(errorData.error || errorData.message).toMatch(/cancelad/i);
    });
  });
});

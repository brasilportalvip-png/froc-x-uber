import { describe, it, expect } from 'vitest';
import { validateNegotiatedOffer, calculateNegotiatedFloor } from '../api/_lib/pricing';

interface AuctionBid {
  id: string;
  driverId: string;
  driverName: string;
  amount: number;
  status: 'pending' | 'accepted' | 'declined';
}

function processBidAuction(bids: AuctionBid[], acceptedBidId: string): AuctionBid[] {
  const targetBid = bids.find((b) => b.id === acceptedBidId);
  if (!targetBid) {
    throw new Error('Lance não encontrado no leilão ativo.');
  }

  return bids.map((bid) => ({
    ...bid,
    status: bid.id === acceptedBidId ? 'accepted' : 'declined',
  }));
}

describe('Bidding and Auction Rules (inDrive & Freight)', () => {
  const tripKm = 18;
  const durationMinutes = 35;
  const floor = calculateNegotiatedFloor(tripKm, durationMinutes);

  it('bloqueia criação de lance de motorista com valor abaixo da cotação mínima regulatória', () => {
    const illegalDriverAmount = floor.minimumFloor - 5;
    const check = validateNegotiatedOffer(illegalDriverAmount, tripKm, durationMinutes);
    expect(check.isValid).toBe(false);
  });

  it('permite contrapropostas dinâmicas de motoristas no leilão', () => {
    const passengerOffer = floor.minimumFloor + 2.00;
    const driverCounterBid = passengerOffer + 7.50;

    const checkPassenger = validateNegotiatedOffer(passengerOffer, tripKm, durationMinutes);
    const checkDriver = validateNegotiatedOffer(driverCounterBid, tripKm, durationMinutes);

    expect(checkPassenger.isValid).toBe(true);
    expect(checkDriver.isValid).toBe(true);
    expect(driverCounterBid).toBeGreaterThan(passengerOffer);
  });

  it('ao aceitar um lance, cancela atomicamente todas as ofertas concorrentes', () => {
    const auctionBids: AuctionBid[] = [
      { id: 'bid-1', driverId: 'drv-carlos', driverName: 'Carlos Santos', amount: 45.00, status: 'pending' },
      { id: 'bid-2', driverId: 'drv-ana', driverName: 'Ana Paula', amount: 42.00, status: 'pending' },
      { id: 'bid-3', driverId: 'drv-marcos', driverName: 'Marcos Caminhoneiro', amount: 48.00, status: 'pending' },
    ];

    const resolved = processBidAuction(auctionBids, 'bid-2');

    const accepted = resolved.find((b) => b.id === 'bid-2');
    const declined = resolved.filter((b) => b.id !== 'bid-2');

    expect(accepted?.status).toBe('accepted');
    expect(declined).toHaveLength(2);
    declined.forEach((bid) => {
      expect(bid.status).toBe('declined');
    });
  });

  it('dispara erro se tentar aceitar lance inexistente', () => {
    const auctionBids: AuctionBid[] = [
      { id: 'bid-1', driverId: 'drv-1', driverName: 'Condutor', amount: 50.00, status: 'pending' },
    ];
    expect(() => processBidAuction(auctionBids, 'bid-inexistente')).toThrow('Lance não encontrado');
  });
});

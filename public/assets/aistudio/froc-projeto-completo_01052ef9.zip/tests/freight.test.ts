import { describe, it, expect } from 'vitest';
import { calculateFreightQuote } from '../api/_lib/pricing';

describe('Freight and Return Cargo Engine (Caminhão & Mudanças)', () => {
  it('calcula cubagem volumétrica e peso com acréscimo proporcional', () => {
    const smallVan = calculateFreightQuote(100, 6, 400, false, 0);
    const largeTruck = calculateFreightQuote(100, 36, 6000, false, 0);

    expect(largeTruck.finalQuote).toBeGreaterThan(smallVan.finalQuote);
    expect(largeTruck.volumeCost).toBeGreaterThan(smallVan.volumeCost);
    expect(largeTruck.weightCost).toBeGreaterThan(smallVan.weightCost);
  });

  it('garante retenção de 8% de comissão da plataforma para transporte de carga', () => {
    const quote = calculateFreightQuote(250, 18, 1200, true, 2);
    expect(quote.commissionRate).toBe(0.08);
    expect(quote.platformFee).toBe(Number((quote.finalQuote * 0.08).toFixed(2)));
    expect(Number((quote.carrierPayout + quote.platformFee).toFixed(2))).toBe(quote.finalQuote);
  });

  it('aplica limite de segurança para ajudantes de 0 a 4', () => {
    const quoteMaxHelpers = calculateFreightQuote(50, 10, 500, true, 10); // solicita 10, limita em 4
    expect(quoteMaxHelpers.helpersCost).toBe(600.00); // 4 * 150
  });

  it('bonifica o embarcador com valor reduzido de retorno vazio', () => {
    const fullPrice = calculateFreightQuote(300, 20, 1500, false, 1);
    const returnPrice = calculateFreightQuote(300, 20, 1500, true, 1);

    const discountAmount = fullPrice.subtotal * 0.35;
    expect(returnPrice.returnDiscount).toBeCloseTo(discountAmount, 1);
    expect(returnPrice.finalQuote).toBeLessThan(fullPrice.finalQuote);
  });
});

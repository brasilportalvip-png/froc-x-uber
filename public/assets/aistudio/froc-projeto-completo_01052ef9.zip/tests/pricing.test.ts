import { describe, it, expect } from 'vitest';
import {
  calculateDirectFare,
  calculateNegotiatedFloor,
  validateNegotiatedOffer,
  calculateCarpoolFare,
  calculateFreightQuote,
  PLATFORM_COMMISSION_RATES,
  REGULATORY_FLOOR_PER_KM,
  MINIMUM_RIDE_FARE,
} from '../api/_lib/pricing';

describe('Pricing Engine: 4-in-1 Modalities', () => {
  describe('Modalidade 1: Urbana Direta (Uber/99)', () => {
    it('aplica comissão de 12% da plataforma e respeita a tarifa mínima', () => {
      const result = calculateDirectFare(1.0, 3, 'standard');
      expect(result.commissionRate).toBe(PLATFORM_COMMISSION_RATES.DIRECT);
      expect(result.finalFare).toBeGreaterThanOrEqual(MINIMUM_RIDE_FARE);
      expect(result.platformFee).toBe(Number((result.finalFare * 0.12).toFixed(2)));
      expect(Number((result.driverPayout + result.platformFee).toFixed(2))).toBe(result.finalFare);
    });

    it('calcula multiplicadores proporcionais para categorias Comfort e Black', () => {
      const km = 15;
      const mins = 30;
      const standard = calculateDirectFare(km, mins, 'standard');
      const comfort = calculateDirectFare(km, mins, 'comfort');
      const black = calculateDirectFare(km, mins, 'black');

      expect(comfort.finalFare).toBeGreaterThan(standard.finalFare);
      expect(black.finalFare).toBeGreaterThan(comfort.finalFare);
    });
  });

  describe('Modalidade 2: Negociada com Leilão (inDrive)', () => {
    it('rejeita ofertas do passageiro abaixo do piso regulatório', () => {
      const km = 20;
      const mins = 40;
      const validation = validateNegotiatedOffer(15.00, km, mins);
      expect(validation.isValid).toBe(false);
      expect(validation.minimumFloor).toBeGreaterThan(15.00);
      expect(validation.message).toContain('abaixo do piso regulatório');
    });

    it('aceita ofertas válidas acima ou iguais ao piso regulatório', () => {
      const km = 10;
      const mins = 20;
      const floorData = calculateNegotiatedFloor(km, mins);
      const validation = validateNegotiatedOffer(floorData.minimumFloor + 5.00, km, mins);
      expect(validation.isValid).toBe(true);
    });

    it('garante piso regulamentado mínimo por km', () => {
      const km = 50;
      const floorData = calculateNegotiatedFloor(km, 60);
      expect(floorData.minimumFloor).toBeGreaterThanOrEqual(km * REGULATORY_FLOOR_PER_KM);
    });
  });

  describe('Modalidade 3: Carona Compartilhada (BlaBlaCar)', () => {
    it('calcula assentos múltiplos com taxa de intermediação de 10%', () => {
      const km = 120;
      const result1Seat = calculateCarpoolFare(km, 1);
      const result3Seats = calculateCarpoolFare(km, 3);

      expect(result1Seat.commissionRate).toBe(0.10);
      expect(result3Seats.grossTotal).toBe(Number((result1Seat.pricePerSeat * 3).toFixed(2)));
      expect(result3Seats.platformFee).toBe(Number((result3Seats.grossTotal * 0.10).toFixed(2)));
      expect(Number((result3Seats.driverPayout + result3Seats.platformFee).toFixed(2))).toBe(result3Seats.grossTotal);
    });
  });

  describe('Modalidade 4: Carga e Retorno Vazio (Caminhões e Mudanças)', () => {
    it('concede desconto de até 35% para caminhões em trajeto de retorno vazio', () => {
      const km = 400;
      const vol = 25;
      const kg = 2000;
      const withReturn = calculateFreightQuote(km, vol, kg, true, 1);
      const standardFreight = calculateFreightQuote(km, vol, kg, false, 1);

      expect(withReturn.commissionRate).toBe(0.08);
      expect(withReturn.returnDiscount).toBeGreaterThan(0);
      expect(withReturn.finalQuote).toBeLessThan(standardFreight.finalQuote);
    });

    it('acrescenta custo adicional correto por ajudante solicitado', () => {
      const km = 50;
      const vol = 10;
      const kg = 500;
      const noHelpers = calculateFreightQuote(km, vol, kg, true, 0);
      const twoHelpers = calculateFreightQuote(km, vol, kg, true, 2);

      expect(twoHelpers.helpersCost).toBe(300.00); // 2 * R$ 150
      expect(twoHelpers.subtotal - noHelpers.subtotal).toBe(300.00);
    });
  });
});
